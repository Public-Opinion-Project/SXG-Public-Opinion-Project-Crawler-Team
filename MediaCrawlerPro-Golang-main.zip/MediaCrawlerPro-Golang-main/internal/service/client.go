package service

import (
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/account_pool"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/rpc/signsrv"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo/accounts_cookies"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/xhs"
)

type ICrawlerClient interface {
	// Initialize initialize
	Initialize()

	// Pong get pong
	Pong() bool

	// Request send request
	Request(method, url string, data []byte, headers map[string]string) (string, error)

	// Get send get request
	Get(uri string, params map[string]any) (string, error)

	// Post send post request
	Post(uri string, data any) (string, error)
}

func NewXhsClient() *xhs.Client {
	configConfig := config.GetConfig()
	db := repo.GetDB()
	logger := tools.GetLogger()
	cookiesAccountRepo := accounts_cookies.NewCrawlerCookiesAccountRepo(db, logger)
	accountPool := account_pool.NewAccountPool(configConfig, cookiesAccountRepo)
	accountWithIpPool := account_pool.NewAccountWithIpPool(accountPool)
	client := signsrv.NewSignClient(configConfig)
	xhsClient := xhs.NewXhsClient(accountWithIpPool, client)
	return xhsClient
}
