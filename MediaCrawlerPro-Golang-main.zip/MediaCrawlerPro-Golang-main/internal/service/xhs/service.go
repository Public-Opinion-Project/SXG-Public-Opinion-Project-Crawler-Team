package xhs

import (
	"os"
	"strconv"
	"strings"
	"sync"

	config "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/constant"
	xhsmodel "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models/xiaohongshu"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo/platform_save_data/xhs"
	"github.com/panjf2000/ants/v2"
)

type Crawler struct {
	client *Client
	logger *tools.Logger
	config *config.Config
	store  xhs.Store
}

// NewXhsCrawler create xhs crawler
func NewXhsCrawler(client *Client, store xhs.Store) *Crawler {
	crawler := &Crawler{
		client: client,
		logger: tools.GetLogger(),
		config: config.GetConfig(),
		store:  store,
	}
	crawler.Initialize()
	return crawler
}

// Initialize 初始化
func (c *Crawler) Initialize() {
	var (
		logger = tools.GetLogger()
	)
	logger.Info("[Crawler.Initialize] initialize xhs crawler")
	c.client.Initialize()
}

// Start 主流程开始
func (c *Crawler) Start() {
	c.logger.Info("[Crawler.Start] start xhs crawler")
	if !c.client.Pong() {
		c.logger.Error("[Crawler.Start] api client pong failed")
		return
	}

	switch c.config.CrawlerType {
	case constant.SearchCrawlerType:
		c.Search()
	case constant.DetailCrawlerType:
		c.GetSpecifiedNotes()
	case constant.CreatorCrawlerType:
		c.GetCreatorAndNotes()
	}

}

// Search 指定关键词搜索
func (c *Crawler) Search() {
	c.logger.Info("[Crawler.Search] begin search xhs")

	xhsLimitCount := 20
	if c.config.CrawlerMaxNotesCount < xhsLimitCount {
		c.config.CrawlerMaxNotesCount = xhsLimitCount
	}

	startPage := c.config.StartPage // 起始页码, 从第几页开始搜索, 默认从第1页开始搜索
	for _, keyword := range c.config.Keywords {
		c.logger.Info("[Crawler.Search] search keyword: ", keyword)
		page := 1
		for (page-startPage+1)*xhsLimitCount <= c.config.CrawlerMaxNotesCount {
			if page < startPage {
				c.logger.Info("[Crawler.Search] skip page: ", page)
				page++
				continue
			}
			c.logger.Info("[Crawler.Search] search keyword: ", keyword, " page: ", page)
			searchReq := &xhsmodel.SearchRequest{
				Keyword:  keyword,
				Page:     page,
				PageSize: xhsLimitCount,
				SearchID: tools.GetSearchID(),
				Sort:     xhsmodel.SearchSortTypeGeneral,
				NoteType: xhsmodel.SearchNoteTypeAll,
			}
			searchResp, err := c.client.SearchNotesByKeyword(searchReq)
			if err != nil {
				c.logger.Error("[Crawler.Search] search notes by keyword error: ", err, " keyword: ", keyword, " page: ", page)
				break
			}

			if !searchResp.HasMore {
				c.logger.Info("[Crawler.Search] search notes by keyword: ", keyword, " page: ", page, " no more data")
				break
			}

			c.logger.Info("[Crawler.Search] search notes by keyword: ", keyword, " count: ", len(searchResp.Items))

			// 批量获取帖子详情
			noteIds := make([]string, 0)
			xSecTokens := make([]string, 0)
			xSecSources := make([]string, 0)
			for _, note := range searchResp.Items {
				noteIds = append(noteIds, note.ID)
				xSecTokens = append(xSecTokens, note.XsecToken)
				xSecSources = append(xSecSources, "pc_feed")
			}
			noteDetailResults, failedCount := c.BatchGetNoteDetailTask(noteIds, xSecTokens, xSecSources)
			if failedCount > 4 {
				// 如果从html中获取帖子详情失败次数大于4次，则大概率帖子详情已经无法获取了，可能是由于验证码问题，直接panic,就不接着往下面搜索了
				c.logger.Error("[Crawler.Search] search keyword: ", keyword, " page: ", page, " get note detail failed count: ", failedCount, " noteIds: ", strings.Join(noteIds, ","))
				panic("get note detail failed count: " + strconv.Itoa(failedCount) + " noteIds: " + strings.Join(noteIds, ","))
			}

			// 保存帖子详情
			for _, note := range noteDetailResults {
				note.XsecSource = "pc_feed"
				noteRepo := ConvertNoteDetailToNoteRepo(note)
				c.logger.Info("[Crawler.Search] save note: ", noteRepo)
				c.store.StoreContent(noteRepo)
			}
			// todo 批量获取评论
			page++
		}
	}

}

func (c *Crawler) GetSpecifiedNotes() {}

func (c *Crawler) GetCreatorAndNotes() {}

// BatchGetNoteDetailTask 批量获取帖子详情
func (c *Crawler) BatchGetNoteDetailTask(noteIds []string, xSecTokens []string, xSecSources []string) ([]*xhsmodel.NoteDetail, int) {
	var (
		wg      sync.WaitGroup
		resData = make([]*xhsmodel.NoteDetail, 0)
	)

	// 创建一个channel来收集任务结果
	results := make(chan *xhsmodel.NoteDetail, len(noteIds))
	defer close(results) // 关闭channel，通知所有等待的协程

	// 使用ants创建一个协程池用于并发的执行任务，协程池的大小为配置文件中指定的并发数
	p, _ := ants.NewPool(c.config.MaxConcurrencyNum, ants.WithPanicHandler(func(i interface{}) {
		c.logger.Error("[Crawler.BatchGetNoteDetailTask] panic occurred: ", i)
		os.Exit(-1)
	}))
	for i := 0; i < len(noteIds); i++ {
		wg.Add(1) // 往waitGroup中添加一个任务

		// 需要注意的是，当我们使用Submit方法提交任务时，协程池会自动管理协程的创建和销毁，并且，
		// 当协程池中的协程数量达到配置文件中指定的并发数时，Submit方法会阻塞，直到有协程执行完毕
		_ = p.Submit(func() {
			defer wg.Done() // 任务执行完毕后，从waitGroup中减去一个任务
			result := c.GetNoteDetailTask(noteIds[i], xSecTokens[i], xSecSources[i])
			c.logger.Info("[Crawler.BatchGetNoteDetailTask] get note detail task result: ", result)
			results <- result
		})
	}
	p.Release() // 释放协程池
	wg.Wait()   // 主协程等待所有任务执行完毕

	// 提取所有任务的结果
	failedCount := 0
	for i := 0; i < len(noteIds); i++ {
		result := <-results
		if result == nil {
			failedCount++
			continue
		}
		resData = append(resData, result)
	}

	return resData, failedCount
}

// GetNoteDetailTask 通过帖子ID和xSecToken获取帖子详情
// xSecToken: 这是xhs服务端下发的一个token，用于获取帖子详情，每个帖子都有一个唯一的token，前端无法构造
func (c *Crawler) GetNoteDetailTask(noteId, xSecToken string, xSecSource string) *xhsmodel.NoteDetail {
	noteDetail, err := c.client.GetNoteDetailFromHtml(noteId, xSecToken, xSecSource)
	if err != nil {
		c.logger.Error("[Crawler.GetNoteDetailTask] get note detail from html error: ", err, " noteId: ", noteId, " xSecToken: ", xSecToken)
		// 如果从html中获取帖子详情失败，则尝试从api中获取帖子详情
		noteDetail, err = c.client.GetNoteDetailFromApi(noteId, xSecToken, xSecSource)
		if err != nil {
			c.logger.Error("[Crawler.GetNoteDetailTask] get note detail from api error: ", err, " noteId: ", noteId)
			return nil
		}
		return noteDetail
	}
	return noteDetail
}
