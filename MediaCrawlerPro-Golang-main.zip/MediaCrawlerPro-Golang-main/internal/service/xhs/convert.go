package xhs

import (
	"fmt"
	"strings"
	"time"

	xhsmodel "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models/xiaohongshu"
	xhsrepo "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo/platform_save_data/xhs"
)

// GetVideoUrl 获取视频url
func GetVideoUrl(noteDetail *xhsmodel.NoteDetail) string {
	if noteDetail.Type != "video" {
		return ""
	}

	originVideoKey := noteDetail.Video.Consumer.OriginVideoKey

	if originVideoKey == "" {
		videos := noteDetail.Video.Media.Stream.H264
		if len(videos) > 0 {
			return videos[0].MasterUrl
		}
	} else {
		return fmt.Sprintf("http://sns-video-bd.xhscdn.com/%s", originVideoKey)
	}

	return ""
}

// GetImageList 获取图片列表
func GetImageList(noteDetail *xhsmodel.NoteDetail) []string {
	imgList := []string{}
	for _, img := range noteDetail.ImageList {
		imgList = append(imgList, img.URL)
	}
	return imgList
}

// GetTagList 获取标签列表
func GetTagList(noteDetail *xhsmodel.NoteDetail) []string {
	tagList := []string{}
	for _, tag := range noteDetail.TagList {
		if tag.Type != "topic" {
			continue
		}
		tagList = append(tagList, tag.Name)
	}
	return tagList
}

// GetNoteUrl 获取帖子url
func GetNoteUrl(noteDetail *xhsmodel.NoteDetail) string {
	// https://www.xiaohongshu.com/explore/6713d027000000002401b3ea?xsec_token=ABrLTNMvTVWKF96ZyI_G3x8EAZ6ZqsxW93FqAWZW_iOQA=&xsec_source=pc_user
	return fmt.Sprintf("%s/explore/%s?xsecToken=%s&xsecSource=%s", IndexUrl, noteDetail.NoteId, noteDetail.XsecToken, noteDetail.XsecSource)
}

// ConvertNoteDetailToNoteRepo 将帖子详情转换为数据库保存的结构体
func ConvertNoteDetailToNoteRepo(noteDetail *xhsmodel.NoteDetail) *xhsrepo.Note {
	return &xhsrepo.Note{
		NoteID:         noteDetail.NoteId,
		UserID:         noteDetail.User.UserID,
		Nickname:       noteDetail.User.Nickname,
		Avatar:         noteDetail.User.Avatar,
		IpLocation:     noteDetail.IpLocation,
		AddTs:          time.Now().Unix(),
		LastModifyTs:   time.Now().Unix(),
		Type:           noteDetail.Type,
		Title:          noteDetail.Title,
		Desc:           noteDetail.Desc,
		VideoUrl:       GetVideoUrl(noteDetail),
		Time:           noteDetail.Time,
		LastUpdateTime: noteDetail.LastUpdateTime,
		LikedCount:     noteDetail.InteractInfo.LikedCount,
		CollectedCount: noteDetail.InteractInfo.CollectedCount,
		CommentCount:   noteDetail.InteractInfo.CommentCount,
		ShareCount:     noteDetail.InteractInfo.ShareCount,
		ImageList:      strings.Join(GetImageList(noteDetail), ","),
		TagList:        strings.Join(GetTagList(noteDetail), ","),
		NoteUrl:        GetNoteUrl(noteDetail),
	}
}
