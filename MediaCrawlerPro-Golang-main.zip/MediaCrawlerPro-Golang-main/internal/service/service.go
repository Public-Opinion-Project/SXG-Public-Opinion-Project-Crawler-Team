package service

import (
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/constant"
	xhsStore "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo/platform_save_data/xhs"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/xhs"
)

type ICrawlerService interface {
	// Initialize 初始化
	Initialize()

	// Start 主流程开始
	Start()

	// Search 指定关键词搜索
	Search()

	// GetSpecifiedNotes 获取指定笔记列表信息
	GetSpecifiedNotes()

	// GetCreatorAndNotes 获取指定创作者信息和笔记列表信息
	GetCreatorAndNotes()
}

// NewCrawlerService 创建爬虫服务
func NewCrawlerService(config *config.Config) ICrawlerService {
	switch config.Platform {
	case constant.XhsPlatformName:
		return xhs.NewXhsCrawler(NewXhsClient(), xhsStore.NewXhsRepo(config))
	default:
		panic("platform not support")
	}
}
