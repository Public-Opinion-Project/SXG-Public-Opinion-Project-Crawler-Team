package bilibili

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strconv"
	"time"

	config "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models"
	bilimodel "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models/bilibili"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/account_pool"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/httpclient"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/rpc/signsrv"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
)

const (
	ApiUrl   = "https://api.bilibili.com"
	IndexUrl = "https://www.bilibili.com"
	SpaceUrl = "https://space.bilibili.com"
)

type Client struct {
	clientConfig      *httpclient.ClientConfig
	accountWithIpPool *account_pool.AccountWithIpPool
	accountInfo       *models.AccountWithIpPoolModel
	logger            *tools.Logger
	config            *config.Config
	signSrvClient     *signsrv.Client
}

func NewBilibiliClient(accountWithIpPool *account_pool.AccountWithIpPool, signSrvClient *signsrv.Client) *Client {
	globalConfig := config.GetConfig()
	clientConfig := &httpclient.ClientConfig{
		TimeOut: time.Duration(globalConfig.RequestTimeOut) * time.Second,
		Headers: make(map[string]string),
	}
	client := &Client{
		logger:            tools.GetLogger(),
		config:            globalConfig,
		clientConfig:      clientConfig,
		accountWithIpPool: accountWithIpPool,
		signSrvClient:     signSrvClient,
	}
	client.addRequestHeaders()
	return client
}

func (c *Client) Initialize() {
	err := c.updateAccountInfo()
	if err != nil {
		c.logger.Error("[Client.Initialize] update account info error: ", err)
		panic(err)
	}
}

func (c *Client) addRequestHeaders() {
	c.clientConfig.SetHeader("referer", "https://www.bilibili.com/")
	c.clientConfig.SetHeader("origin", "https://www.bilibili.com")
	c.clientConfig.SetHeader("Accept-Language", "zh-CN,zh;q=0.9")
	c.clientConfig.SetHeader("Accept", "application/json, text/plain, */*")
	c.clientConfig.SetHeader("user-agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36")
}

func (c *Client) updateAccountInfo() error {
	accountInfo, err := c.accountWithIpPool.GetAccountWithIpInfo()
	if err != nil {
		c.logger.Error("[Client.updateAccountInfo] Get account with ip info error: ", err)
		return err
	}
	c.accountInfo = accountInfo
	return nil
}

func (c *Client) getIpProxy() string {
	if c.accountInfo.IpInfo != nil {
		return c.accountInfo.IpInfo.FormatProxyToString()
	}
	return ""
}

func (c *Client) checkIpExpired() error {
	if c.config.ProxyConfig.EnableIpProxy && c.accountInfo.IpInfo != nil && c.accountInfo.IpInfo.Expired() {
		c.logger.Info("[Client.checkIpExpired] ip is expired, reload ip")
		ip, err := c.accountWithIpPool.ProxyIpPool.GetProxy()
		if err != nil {
			c.logger.Error("[Client.checkIpExpired] Get ip error: ", err)
			return err
		}
		c.accountInfo.IpInfo = ip
	}
	return nil
}

// preRequestData 预处理请求数据（添加WBI签名）
func (c *Client) preRequestData(params map[string]string) (map[string]string, error) {
	signReq := &signsrv.BilibiliSignRequest{
		ReqData: params,
		Cookies: c.accountInfo.Account.Cookies,
	}
	signResp, err := c.signSrvClient.BilibiliSignServer(signReq)
	if err != nil {
		c.logger.Error("[Client.preRequestData] sign request error: ", err)
		return nil, err
	}
	// 添加签名参数
	params["wts"] = signResp.Result.Wts
	params["w_rid"] = signResp.Result.WRid
	return params, nil
}

// Request 发送HTTP请求
func (c *Client) Request(method, url string, headers map[string]string) (string, error) {
	var (
		err      error
		response *http.Response
	)

	err = c.checkIpExpired()
	if err != nil {
		return "", err
	}

	httpClient, err := httpclient.NewHttpClient(c.clientConfig.TimeOut, c.getIpProxy())
	if err != nil {
		c.logger.Error("[Client.Request] create http client error: ", err)
		return "", err
	}
	for key, value := range headers {
		httpClient.SetHeader(key, value)
	}

	if c.config.DebugRequest {
		c.logger.Debug("[Client.Request] Request url: ", url, " method: ", method)
	}

	switch method {
	case http.MethodGet:
		response, err = httpClient.Get(url)
	default:
		c.logger.Error("[Client.Request] unsupported Request method")
		return "", errors.New("unsupported request method")
	}

	if err != nil {
		c.logger.Error("[Client.Request] Request error: ", err)
		return "", err
	}

	bodyBytes, err := io.ReadAll(response.Body)
	if err != nil {
		c.logger.Error("[Client.Request] read response body error: ", err)
		return "", err
	}
	defer response.Body.Close()

	if c.config.DebugRequest {
		c.logger.Debug("[Client.Request] Response: ", string(bodyBytes))
	}

	return string(bodyBytes), nil
}

// Get 发送GET请求
func (c *Client) Get(uri string, params map[string]string) (string, error) {
	// 添加WBI签名
	signedParams, err := c.preRequestData(params)
	if err != nil {
		return "", err
	}

	// 构建URL
	queryStr := tools.EncodeQueryParamsStr(signedParams)
	url := ApiUrl + uri + "?" + queryStr

	headers := c.clientConfig.GetHeaders()
	headers["Cookie"] = c.accountInfo.Account.Cookies

	return c.Request(http.MethodGet, url, headers)
}

func (c *Client) unmarshalResponseData(data []byte, resp any) error {
	return json.Unmarshal(data, resp)
}

// Pong 检查登录状态
func (c *Client) Pong() bool {
	if !c.signSrvClient.PongSignServer() {
		c.logger.Error("[Client.Pong] sign server pong failed")
		return false
	}
	c.logger.Info("[Client.Pong] Begin to check login state....")
	if c.accountInfo == nil {
		c.logger.Error("[Client.Pong] account info is empty")
		return false
	}
	// 简单检查cookie是否存在
	if c.accountInfo.Account.Cookies == "" {
		return false
	}
	return true
}

// SearchVideoByKeyword 搜索视频
func (c *Client) SearchVideoByKeyword(keyword string, page, pageSize int, order string) (*bilimodel.SearchData, error) {
	uri := "/x/web-interface/wbi/search/type"
	params := map[string]string{
		"search_type": "video",
		"keyword":     keyword,
		"page":        strconv.Itoa(page),
		"page_size":   strconv.Itoa(pageSize),
		"order":       order,
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.SearchResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}

// GetVideoInfo 获取视频详情
func (c *Client) GetVideoInfo(bvid string, aid int64) (*bilimodel.VideoInfo, error) {
	uri := "/x/web-interface/view"
	params := map[string]string{}
	if bvid != "" {
		params["bvid"] = bvid
	} else if aid > 0 {
		params["aid"] = strconv.FormatInt(aid, 10)
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.VideoInfoResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}

// GetVideoComments 获取视频评论
func (c *Client) GetVideoComments(aid int64, cursor int, pageSize int) (*bilimodel.CommentData, error) {
	uri := "/x/v2/reply/wbi/main"
	params := map[string]string{
		"type": "1",
		"oid":  strconv.FormatInt(aid, 10),
		"mode": "3",
		"plat": "1",
		"ps":   strconv.Itoa(pageSize),
		"next": strconv.Itoa(cursor),
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.CommentResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}

// GetUpInfo 获取UP主信息
func (c *Client) GetUpInfo(mid int64) (*bilimodel.UpInfo, error) {
	uri := "/x/space/wbi/acc/info"
	params := map[string]string{
		"mid": strconv.FormatInt(mid, 10),
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.UpInfoResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}

// GetUpStat 获取UP主统计信息
func (c *Client) GetUpStat(mid int64) (*bilimodel.UpStat, error) {
	uri := "/x/relation/stat"
	params := map[string]string{
		"vmid": strconv.FormatInt(mid, 10),
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.UpStatResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}

// GetUpVideos 获取UP主视频列表
func (c *Client) GetUpVideos(mid int64, page, pageSize int) (*bilimodel.SpaceVideoData, error) {
	uri := "/x/space/wbi/arc/search"
	params := map[string]string{
		"mid": strconv.FormatInt(mid, 10),
		"pn":  strconv.Itoa(page),
		"ps":  strconv.Itoa(pageSize),
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.SpaceVideoResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}

// GetHomefeedVideos 获取首页推荐
func (c *Client) GetHomefeedVideos(freshIdx int) (*bilimodel.HomefeedData, error) {
	uri := "/x/web-interface/wbi/index/top/feed/rcmd"
	params := map[string]string{
		"fresh_type":   "3",
		"ps":           "12",
		"fresh_idx":    strconv.Itoa(freshIdx),
		"fresh_idx_1h": strconv.Itoa(freshIdx),
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var resp bilimodel.HomefeedResponse
	if err := c.unmarshalResponseData([]byte(respData), &resp); err != nil {
		return nil, err
	}

	if resp.Code != 0 {
		return nil, errors.New(resp.Message)
	}

	return resp.Data, nil
}
