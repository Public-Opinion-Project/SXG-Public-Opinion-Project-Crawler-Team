// internal/bilibili/store.go
package bilibili

import (
	"context"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

// Store 存储接口
type Store interface {
	// Video 相关
	SaveVideo(ctx context.Context, video *Video) error
	VideoExists(ctx context.Context, videoID string) (bool, error)

	// Comment 相关
	SaveComment(ctx context.Context, comment *VideoComment) error

	// UpInfo 相关
	SaveUpInfo(ctx context.Context, upInfo *UpInfo) error
}

// DBStore 数据库存储实现
type DBStore struct {
	db *gorm.DB
}

// NewDBStore 创建数据库存储
func NewDBStore(db *gorm.DB) *DBStore {
	return &DBStore{db: db}
}

// SaveVideo 保存视频（upsert语义）
func (s *DBStore) SaveVideo(ctx context.Context, video *Video) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "video_id"}},
			UpdateAll: true,
		}).Create(video).Error
}

// VideoExists 检查视频是否存在
func (s *DBStore) VideoExists(ctx context.Context, videoID string) (bool, error) {
	var count int64
	err := s.db.WithContext(ctx).Model(&Video{}).Where("video_id = ?", videoID).Count(&count).Error
	return count > 0, err
}

// SaveComment 保存评论（upsert语义）
func (s *DBStore) SaveComment(ctx context.Context, comment *VideoComment) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "comment_id"}},
			UpdateAll: true,
		}).Create(comment).Error
}

// SaveUpInfo 保存UP主信息（upsert语义）
func (s *DBStore) SaveUpInfo(ctx context.Context, upInfo *UpInfo) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "user_id"}},
			UpdateAll: true,
		}).Create(upInfo).Error
}
