package bilibili

import (
	"context"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/constant"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/crawler"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	biliclient "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/bilibili"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
	"gorm.io/gorm"
)

// CrawlerOptions Crawler配置选项
type CrawlerOptions struct {
	DB         *gorm.DB
	Client     *biliclient.Client
	WorkerSize int
	Config     *config.Config
}

// Crawler Bilibili爬虫主结构
type Crawler struct {
	client     *biliclient.Client
	store      Store
	processor  *Processor
	checkpoint *crawler.CheckpointManager
	workerPool *worker.Pool
	handlers   map[string]Handler
	config     *config.Config
	logger     *tools.Logger
}

// NewCrawler 创建Bilibili爬虫
func NewCrawler(opts CrawlerOptions) *Crawler {
	// 设置默认值
	workerSize := opts.WorkerSize
	if workerSize <= 0 {
		workerSize = opts.Config.MaxConcurrencyNum
	}
	if workerSize <= 0 {
		workerSize = 5
	}

	store := NewDBStore(opts.DB)
	checkpoint := crawler.NewCheckpointManager("bilibili", "data/checkpoints")
	workerPool := worker.NewPool(workerSize)

	c := &Crawler{
		client:     opts.Client,
		store:      store,
		checkpoint: checkpoint,
		workerPool: workerPool,
		config:     opts.Config,
		logger:     tools.GetLogger(),
		handlers:   make(map[string]Handler),
	}

	// 创建Processor
	c.processor = NewProcessor(c.client, c.store, c.workerPool, c.config)

	// 注册Handlers
	deps := NewHandlerDeps(c.client, c.processor, c.checkpoint, c.workerPool, c.config)
	c.handlers[constant.SearchCrawlerType] = NewSearchHandler(deps)
	c.handlers[constant.DetailCrawlerType] = NewDetailHandler(deps)
	c.handlers[constant.CreatorCrawlerType] = NewCreatorHandler(deps)
	c.handlers[constant.HomefeedCrawlerType] = NewHomefeedHandler(deps)

	return c
}

// Initialize 初始化
func (c *Crawler) Initialize() {
	c.logger.Info("[Crawler.Initialize] Initializing Bilibili crawler")
	c.client.Initialize()
}

// Start 启动爬虫
func (c *Crawler) Start(ctx context.Context) {
	c.logger.Info("[Crawler.Start] Starting Bilibili crawler")

	// 检查登录状态
	if !c.client.Pong() {
		c.logger.Error("[Crawler.Start] API client pong failed, please check account")
		return
	}

	// 根据配置选择Handler
	crawlerType := c.config.CrawlerType
	handler, ok := c.handlers[crawlerType]
	if !ok {
		c.logger.Error("[Crawler.Start] Unknown crawler type: ", crawlerType)
		return
	}

	c.logger.Info("[Crawler.Start] Using handler: ", handler.Name())

	// 执行爬取
	if err := handler.Handle(ctx); err != nil {
		c.logger.Error("[Crawler.Start] Handler error: ", err)
		return
	}

	c.logger.Info("[Crawler.Start] Bilibili crawler finished")
}

// GetHandler 获取指定类型的Handler
func (c *Crawler) GetHandler(crawlerType string) Handler {
	return c.handlers[crawlerType]
}

// GetStore 获取存储实例
func (c *Crawler) GetStore() Store {
	return c.store
}

// GetProcessor 获取处理器实例
func (c *Crawler) GetProcessor() *Processor {
	return c.processor
}
