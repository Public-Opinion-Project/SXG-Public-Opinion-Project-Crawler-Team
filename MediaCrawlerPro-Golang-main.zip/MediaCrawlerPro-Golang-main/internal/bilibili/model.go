// internal/bilibili/model.go
package bilibili

// Video 对应 bilibili_video 表
type Video struct {
	ID             int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID         string `gorm:"column:user_id;not null"`
	Nickname       string `gorm:"column:nickname"`
	Avatar         string `gorm:"column:avatar"`
	AddTs          int64  `gorm:"column:add_ts;not null"`
	LastModifyTs   int64  `gorm:"column:last_modify_ts;not null"`
	VideoID        string `gorm:"column:video_id;not null;index"`
	Bvid           string `gorm:"column:bvid"`
	VideoType      string `gorm:"column:video_type"`
	Title          string `gorm:"column:title;type:longtext"`
	Desc           string `gorm:"column:desc;type:longtext"`
	CreateTime     int64  `gorm:"column:create_time;not null;index"`
	LikedCount     string `gorm:"column:liked_count"`
	VideoPlayCount string `gorm:"column:video_play_count"`
	VideoDanmaku   string `gorm:"column:video_danmaku"`
	VideoComment   string `gorm:"column:video_comment"`
	VideoDuration  string `gorm:"column:video_duration"`
	VideoURL       string `gorm:"column:video_url;type:longtext"`
	VideoCover     string `gorm:"column:video_cover;type:longtext"`
	SourceKeyword  string `gorm:"column:source_keyword"`
}

func (Video) TableName() string { return "bilibili_video" }

// VideoComment 对应 bilibili_video_comment 表
type VideoComment struct {
	ID              int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID          string `gorm:"column:user_id;not null"`
	Nickname        string `gorm:"column:nickname"`
	Avatar          string `gorm:"column:avatar"`
	AddTs           int64  `gorm:"column:add_ts;not null"`
	LastModifyTs    int64  `gorm:"column:last_modify_ts;not null"`
	CommentID       string `gorm:"column:comment_id;not null;index"`
	VideoID         string `gorm:"column:video_id;not null"`
	Content         string `gorm:"column:content;type:longtext;not null"`
	CreateTime      int64  `gorm:"column:create_time;not null;index"`
	SubCommentCount string `gorm:"column:sub_comment_count;not null"`
	ParentCommentID string `gorm:"column:parent_comment_id"`
	LikeCount       string `gorm:"column:like_count;not null;default:'0'"`
}

func (VideoComment) TableName() string { return "bilibili_video_comment" }

// UpInfo 对应 bilibili_up_info 表
type UpInfo struct {
	ID             int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID         string `gorm:"column:user_id;not null;index"`
	Nickname       string `gorm:"column:nickname"`
	Avatar         string `gorm:"column:avatar"`
	AddTs          int64  `gorm:"column:add_ts;not null"`
	LastModifyTs   int64  `gorm:"column:last_modify_ts;not null"`
	Desc           string `gorm:"column:desc;type:longtext"`
	FollowerCount  string `gorm:"column:follower_count"`
	FollowingCount string `gorm:"column:following_count"`
	ContentCount   string `gorm:"column:content_count"`
}

func (UpInfo) TableName() string { return "bilibili_up_info" }
