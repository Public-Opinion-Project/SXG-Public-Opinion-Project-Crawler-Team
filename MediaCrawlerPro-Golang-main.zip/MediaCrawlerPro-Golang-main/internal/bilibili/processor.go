package bilibili

import (
	"context"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	bilimodel "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models/bilibili"
	biliclient "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/bilibili"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
)

// Processor 数据处理器
type Processor struct {
	client     *biliclient.Client
	store      Store
	workerPool *worker.Pool
	config     *config.Config
	logger     *tools.Logger
}

func NewProcessor(client *biliclient.Client, store Store, workerPool *worker.Pool, cfg *config.Config) *Processor {
	return &Processor{
		client:     client,
		store:      store,
		workerPool: workerPool,
		config:     cfg,
		logger:     tools.GetLogger(),
	}
}

// ProcessVideos 批量处理视频
func (p *Processor) ProcessVideos(ctx context.Context, videoItems []VideoItem, sourceKeyword string) (int, error) {
	if len(videoItems) == 0 {
		return 0, nil
	}

	p.logger.Info("[Processor.ProcessVideos] Processing ", len(videoItems), " videos")

	var successCount int32
	tasks := make([]worker.Task, 0, len(videoItems))

	for _, item := range videoItems {
		videoItem := item // 捕获变量
		tasks = append(tasks, func(ctx context.Context) error {
			err := p.processOneVideo(ctx, videoItem, sourceKeyword)
			if err == nil {
				atomic.AddInt32(&successCount, 1)
			}
			return err
		})
	}

	errs := p.workerPool.Submit(ctx, tasks)
	if len(errs) > 0 {
		p.logger.Error("[Processor.ProcessVideos] Failed count: ", len(errs))
	}

	return int(successCount), nil
}

// processOneVideo 处理单个视频
func (p *Processor) processOneVideo(ctx context.Context, item VideoItem, sourceKeyword string) error {
	videoID := strconv.FormatInt(item.Aid, 10)
	if videoID == "0" && item.Bvid != "" {
		videoID = item.Bvid
	}

	// 检查是否已存在
	exists, _ := p.store.VideoExists(ctx, videoID)
	if exists {
		p.logger.Info("[Processor.processOneVideo] Video already exists: ", videoID)
		return nil
	}

	// 获取视频详情
	videoInfo, err := p.client.GetVideoInfo(item.Bvid, item.Aid)
	if err != nil {
		p.logger.Error("[Processor.processOneVideo] Get video info failed: ", videoID, err)
		return err
	}

	// 转换为存储模型
	video := p.convertVideoInfoToModel(videoInfo)
	video.SourceKeyword = sourceKeyword
	video.VideoURL = "https://www.bilibili.com/video/" + videoInfo.Bvid

	// 保存
	if err := p.store.SaveVideo(ctx, video); err != nil {
		p.logger.Error("[Processor.processOneVideo] Save video failed: ", videoID, err)
		return err
	}

	p.logger.Info("[Processor.processOneVideo] Saved video: ", videoID)
	return nil
}

// convertVideoInfoToModel 将API响应转换为存储模型
func (p *Processor) convertVideoInfoToModel(info *bilimodel.VideoInfo) *Video {
	now := time.Now().Unix()

	return &Video{
		VideoID:        strconv.FormatInt(info.Aid, 10),
		Bvid:           info.Bvid,
		UserID:         strconv.FormatInt(info.Owner.Mid, 10),
		Nickname:       info.Owner.Name,
		Avatar:         info.Owner.Face,
		AddTs:          now,
		LastModifyTs:   now,
		VideoType:      info.Tname,
		Title:          info.Title,
		Desc:           info.Desc,
		CreateTime:     info.Pubdate,
		LikedCount:     strconv.FormatInt(info.Stat.Like, 10),
		VideoPlayCount: strconv.FormatInt(info.Stat.View, 10),
		VideoDanmaku:   strconv.FormatInt(info.Stat.Danmaku, 10),
		VideoComment:   strconv.FormatInt(info.Stat.Reply, 10),
		VideoDuration:  strconv.FormatInt(info.Duration, 10),
		VideoCover:     info.Pic,
	}
}

// ProcessComments 批量处理视频评论
func (p *Processor) ProcessComments(ctx context.Context, aids []int64) {
	if len(aids) == 0 || !p.config.EnableGetComments {
		return
	}

	p.logger.Info("[Processor.ProcessComments] Processing comments for ", len(aids), " videos")

	tasks := make([]worker.Task, 0, len(aids))
	for _, aid := range aids {
		videoAid := aid
		tasks = append(tasks, func(ctx context.Context) error {
			return p.processVideoComments(ctx, videoAid)
		})
	}

	p.workerPool.Submit(ctx, tasks)
}

// processVideoComments 处理单个视频的所有评论
func (p *Processor) processVideoComments(ctx context.Context, aid int64) error {
	cursor := 0
	totalComments := 0
	maxComments := p.config.PerNoteMaxComments
	if maxComments <= 0 {
		maxComments = 100
	}
	pageSize := 20

	for totalComments < maxComments {
		commentData, err := p.client.GetVideoComments(aid, cursor, pageSize)
		if err != nil {
			p.logger.Error("[Processor.processVideoComments] Get comments failed: ", aid, err)
			return err
		}

		if commentData == nil || len(commentData.Replies) == 0 {
			break
		}

		// 保存评论
		for _, reply := range commentData.Replies {
			commentModel := p.convertCommentToModel(aid, &reply, 0)
			p.store.SaveComment(ctx, commentModel)
			totalComments++

			// 处理子评论
			if p.config.EnableGetSubComments && reply.Rcount > 0 {
				for _, subReply := range reply.Replies {
					subCommentModel := p.convertCommentToModel(aid, &subReply, reply.Rpid)
					p.store.SaveComment(ctx, subCommentModel)
				}
			}
		}

		if commentData.Cursor.IsEnd {
			break
		}
		cursor = commentData.Cursor.Next
	}

	p.logger.Info("[Processor.processVideoComments] Processed ", totalComments, " comments for video: ", aid)
	return nil
}

// convertCommentToModel 转换评论为存储模型
func (p *Processor) convertCommentToModel(aid int64, comment *bilimodel.Comment, parentRpid int64) *VideoComment {
	now := time.Now().Unix()

	parentCommentID := ""
	if parentRpid > 0 {
		parentCommentID = strconv.FormatInt(parentRpid, 10)
	}

	return &VideoComment{
		CommentID:       strconv.FormatInt(comment.Rpid, 10),
		VideoID:         strconv.FormatInt(aid, 10),
		UserID:          comment.Member.Mid,
		Nickname:        comment.Member.Uname,
		Avatar:          comment.Member.Avatar,
		AddTs:           now,
		LastModifyTs:    now,
		Content:         comment.Content.Message,
		CreateTime:      comment.Ctime,
		SubCommentCount: strconv.Itoa(comment.Rcount),
		ParentCommentID: parentCommentID,
		LikeCount:       strconv.Itoa(comment.Like),
	}
}

// ProcessUpInfo 处理UP主信息
func (p *Processor) ProcessUpInfo(ctx context.Context, upInfo *bilimodel.UpInfo, upStat *bilimodel.UpStat) error {
	if upInfo == nil {
		return nil
	}

	now := time.Now().Unix()
	info := &UpInfo{
		UserID:       strconv.FormatInt(upInfo.Mid, 10),
		Nickname:     upInfo.Name,
		Avatar:       upInfo.Face,
		AddTs:        now,
		LastModifyTs: now,
		Desc:         upInfo.Sign,
	}

	if upStat != nil {
		info.FollowerCount = strconv.FormatInt(upStat.Follower, 10)
		info.FollowingCount = strconv.FormatInt(upStat.Following, 10)
	}

	return p.store.SaveUpInfo(ctx, info)
}
