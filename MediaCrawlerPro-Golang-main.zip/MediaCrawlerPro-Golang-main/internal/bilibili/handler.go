package bilibili

import (
	"context"
	"strconv"
	"time"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/crawler"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	biliclient "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/bilibili"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
)

// Handler 定义爬取处理器接口
type Handler interface {
	Handle(ctx context.Context) error
	Name() string
}

// HandlerDeps 所有Handler共享的依赖
type HandlerDeps struct {
	Client     *biliclient.Client
	Processor  *Processor
	Checkpoint *crawler.CheckpointManager
	WorkerPool *worker.Pool
	Config     *config.Config
	Logger     *tools.Logger
}

func NewHandlerDeps(
	client *biliclient.Client,
	processor *Processor,
	checkpoint *crawler.CheckpointManager,
	workerPool *worker.Pool,
	cfg *config.Config,
) *HandlerDeps {
	return &HandlerDeps{
		Client:     client,
		Processor:  processor,
		Checkpoint: checkpoint,
		WorkerPool: workerPool,
		Config:     cfg,
		Logger:     tools.GetLogger(),
	}
}

// VideoItem 视频项（用于批量处理）
type VideoItem struct {
	Aid  int64
	Bvid string
}

// ========== SearchHandler ==========

type SearchHandler struct {
	*HandlerDeps
}

func NewSearchHandler(deps *HandlerDeps) *SearchHandler {
	return &SearchHandler{HandlerDeps: deps}
}

func (h *SearchHandler) Name() string {
	return "search"
}

func (h *SearchHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[SearchHandler.Handle] Begin search bilibili")

	keywords := h.Config.Keywords
	maxVideos := h.Config.CrawlerMaxNotesCount
	pageSize := 20

	for _, keyword := range keywords {
		h.Logger.Info("[SearchHandler.Handle] Searching keyword: ", keyword)

		// 尝试加载断点
		var startPage int = 1
		var crawledCount int = 0
		cp, _ := h.Checkpoint.Load(h.Name(), keyword)
		if cp != nil {
			startPage = cp.CurrentPage
			crawledCount = cp.TotalCrawled
			h.Logger.Info("[SearchHandler.Handle] Resume from checkpoint, page: ", startPage)
		} else {
			cp = &crawler.Checkpoint{
				CrawlerType: h.Name(),
				Keyword:     keyword,
				CurrentPage: 1,
			}
		}

		page := startPage
		for crawledCount < maxVideos {
			h.Logger.Info("[SearchHandler.Handle] Searching page: ", page)

			searchData, err := h.Client.SearchVideoByKeyword(keyword, page, pageSize, "")
			if err != nil {
				h.Logger.Error("[SearchHandler.Handle] Search error: ", err)
				break
			}

			if len(searchData.Result) == 0 {
				h.Logger.Info("[SearchHandler.Handle] No more data")
				break
			}

			// 构建VideoItem列表
			videoItems := make([]VideoItem, 0)
			for _, item := range searchData.Result {
				if item.Type != "video" {
					continue
				}
				videoItems = append(videoItems, VideoItem{
					Aid:  item.Aid,
					Bvid: item.Bvid,
				})
			}

			// 处理视频
			processedCount, err := h.Processor.ProcessVideos(ctx, videoItems, keyword)
			if err != nil {
				h.Logger.Error("[SearchHandler.Handle] Process videos error: ", err)
			}

			// 处理评论
			if h.Config.EnableGetComments {
				aids := make([]int64, 0)
				for _, item := range videoItems {
					aids = append(aids, item.Aid)
				}
				h.Processor.ProcessComments(ctx, aids)
			}

			crawledCount += processedCount
			page++

			// 更新断点
			cp.CurrentPage = page
			cp.TotalCrawled = crawledCount
			h.Checkpoint.Save(cp)

			// 请求间隔
			if h.Config.CrawlerTimeSleep > 0 {
				time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
			}
		}
	}

	h.Logger.Info("[SearchHandler.Handle] Search completed")
	return nil
}

// ========== DetailHandler ==========

type DetailHandler struct {
	*HandlerDeps
}

func NewDetailHandler(deps *HandlerDeps) *DetailHandler {
	return &DetailHandler{HandlerDeps: deps}
}

func (h *DetailHandler) Name() string {
	return "detail"
}

func (h *DetailHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[DetailHandler.Handle] Begin get specified videos")

	// 从配置读取视频ID列表 (Bvid)
	videoIDs := h.Config.SpecifiedNoteIDs // 复用XHS的配置字段
	if len(videoIDs) == 0 {
		h.Logger.Warn("[DetailHandler.Handle] No video IDs specified")
		return nil
	}

	// 构建VideoItem列表
	videoItems := make([]VideoItem, 0, len(videoIDs))
	for _, bvid := range videoIDs {
		videoItems = append(videoItems, VideoItem{
			Bvid: bvid,
		})
	}

	// 处理视频
	_, err := h.Processor.ProcessVideos(ctx, videoItems, "")
	if err != nil {
		h.Logger.Error("[DetailHandler.Handle] Process videos error: ", err)
		return err
	}

	// 处理评论 - 需要先获取aid
	if h.Config.EnableGetComments {
		aids := make([]int64, 0)
		for _, bvid := range videoIDs {
			info, err := h.Client.GetVideoInfo(bvid, 0)
			if err == nil && info != nil {
				aids = append(aids, info.Aid)
			}
		}
		if len(aids) > 0 {
			h.Processor.ProcessComments(ctx, aids)
		}
	}

	h.Logger.Info("[DetailHandler.Handle] Detail completed")
	return nil
}

// ========== CreatorHandler ==========

type CreatorHandler struct {
	*HandlerDeps
}

func NewCreatorHandler(deps *HandlerDeps) *CreatorHandler {
	return &CreatorHandler{HandlerDeps: deps}
}

func (h *CreatorHandler) Name() string {
	return "creator"
}

func (h *CreatorHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[CreatorHandler.Handle] Begin get creator videos")

	// 从配置读取UP主ID列表
	creatorIDs := h.Config.SpecifiedCreatorIDs
	if len(creatorIDs) == 0 {
		h.Logger.Warn("[CreatorHandler.Handle] No creator IDs specified")
		return nil
	}

	for _, creatorIDStr := range creatorIDs {
		mid, err := strconv.ParseInt(creatorIDStr, 10, 64)
		if err != nil {
			h.Logger.Error("[CreatorHandler.Handle] Invalid creator ID: ", creatorIDStr)
			continue
		}

		h.Logger.Info("[CreatorHandler.Handle] Processing creator: ", mid)

		// 获取UP主信息
		upInfo, err := h.Client.GetUpInfo(mid)
		if err != nil {
			h.Logger.Error("[CreatorHandler.Handle] Get up info error: ", err)
			continue
		}

		// 获取UP主统计
		upStat, _ := h.Client.GetUpStat(mid)

		// 保存UP主信息
		h.Processor.ProcessUpInfo(ctx, upInfo, upStat)

		// 获取UP主视频
		page := 1
		pageSize := 30
		crawledCount := 0
		maxVideos := h.Config.CrawlerMaxNotesCount

		for crawledCount < maxVideos {
			videosData, err := h.Client.GetUpVideos(mid, page, pageSize)
			if err != nil {
				h.Logger.Error("[CreatorHandler.Handle] Get up videos error: ", err)
				break
			}

			if len(videosData.List.Vlist) == 0 {
				break
			}

			// 构建VideoItem列表
			videoItems := make([]VideoItem, 0)
			for _, v := range videosData.List.Vlist {
				videoItems = append(videoItems, VideoItem{
					Aid:  v.Aid,
					Bvid: v.Bvid,
				})
			}

			// 处理视频
			processedCount, _ := h.Processor.ProcessVideos(ctx, videoItems, "")
			crawledCount += processedCount

			// 处理评论
			if h.Config.EnableGetComments {
				aids := make([]int64, 0)
				for _, item := range videoItems {
					aids = append(aids, item.Aid)
				}
				h.Processor.ProcessComments(ctx, aids)
			}

			page++
			if crawledCount >= videosData.Page.Count {
				break
			}

			// 请求间隔
			if h.Config.CrawlerTimeSleep > 0 {
				time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
			}
		}
	}

	h.Logger.Info("[CreatorHandler.Handle] Creator completed")
	return nil
}

// ========== HomefeedHandler ==========

type HomefeedHandler struct {
	*HandlerDeps
}

func NewHomefeedHandler(deps *HandlerDeps) *HomefeedHandler {
	return &HomefeedHandler{HandlerDeps: deps}
}

func (h *HomefeedHandler) Name() string {
	return "homefeed"
}

func (h *HomefeedHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[HomefeedHandler.Handle] Begin get homefeed videos")

	freshIdx := 1
	crawledCount := 0
	maxVideos := h.Config.CrawlerMaxNotesCount

	for crawledCount < maxVideos {
		h.Logger.Info("[HomefeedHandler.Handle] Getting homefeed, idx: ", freshIdx)

		feedData, err := h.Client.GetHomefeedVideos(freshIdx)
		if err != nil {
			h.Logger.Error("[HomefeedHandler.Handle] Get homefeed error: ", err)
			break
		}

		if len(feedData.Item) == 0 {
			h.Logger.Info("[HomefeedHandler.Handle] No more data")
			break
		}

		// 构建VideoItem列表
		videoItems := make([]VideoItem, 0)
		for _, item := range feedData.Item {
			if item.Bvid == "" {
				continue
			}
			videoItems = append(videoItems, VideoItem{
				Aid:  item.Id,
				Bvid: item.Bvid,
			})
		}

		// 处理视频
		processedCount, _ := h.Processor.ProcessVideos(ctx, videoItems, "homefeed")
		crawledCount += processedCount

		// 处理评论
		if h.Config.EnableGetComments {
			aids := make([]int64, 0)
			for _, item := range videoItems {
				aids = append(aids, item.Aid)
			}
			h.Processor.ProcessComments(ctx, aids)
		}

		freshIdx++

		// 请求间隔
		if h.Config.CrawlerTimeSleep > 0 {
			time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
		}
	}

	h.Logger.Info("[HomefeedHandler.Handle] Homefeed completed")
	return nil
}
