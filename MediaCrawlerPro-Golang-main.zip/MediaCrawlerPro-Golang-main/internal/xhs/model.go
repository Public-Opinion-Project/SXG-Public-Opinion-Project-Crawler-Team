// internal/xhs/model.go
package xhs

// Note 对应 xhs_note 表
type Note struct {
	ID             int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID         string `gorm:"column:user_id;not null"`
	Nickname       string `gorm:"column:nickname"`
	Avatar         string `gorm:"column:avatar"`
	IPLocation     string `gorm:"column:ip_location"`
	AddTs          int64  `gorm:"column:add_ts;not null"`
	LastModifyTs   int64  `gorm:"column:last_modify_ts;not null"`
	NoteID         string `gorm:"column:note_id;not null;index"`
	Type           string `gorm:"column:type"`
	Title          string `gorm:"column:title"`
	Desc           string `gorm:"column:desc;type:longtext"`
	VideoURL       string `gorm:"column:video_url;type:longtext"`
	Time           int64  `gorm:"column:time;not null;index"`
	LastUpdateTime int64  `gorm:"column:last_update_time;not null"`
	LikedCount     string `gorm:"column:liked_count"`
	CollectedCount string `gorm:"column:collected_count"`
	CommentCount   string `gorm:"column:comment_count"`
	ShareCount     string `gorm:"column:share_count"`
	ImageList      string `gorm:"column:image_list;type:longtext"`
	TagList        string `gorm:"column:tag_list;type:longtext"`
	NoteURL        string `gorm:"column:note_url"`
	SourceKeyword  string `gorm:"column:source_keyword"`
}

func (Note) TableName() string { return "xhs_note" }

// NoteComment 对应 xhs_note_comment 表
type NoteComment struct {
	ID              int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID          string `gorm:"column:user_id;not null"`
	Nickname        string `gorm:"column:nickname"`
	Avatar          string `gorm:"column:avatar"`
	IPLocation      string `gorm:"column:ip_location"`
	AddTs           int64  `gorm:"column:add_ts;not null"`
	LastModifyTs    int64  `gorm:"column:last_modify_ts;not null"`
	CommentID       string `gorm:"column:comment_id;not null;index"`
	CreateTime      int64  `gorm:"column:create_time;not null;index"`
	NoteID          string `gorm:"column:note_id;not null"`
	Content         string `gorm:"column:content;type:longtext;not null"`
	SubCommentCount string `gorm:"column:sub_comment_count;not null"`
	Pictures        string `gorm:"column:pictures;type:varchar(512)"`
	ParentCommentID string `gorm:"column:parent_comment_id"`
	LikeCount       string `gorm:"column:like_count;not null;default:'0'"`
	NoteURL         string `gorm:"column:note_url;not null;default:''"`
	TargetCommentID string `gorm:"column:target_comment_id"`
}

func (NoteComment) TableName() string { return "xhs_note_comment" }

// Creator 对应 xhs_creator 表
type Creator struct {
	ID           int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID       string `gorm:"column:user_id;not null"`
	Nickname     string `gorm:"column:nickname"`
	Avatar       string `gorm:"column:avatar"`
	IPLocation   string `gorm:"column:ip_location"`
	AddTs        int64  `gorm:"column:add_ts;not null"`
	LastModifyTs int64  `gorm:"column:last_modify_ts;not null"`
	Desc         string `gorm:"column:desc;type:longtext"`
	Gender       string `gorm:"column:gender;type:varchar(2)"`
	Follows      string `gorm:"column:follows"`
	Fans         string `gorm:"column:fans"`
	Interaction  string `gorm:"column:interaction"`
	TagList      string `gorm:"column:tag_list;type:longtext"`
}

func (Creator) TableName() string { return "xhs_creator" }
