// internal/xhs/store.go
package xhs

import (
	"context"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

// Store 存储接口
type Store interface {
	// Note 相关
	SaveNote(ctx context.Context, note *Note) error
	NoteExists(ctx context.Context, noteID string) (bool, error)

	// Comment 相关
	SaveComment(ctx context.Context, comment *NoteComment) error

	// Creator 相关
	SaveCreator(ctx context.Context, creator *Creator) error
}

// DBStore 数据库存储实现
type DBStore struct {
	db *gorm.DB
}

// NewDBStore 创建数据库存储
func NewDBStore(db *gorm.DB) *DBStore {
	return &DBStore{db: db}
}

// SaveNote 保存帖子（upsert语义）
func (s *DBStore) SaveNote(ctx context.Context, note *Note) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "note_id"}},
			UpdateAll: true,
		}).Create(note).Error
}

// NoteExists 检查帖子是否存在
func (s *DBStore) NoteExists(ctx context.Context, noteID string) (bool, error) {
	var count int64
	err := s.db.WithContext(ctx).Model(&Note{}).Where("note_id = ?", noteID).Count(&count).Error
	return count > 0, err
}

// SaveComment 保存评论
func (s *DBStore) SaveComment(ctx context.Context, comment *NoteComment) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "comment_id"}},
			UpdateAll: true,
		}).Create(comment).Error
}

// SaveCreator 保存创作者
func (s *DBStore) SaveCreator(ctx context.Context, creator *Creator) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "user_id"}},
			UpdateAll: true,
		}).Create(creator).Error
}
