// internal/xhs/handler.go
package xhs

import (
	"context"
	"time"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/crawler"
	xhsmodel "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models/xiaohongshu"
	xhsclient "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/xhs"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
)

// Handler 定义爬取处理器接口
type Handler interface {
	// Handle 执行爬取任务
	Handle(ctx context.Context) error
	// Name 返回handler名称
	Name() string
}

// HandlerDeps 所有Handler共享的依赖
type HandlerDeps struct {
	Client     *xhsclient.Client
	Processor  *Processor
	Checkpoint *crawler.CheckpointManager
	WorkerPool *worker.Pool
	Config     *config.Config
	Logger     *tools.Logger
}

// NewHandlerDeps 创建Handler依赖
func NewHandlerDeps(
	client *xhsclient.Client,
	processor *Processor,
	checkpoint *crawler.CheckpointManager,
	workerPool *worker.Pool,
	cfg *config.Config,
) *HandlerDeps {
	return &HandlerDeps{
		Client:     client,
		Processor:  processor,
		Checkpoint: checkpoint,
		WorkerPool: workerPool,
		Config:     cfg,
		Logger:     tools.GetLogger(),
	}
}

// NoteItem 帖子项（用于批量处理）
type NoteItem struct {
	NoteID     string
	XsecToken  string
	XsecSource string
}

// ========== SearchHandler ==========

// SearchHandler 搜索爬取处理器
type SearchHandler struct {
	*HandlerDeps
}

func NewSearchHandler(deps *HandlerDeps) *SearchHandler {
	return &SearchHandler{HandlerDeps: deps}
}

func (h *SearchHandler) Name() string {
	return "search"
}

func (h *SearchHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[SearchHandler.Handle] Begin search xhs")

	keywords := h.Config.Keywords
	maxNotes := h.Config.CrawlerMaxNotesCount
	pageSize := 20

	for _, keyword := range keywords {
		h.Logger.Info("[SearchHandler.Handle] Searching keyword: ", keyword)

		// 尝试加载断点
		var startPage int = 1
		var crawledCount int = 0
		cp, _ := h.Checkpoint.Load(h.Name(), keyword)
		if cp != nil {
			startPage = cp.CurrentPage
			crawledCount = cp.TotalCrawled
			h.Logger.Info("[SearchHandler.Handle] Resume from checkpoint, page: ", startPage)
		} else {
			cp = &crawler.Checkpoint{
				CrawlerType: h.Name(),
				Keyword:     keyword,
				CurrentPage: 1,
			}
		}

		page := startPage
		for crawledCount < maxNotes {
			h.Logger.Info("[SearchHandler.Handle] Searching page: ", page)

			// 搜索
			searchResp, err := h.Client.SearchNotesByKeyword(&xhsmodel.SearchRequest{
				Keyword:  keyword,
				Page:     page,
				PageSize: pageSize,
				SearchID: tools.GetSearchID(),
				Sort:     xhsmodel.SearchSortTypeGeneral,
				NoteType: xhsmodel.SearchNoteTypeAll,
			})
			if err != nil {
				h.Logger.Error("[SearchHandler.Handle] Search error: ", err)
				break
			}

			if !searchResp.HasMore || len(searchResp.Items) == 0 {
				h.Logger.Info("[SearchHandler.Handle] No more data")
				break
			}

			// 过滤有效帖子
			noteItems := make([]NoteItem, 0)
			for _, item := range searchResp.Items {
				if item.ModelType == "rec_query" || item.ModelType == "hot_query" {
					continue
				}
				noteItems = append(noteItems, NoteItem{
					NoteID:     item.ID,
					XsecToken:  item.XsecToken,
					XsecSource: "pc_feed",
				})
			}

			// 处理帖子
			processedCount, err := h.Processor.ProcessNotes(ctx, noteItems, keyword)
			if err != nil {
				h.Logger.Error("[SearchHandler.Handle] Process notes error: ", err)
			}

			// 处理评论
			if h.Config.EnableGetComments {
				noteIDs := make([]string, 0)
				xsecTokens := make([]string, 0)
				for _, item := range noteItems {
					noteIDs = append(noteIDs, item.NoteID)
					xsecTokens = append(xsecTokens, item.XsecToken)
				}
				h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
			}

			crawledCount += processedCount
			page++

			// 更新断点
			cp.CurrentPage = page
			cp.TotalCrawled = crawledCount
			h.Checkpoint.Save(cp)

			// 请求间隔
			if h.Config.CrawlerTimeSleep > 0 {
				time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
			}
		}
	}

	h.Logger.Info("[SearchHandler.Handle] Search completed")
	return nil
}

// ========== DetailHandler ==========

// DetailHandler 指定帖子爬取处理器
type DetailHandler struct {
	*HandlerDeps
}

func NewDetailHandler(deps *HandlerDeps) *DetailHandler {
	return &DetailHandler{HandlerDeps: deps}
}

func (h *DetailHandler) Name() string {
	return "detail"
}

func (h *DetailHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[DetailHandler.Handle] Begin get specified notes")

	noteIDs := h.Config.SpecifiedNoteIDs
	if len(noteIDs) == 0 {
		h.Logger.Warn("[DetailHandler.Handle] No note IDs specified")
		return nil
	}

	// 构建NoteItem列表
	noteItems := make([]NoteItem, 0, len(noteIDs))
	for _, noteID := range noteIDs {
		noteItems = append(noteItems, NoteItem{
			NoteID:     noteID,
			XsecToken:  "", // Detail模式可能没有token
			XsecSource: "pc_note_detail",
		})
	}

	// 处理帖子
	_, err := h.Processor.ProcessNotes(ctx, noteItems, "")
	if err != nil {
		h.Logger.Error("[DetailHandler.Handle] Process notes error: ", err)
		return err
	}

	// 处理评论
	if h.Config.EnableGetComments {
		xsecTokens := make([]string, len(noteIDs))
		h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
	}

	h.Logger.Info("[DetailHandler.Handle] Detail completed")
	return nil
}

// ========== CreatorHandler ==========

// CreatorHandler 创作者爬取处理器
type CreatorHandler struct {
	*HandlerDeps
}

func NewCreatorHandler(deps *HandlerDeps) *CreatorHandler {
	return &CreatorHandler{HandlerDeps: deps}
}

func (h *CreatorHandler) Name() string {
	return "creator"
}

func (h *CreatorHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[CreatorHandler.Handle] Begin get creator notes")

	creatorIDs := h.Config.SpecifiedCreatorIDs
	if len(creatorIDs) == 0 {
		h.Logger.Warn("[CreatorHandler.Handle] No creator IDs specified")
		return nil
	}

	for _, creatorID := range creatorIDs {
		h.Logger.Info("[CreatorHandler.Handle] Processing creator: ", creatorID)

		// 获取创作者信息
		creatorInfo, err := h.Client.GetCreatorInfo(creatorID, "", "pc_user")
		if err != nil {
			h.Logger.Error("[CreatorHandler.Handle] Get creator info error: ", err)
			continue
		}

		// 保存创作者信息
		h.Processor.ProcessCreator(ctx, creatorInfo)

		// 获取创作者帖子
		cursor := ""
		pageSize := 30
		crawledCount := 0
		maxNotes := h.Config.CrawlerMaxNotesCount

		for crawledCount < maxNotes {
			notesResp, err := h.Client.GetCreatorNotes(creatorID, cursor, "", "pc_user", pageSize)
			if err != nil {
				h.Logger.Error("[CreatorHandler.Handle] Get creator notes error: ", err)
				break
			}

			if len(notesResp.Notes) == 0 {
				break
			}

			// 构建NoteItem列表
			noteItems := make([]NoteItem, 0)
			for _, note := range notesResp.Notes {
				noteItems = append(noteItems, NoteItem{
					NoteID:     note.NoteID,
					XsecToken:  note.XsecToken,
					XsecSource: "pc_user",
				})
			}

			// 处理帖子
			processedCount, _ := h.Processor.ProcessNotes(ctx, noteItems, "")
			crawledCount += processedCount

			// 处理评论
			if h.Config.EnableGetComments {
				noteIDs := make([]string, 0)
				xsecTokens := make([]string, 0)
				for _, item := range noteItems {
					noteIDs = append(noteIDs, item.NoteID)
					xsecTokens = append(xsecTokens, item.XsecToken)
				}
				h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
			}

			cursor = notesResp.Cursor
			if !notesResp.HasMore {
				break
			}

			// 请求间隔
			if h.Config.CrawlerTimeSleep > 0 {
				time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
			}
		}
	}

	h.Logger.Info("[CreatorHandler.Handle] Creator completed")
	return nil
}

// ========== HomefeedHandler ==========

// HomefeedHandler 首页推荐爬取处理器
type HomefeedHandler struct {
	*HandlerDeps
}

func NewHomefeedHandler(deps *HandlerDeps) *HomefeedHandler {
	return &HomefeedHandler{HandlerDeps: deps}
}

func (h *HomefeedHandler) Name() string {
	return "homefeed"
}

func (h *HomefeedHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[HomefeedHandler.Handle] Begin get homefeed notes")

	cursor := ""
	noteIndex := 0
	noteNum := 18
	crawledCount := 0
	maxNotes := h.Config.CrawlerMaxNotesCount

	for crawledCount < maxNotes {
		h.Logger.Info("[HomefeedHandler.Handle] Getting homefeed, index: ", noteIndex)

		resp, err := h.Client.GetHomefeedNotes(xhsmodel.FeedTypeRecommend, cursor, noteIndex, noteNum)
		if err != nil {
			h.Logger.Error("[HomefeedHandler.Handle] Get homefeed error: ", err)
			break
		}

		if len(resp.Items) == 0 {
			h.Logger.Info("[HomefeedHandler.Handle] No more data")
			break
		}

		// 构建NoteItem列表
		noteItems := make([]NoteItem, 0)
		for _, item := range resp.Items {
			if item.NoteCard.NoteID == "" {
				continue
			}
			noteItems = append(noteItems, NoteItem{
				NoteID:     item.NoteCard.NoteID,
				XsecToken:  item.XsecToken,
				XsecSource: "pc_feed",
			})
		}

		// 处理帖子
		processedCount, _ := h.Processor.ProcessNotes(ctx, noteItems, "homefeed")
		crawledCount += processedCount

		// 处理评论
		if h.Config.EnableGetComments {
			noteIDs := make([]string, 0)
			xsecTokens := make([]string, 0)
			for _, item := range noteItems {
				noteIDs = append(noteIDs, item.NoteID)
				xsecTokens = append(xsecTokens, item.XsecToken)
			}
			h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
		}

		cursor = resp.CursorScore
		noteIndex += len(resp.Items)

		// 请求间隔
		if h.Config.CrawlerTimeSleep > 0 {
			time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
		}
	}

	h.Logger.Info("[HomefeedHandler.Handle] Homefeed completed")
	return nil
}
