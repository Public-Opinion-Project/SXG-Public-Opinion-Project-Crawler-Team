// internal/xhs/processor.go
package xhs

import (
	"context"
	"strings"
	"sync/atomic"
	"time"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	xhsmodel "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models/xiaohongshu"
	xhsclient "github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service/xhs"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
)

// Processor 数据处理器
type Processor struct {
	client     *xhsclient.Client
	store      Store
	workerPool *worker.Pool
	config     *config.Config
	logger     *tools.Logger
}

// NewProcessor 创建处理器
func NewProcessor(client *xhsclient.Client, store Store, workerPool *worker.Pool, cfg *config.Config) *Processor {
	return &Processor{
		client:     client,
		store:      store,
		workerPool: workerPool,
		config:     cfg,
		logger:     tools.GetLogger(),
	}
}

// ProcessNotes 批量处理帖子
func (p *Processor) ProcessNotes(ctx context.Context, noteItems []NoteItem, sourceKeyword string) (int, error) {
	if len(noteItems) == 0 {
		return 0, nil
	}

	p.logger.Info("[Processor.ProcessNotes] Processing ", len(noteItems), " notes")

	var successCount int32
	tasks := make([]worker.Task, 0, len(noteItems))

	for _, item := range noteItems {
		noteItem := item // 捕获变量
		tasks = append(tasks, func(ctx context.Context) error {
			err := p.processOneNote(ctx, noteItem, sourceKeyword)
			if err == nil {
				atomic.AddInt32(&successCount, 1)
			}
			return err
		})
	}

	errs := p.workerPool.Submit(ctx, tasks)
	if len(errs) > 0 {
		p.logger.Error("[Processor.ProcessNotes] Failed count: ", len(errs))
	}

	return int(successCount), nil
}

// processOneNote 处理单个帖子
func (p *Processor) processOneNote(ctx context.Context, item NoteItem, sourceKeyword string) error {
	// 检查是否已存在
	exists, _ := p.store.NoteExists(ctx, item.NoteID)
	if exists {
		p.logger.Info("[Processor.processOneNote] Note already exists: ", item.NoteID)
		return nil
	}

	// 获取帖子详情（HTML优先）
	noteDetail, err := p.client.GetNoteDetailFromHtml(item.NoteID, item.XsecToken, item.XsecSource)
	if err != nil {
		p.logger.Warn("[Processor.processOneNote] Get from HTML failed, try API: ", item.NoteID)
		noteDetail, err = p.client.GetNoteDetailFromApi(item.NoteID, item.XsecToken, item.XsecSource)
		if err != nil {
			p.logger.Error("[Processor.processOneNote] Get note detail failed: ", item.NoteID, err)
			return err
		}
	}

	// 转换为存储模型
	note := p.convertNoteDetailToNote(noteDetail)
	note.SourceKeyword = sourceKeyword
	note.NoteURL = "https://www.xiaohongshu.com/explore/" + item.NoteID

	// 保存
	if err := p.store.SaveNote(ctx, note); err != nil {
		p.logger.Error("[Processor.processOneNote] Save note failed: ", item.NoteID, err)
		return err
	}

	p.logger.Info("[Processor.processOneNote] Saved note: ", item.NoteID)
	return nil
}

// convertNoteDetailToNote 将API响应转换为存储模型
func (p *Processor) convertNoteDetailToNote(noteDetail *xhsmodel.NoteDetail) *Note {
	now := time.Now().Unix()

	// 获取图片列表
	imgList := make([]string, 0)
	for _, img := range noteDetail.ImageList {
		imgList = append(imgList, img.URL)
	}

	// 获取标签列表
	tagList := make([]string, 0)
	for _, tag := range noteDetail.TagList {
		if tag.Type == "topic" {
			tagList = append(tagList, tag.Name)
		}
	}

	// 获取视频URL
	videoURL := ""
	if noteDetail.Type == "video" {
		originVideoKey := noteDetail.Video.Consumer.OriginVideoKey
		if originVideoKey != "" {
			videoURL = "http://sns-video-bd.xhscdn.com/" + originVideoKey
		} else if len(noteDetail.Video.Media.Stream.H264) > 0 {
			videoURL = noteDetail.Video.Media.Stream.H264[0].MasterUrl
		}
	}

	return &Note{
		NoteID:         noteDetail.NoteId,
		UserID:         noteDetail.User.UserID,
		Nickname:       noteDetail.User.Nickname,
		Avatar:         noteDetail.User.Avatar,
		IPLocation:     noteDetail.IpLocation,
		AddTs:          now,
		LastModifyTs:   now,
		Type:           noteDetail.Type,
		Title:          noteDetail.Title,
		Desc:           noteDetail.Desc,
		VideoURL:       videoURL,
		Time:           noteDetail.Time,
		LastUpdateTime: noteDetail.LastUpdateTime,
		LikedCount:     noteDetail.InteractInfo.LikedCount,
		CollectedCount: noteDetail.InteractInfo.CollectedCount,
		CommentCount:   noteDetail.InteractInfo.CommentCount,
		ShareCount:     noteDetail.InteractInfo.ShareCount,
		ImageList:      strings.Join(imgList, ","),
		TagList:        strings.Join(tagList, ","),
	}
}

// ProcessComments 批量处理帖子评论
func (p *Processor) ProcessComments(ctx context.Context, noteIDs []string, xsecTokens []string) {
	if len(noteIDs) == 0 || !p.config.EnableGetComments {
		return
	}

	p.logger.Info("[Processor.ProcessComments] Processing comments for ", len(noteIDs), " notes")

	tasks := make([]worker.Task, 0, len(noteIDs))
	for i, noteID := range noteIDs {
		nid := noteID
		token := ""
		if i < len(xsecTokens) {
			token = xsecTokens[i]
		}

		tasks = append(tasks, func(ctx context.Context) error {
			return p.processNoteComments(ctx, nid, token)
		})
	}

	p.workerPool.Submit(ctx, tasks)
}

// processNoteComments 处理单个帖子的所有评论
func (p *Processor) processNoteComments(ctx context.Context, noteID, xsecToken string) error {
	cursor := ""
	totalComments := 0
	maxComments := p.config.PerNoteMaxComments
	if maxComments <= 0 {
		maxComments = 100 // 默认值
	}

	for totalComments < maxComments {
		// 获取一级评论
		resp, err := p.client.GetNoteComments(noteID, cursor, xsecToken)
		if err != nil {
			p.logger.Error("[Processor.processNoteComments] Get comments failed: ", noteID, err)
			return err
		}

		if len(resp.Comments) == 0 {
			break
		}

		// 保存评论
		for _, comment := range resp.Comments {
			commentModel := p.convertCommentToModel(noteID, &comment, "")
			p.store.SaveComment(ctx, commentModel)
			totalComments++

			// 获取子评论
			if p.config.EnableGetSubComments && comment.SubCommentCount != "0" {
				p.processSubComments(ctx, noteID, comment.ID, xsecToken)
			}
		}

		if !resp.HasMore || cursor == resp.Cursor {
			break
		}
		cursor = resp.Cursor
	}

	p.logger.Info("[Processor.processNoteComments] Processed ", totalComments, " comments for note: ", noteID)
	return nil
}

// processSubComments 处理子评论
func (p *Processor) processSubComments(ctx context.Context, noteID, rootCommentID, xsecToken string) {
	cursor := ""
	for {
		resp, err := p.client.GetNoteSubComments(noteID, rootCommentID, cursor, xsecToken, 10)
		if err != nil {
			break
		}

		if len(resp.Comments) == 0 {
			break
		}

		for _, comment := range resp.Comments {
			commentModel := p.convertCommentToModel(noteID, &comment, rootCommentID)
			p.store.SaveComment(ctx, commentModel)
		}

		if !resp.HasMore {
			break
		}
		cursor = resp.Cursor
	}
}

// convertCommentToModel 转换评论为存储模型
func (p *Processor) convertCommentToModel(noteID string, comment *xhsmodel.Comment, parentCommentID string) *NoteComment {
	now := time.Now().Unix()

	userID := ""
	nickname := ""
	avatar := ""
	if comment.UserInfo != nil {
		userID = comment.UserInfo.UserID
		nickname = comment.UserInfo.Nickname
		avatar = comment.UserInfo.Image
	}

	return &NoteComment{
		UserID:          userID,
		Nickname:        nickname,
		Avatar:          avatar,
		IPLocation:      comment.IPLocation,
		AddTs:           now,
		LastModifyTs:    now,
		CommentID:       comment.ID,
		CreateTime:      comment.CreateTime,
		NoteID:          noteID,
		Content:         comment.Content,
		SubCommentCount: comment.SubCommentCount,
		Pictures:        comment.Pictures,
		ParentCommentID: parentCommentID,
		LikeCount:       comment.LikeCount,
		NoteURL:         "https://www.xiaohongshu.com/explore/" + noteID,
	}
}

// ProcessCreator 处理创作者信息
func (p *Processor) ProcessCreator(ctx context.Context, creatorInfo *xhsmodel.CreatorInfo) error {
	if creatorInfo == nil {
		return nil
	}

	now := time.Now().Unix()
	creator := &Creator{
		UserID:       creatorInfo.UserID,
		Nickname:     creatorInfo.Nickname,
		Avatar:       creatorInfo.Avatar,
		IPLocation:   creatorInfo.IPLocation,
		AddTs:        now,
		LastModifyTs: now,
		Desc:         creatorInfo.Desc,
		Gender:       creatorInfo.Gender,
		Follows:      creatorInfo.Follows,
		Fans:         creatorInfo.Fans,
		Interaction:  creatorInfo.Interaction,
		TagList:      creatorInfo.TagList,
	}

	return p.store.SaveCreator(ctx, creator)
}
