package xhs

import (
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/constant"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo"
)

type Store interface {
	// StoreContent save content data
	StoreContent(data *Note) error

	// StoreComment save comment data
	StoreComment(data *NoteComment) error

	// StoreCreator save creator data
	StoreCreator(data *Creator) error
}

// NewXhsRepo new a xhs repo
func NewXhsRepo(config *config.Config) Store {
	switch config.SaveDataOption {
	case constant.SaveDataToDb:
		return NewStoreDb(repo.GetDB())
	default:
		// Only DB storage is supported in the new architecture
		panic("only 'db' save data option is supported")
	}
}
