package xhs

import (
	"errors"
	"gorm.io/gorm"
	"time"
)

type StoreDb struct {
	db *gorm.DB
}

// NewStoreDb new a store db
func NewStoreDb(db *gorm.DB) *StoreDb {
	return &StoreDb{
		db: db,
	}
}

// StoreContent save content data
func (s *StoreDb) StoreContent(data *Note) error {
	var existingNote Note
	result := s.db.Where("note_id = ?", data.NoteID).First(&existingNote)

	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		// new record, create directly
		data.AddTs = time.Now().Unix()
		data.LastModifyTs = time.Now().Unix()
		return s.db.Create(data).Error
	}

	// update existing record
	data.LastModifyTs = time.Now().Unix()
	return s.db.Model(&Note{}).Where("note_id = ?", data.NoteID).Updates(data).Error
}

// StoreComment save comment data
func (s *StoreDb) StoreComment(data *NoteComment) error {
	var existingComment NoteComment
	result := s.db.Where("comment_id = ?", data.CommentID).First(&existingComment)

	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		// new record, create directly
		data.AddTs = time.Now().Unix()
		data.LastModifyTs = time.Now().Unix()
		return s.db.Create(data).Error
	}

	// update existing record
	data.LastModifyTs = time.Now().Unix()
	return s.db.Model(&NoteComment{}).Where("comment_id = ?", data.CommentID).Updates(data).Error
}

// StoreCreator save creator data
func (s *StoreDb) StoreCreator(data *Creator) error {
	var existingCreator Creator
	result := s.db.Where("user_id = ?", data.UserID).First(&existingCreator)

	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		// new record, create directly
		data.AddTs = time.Now().Unix()
		data.LastModifyTs = time.Now().Unix()
		return s.db.Create(data).Error
	}

	// update existing record
	data.LastModifyTs = time.Now().Unix()
	return s.db.Model(&Creator{}).Where("user_id = ?", data.UserID).Updates(data).Error
}
