package xhs

type Note struct {
	ID             int    `json:"id" gorm:"column:id;primaryKey;autoIncrement"`
	UserID         string `json:"user_id" gorm:"column:user_id;not null"`
	Nickname       string `json:"nickname" gorm:"column:nickname"`
	Avatar         string `json:"avatar" gorm:"column:avatar"`
	IpLocation     string `json:"ip_location" gorm:"column:ip_location"`
	AddTs          int64  `json:"add_ts" gorm:"column:add_ts;not null"`
	LastModifyTs   int64  `json:"last_modify_ts" gorm:"column:last_modify_ts;not null"`
	NoteID         string `json:"note_id" gorm:"column:note_id;not null;index:idx_xhs_note_note_id_209457"`
	Type           string `json:"type" gorm:"column:type"`
	Title          string `json:"title" gorm:"column:title"`
	Desc           string `json:"desc" gorm:"column:desc;type:longtext"`
	VideoUrl       string `json:"video_url" gorm:"column:video_url;type:longtext"`
	Time           int64  `json:"time" gorm:"column:time;not null;index:idx_xhs_note_time_eaa910"`
	LastUpdateTime int64  `json:"last_update_time" gorm:"column:last_update_time;not null"`
	LikedCount     string `json:"liked_count" gorm:"column:liked_count"`
	CollectedCount string `json:"collected_count" gorm:"column:collected_count"`
	CommentCount   string `json:"comment_count" gorm:"column:comment_count"`
	ShareCount     string `json:"share_count" gorm:"column:share_count"`
	ImageList      string `json:"image_list" gorm:"column:image_list;type:longtext"`
	TagList        string `json:"tag_list" gorm:"column:tag_list;type:longtext"`
	NoteUrl        string `json:"note_url" gorm:"column:note_url"`
	SourceKeyword  string `json:"source_keyword" gorm:"column:source_keyword;default:''"`
}

// TableName set table name
func (Note) TableName() string {
	return "xhs_note"
}

type NoteComment struct {
	ID              int    `json:"id" gorm:"column:id;primaryKey;autoIncrement"`
	UserID          string `json:"user_id" gorm:"column:user_id;not null"`
	Nickname        string `json:"nickname" gorm:"column:nickname"`
	Avatar          string `json:"avatar" gorm:"column:avatar"`
	IpLocation      string `json:"ip_location" gorm:"column:ip_location"`
	AddTs           int64  `json:"add_ts" gorm:"column:add_ts;not null"`
	LastModifyTs    int64  `json:"last_modify_ts" gorm:"column:last_modify_ts;not null"`
	CommentID       string `json:"comment_id" gorm:"column:comment_id;not null;index:idx_xhs_note_co_comment_8e8349"`
	CreateTime      int64  `json:"create_time" gorm:"column:create_time;not null;index:idx_xhs_note_co_create__204f8d"`
	NoteID          string `json:"note_id" gorm:"column:note_id;not null"`
	Content         string `json:"content" gorm:"column:content;type:longtext;not null"`
	SubCommentCount int    `json:"sub_comment_count" gorm:"column:sub_comment_count;not null"`
	Pictures        string `json:"pictures" gorm:"column:pictures;type:varchar(512)"`
	ParentCommentID string `json:"parent_comment_id" gorm:"column:parent_comment_id"`
	LikeCount       int    `json:"like_count" gorm:"column:like_count;not null;default:0"`
}

// TableName set table name
func (NoteComment) TableName() string {
	return "xhs_note_comment"
}

type Creator struct {
	ID           int    `json:"id" gorm:"column:id;primaryKey;autoIncrement"`
	UserID       string `json:"user_id" gorm:"column:user_id;not null"`
	Nickname     string `json:"nickname" gorm:"column:nickname"`
	Avatar       string `json:"avatar" gorm:"column:avatar"`
	IpLocation   string `json:"ip_location" gorm:"column:ip_location"`
	AddTs        int64  `json:"add_ts" gorm:"column:add_ts;not null"`
	LastModifyTs int64  `json:"last_modify_ts" gorm:"column:last_modify_ts;not null"`
	Desc         string `json:"desc" gorm:"column:desc;type:longtext"`
	Gender       string `json:"gender" gorm:"column:gender;type:varchar(2)"`
	Follows      string `json:"follows" gorm:"column:follows"`
	Fans         string `json:"fans" gorm:"column:fans"`
	Interaction  string `json:"interaction" gorm:"column:interaction"`
	TagList      string `json:"tag_list" gorm:"column:tag_list;type:longtext"`
}

// TableName set table name
func (Creator) TableName() string {
	return "xhs_creator"
}
