package repo

import (
	"fmt"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var db *gorm.DB

func init() {
	if db == nil {
		db = NewDB()
	}
}

// NewDB new db
func NewDB() *gorm.DB {
	gConfig := config.GetConfig()
	mysqlConnectDsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		gConfig.DbConfig.RelationDbUser,
		gConfig.DbConfig.RelationDbPwd,
		gConfig.DbConfig.RelationDbHost,
		gConfig.DbConfig.RelationDbPort,
		gConfig.DbConfig.RelationDbName,
	)
	db, err := gorm.Open(mysql.Open(mysqlConnectDsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	return db
}

// GetDB get db
func GetDB() *gorm.DB {
	return db
}
