package accounts_cookies

import (
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"gorm.io/gorm"
)

type CrawlerCookiesAccount struct {
	ID               int64  `json:"id" gorm:"column:id;primaryKey;autoIncrement"`
	AccountName      string `json:"account_name" gorm:"column:account_name"`
	PlatformName     string `json:"platform_name" gorm:"column:platform_name"`
	Cookies          string `json:"cookies" gorm:"column:cookies"`
	CreateTime       string `json:"create_time" gorm:"column:create_time"`
	UpdateTime       string `json:"update_time" gorm:"column:update_time"`
	InvalidTimeStamp int64  `json:"invalid_time_stamp" gorm:"column:invalid_time_stamp"`
	Status           uint8  `json:"status" gorm:"column:status"`
}

// TableName set table name
func (CrawlerCookiesAccount) TableName() string {
	return "crawler_cookies_account"
}

type CookiesAccountRepo struct {
	db     *gorm.DB
	logger *tools.Logger
}

// NewCrawlerCookiesAccountRepo new a data repo
func NewCrawlerCookiesAccountRepo(db *gorm.DB, logger *tools.Logger) *CookiesAccountRepo {
	return &CookiesAccountRepo{
		db:     db,
		logger: logger,
	}
}

// ListCookiesAccountByStatus list all crawler cookies account
func (c *CookiesAccountRepo) ListCookiesAccountByStatus(status int) ([]*CrawlerCookiesAccount, error) {
	var accounts []*CrawlerCookiesAccount
	txDb := c.db.Model(&CrawlerCookiesAccount{}).Where("status = ?", status).Find(&accounts)
	if txDb.Error != nil {
		c.logger.Error("ListCookiesAccountByStatus failed", txDb.Error)
		return nil, txDb.Error
	}
	return accounts, nil
}
