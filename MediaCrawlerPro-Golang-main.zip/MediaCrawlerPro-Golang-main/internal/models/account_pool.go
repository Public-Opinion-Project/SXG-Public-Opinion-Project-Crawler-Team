package models

type AccountInfoModel struct {
	Id                int64  `json:"id" csv:"id"`
	AccountName       string `json:"account_name" csv:"account_name"`
	Cookies           string `json:"cookies" csv:"cookies"`
	PlatformName      string `json:"platform_name" csv:"platform_name"`
	Status            int    `json:"status" csv:"status"`
	InvalidTimeStamps int64  `json:"invalid_time_stamps" csv:"invalid_time_stamps"`
}

type AccountWithIpPoolModel struct {
	Account *AccountInfoModel
	IpInfo  *IpInfoModel
}
