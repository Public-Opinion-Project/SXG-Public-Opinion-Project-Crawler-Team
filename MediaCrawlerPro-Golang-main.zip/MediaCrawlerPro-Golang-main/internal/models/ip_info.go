package models

import "time"

type IpInfoModel struct {
	Ip            string `json:"ip"`
	Port          int    `json:"port"`
	User          string `json:"user"`
	Protocol      string `json:"protocol"`
	Password      string `json:"password"`
	ExpiredTimeTs int64  `json:"expired_time_ts"`
}

// Expired check if the ip info is expired
// if current timestamp is greater than invalid_time_stamps, return true, else return false
func (a *IpInfoModel) Expired() bool {
	return a.ExpiredTimeTs < time.Now().Unix()
}

// FormatProxyToString get the proxy string, eg: http://user:password@ip:port
func (a *IpInfoModel) FormatProxyToString() string {
	return a.Protocol + "://" + a.User + ":" + a.Password + "@" + a.Ip + ":" + string(rune(a.Port))
}
