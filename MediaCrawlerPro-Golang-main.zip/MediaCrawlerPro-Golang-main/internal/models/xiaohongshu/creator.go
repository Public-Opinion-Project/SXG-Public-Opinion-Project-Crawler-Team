package xiaohongshu

// CreatorInfo 创作者信息
type CreatorInfo struct {
	UserID      string `json:"user_id"`
	Nickname    string `json:"nickname"`
	Avatar      string `json:"avatar"`
	IPLocation  string `json:"ip_location"`
	Desc        string `json:"desc"`
	Gender      string `json:"gender"`
	Follows     string `json:"follows"`
	Fans        string `json:"fans"`
	Interaction string `json:"interaction"`
	TagList     string `json:"tag_list"`
}

// CreatorNotesResponse 创作者帖子列表响应
type CreatorNotesResponse struct {
	Cursor  string       `json:"cursor"`
	HasMore bool         `json:"has_more"`
	Notes   []CreatorNote `json:"notes"`
}

// CreatorNote 创作者的帖子
type CreatorNote struct {
	NoteID       string       `json:"note_id"`
	XsecToken    string       `json:"xsec_token"`
	DisplayTitle string       `json:"display_title"`
	Cover        ImageInfo    `json:"cover"`
	Type         string       `json:"type"`
	InteractInfo InteractInfo `json:"interact_info"`
	User         User         `json:"user"`
}
