package xiaohongshu

// FeedType 首页推荐类型
type FeedType string

const (
	FeedTypeRecommend FeedType = "homefeed_recommend"
)

// HomefeedResponse 首页推荐响应
type HomefeedResponse struct {
	Items       []HomefeedItem `json:"items"`
	CursorScore string         `json:"cursor_score"`
}

// HomefeedItem 首页推荐项
type HomefeedItem struct {
	ID        string           `json:"id"`
	ModelType string           `json:"model_type"`
	XsecToken string           `json:"xsec_token"`
	NoteCard  HomefeedNoteCard `json:"note_card"`
}

// HomefeedNoteCard 首页推荐的笔记卡片
type HomefeedNoteCard struct {
	NoteID       string       `json:"note_id"`
	DisplayTitle string       `json:"display_title"`
	Cover        ImageInfo    `json:"cover"`
	Type         string       `json:"type"`
	InteractInfo InteractInfo `json:"interact_info"`
	User         User         `json:"user"`
}

// HomefeedRequest 首页推荐请求
type HomefeedRequest struct {
	Category          string   `json:"category"`
	CursorScore       string   `json:"cursor_score"`
	ImageFormats      []string `json:"image_formats"`
	NeedFilterImage   bool     `json:"need_filter_image"`
	NeedNum           int      `json:"need_num"`
	NoteIndex         int      `json:"note_index"`
	Num               int      `json:"num"`
	RefreshType       int      `json:"refresh_type"`
	SearchKey         string   `json:"search_key"`
	UnreadBeginNoteID string   `json:"unread_begin_note_id"`
	UnreadEndNoteID   string   `json:"unread_end_note_id"`
	UnreadNoteCount   int      `json:"unread_note_count"`
}
