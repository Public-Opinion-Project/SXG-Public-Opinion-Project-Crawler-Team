package xiaohongshu

// UserSelfInfo 数据主体结构
type UserSelfInfo struct {
	Result       UserSelfResult      `json:"result"`
	BasicInfo    BasicInfoStruct     `json:"basic_info"`
	Interactions []InteractionStruct `json:"interactions"`
	Tags         []TagStruct         `json:"tags"`
	TabPublic    TabPublicStruct     `json:"tab_public"`
}

// UserSelfResult 结果信息结构
type UserSelfResult struct {
	Message string `json:"message"`
	Success bool   `json:"success"`
	Code    int    `json:"code"`
}

// BasicInfoStruct 基础信息结构
type BasicInfoStruct struct {
	ImageB     string `json:"imageb"`
	Nickname   string `json:"nickname"`
	Images     string `json:"images"`
	RedID      string `json:"red_id"`
	Gender     int    `json:"gender"`
	IPLocation string `json:"ip_location"`
	Desc       string `json:"desc"`
}

// InteractionStruct 互动信息结构
type InteractionStruct struct {
	Type  string `json:"type"`
	Name  string `json:"name"`
	Count string `json:"count"`
}

// TagStruct 标签结构
type TagStruct struct {
	Icon    string `json:"icon,omitempty"`
	Name    string `json:"name"`
	TagType string `json:"tagType"`
}

// TabPublicStruct 公开标签页结构
type TabPublicStruct struct {
	Collection      bool             `json:"collection"`
	CollectionBoard CollectionStruct `json:"collectionBoard"`
	CollectionNote  CollectionStruct `json:"collectionNote"`
}

// CollectionStruct 收藏相关结构
type CollectionStruct struct {
	Display bool `json:"display"`
	Lock    bool `json:"lock"`
	Count   int  `json:"count"`
}
