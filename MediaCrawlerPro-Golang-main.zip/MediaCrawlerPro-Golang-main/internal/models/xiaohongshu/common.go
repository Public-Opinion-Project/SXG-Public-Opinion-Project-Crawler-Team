package xiaohongshu

// Response generic response structure
type Response[T any] struct {
	Code    int    `json:"code"`
	Success bool   `json:"success"`
	Msg     string `json:"msg"`
	Data    T      `json:"data"`
}

// ImageInfo 图片详细信息
type ImageInfo struct {
	ImageScene string `json:"image_scene"`
	URL        string `json:"url"`
}

// InteractInfo 交互信息
type InteractInfo struct {
	CollectedCount string `json:"collected_count"`
	CommentCount   string `json:"comment_count"`
	ShareCount     string `json:"share_count"`
	Followed       bool   `json:"followed"`
	Relation       string `json:"relation"`
	Liked          bool   `json:"liked"`
	LikedCount     string `json:"liked_count"`
	Collected      bool   `json:"collected"`
}

// TagInfo 标签信息
type TagInfo struct {
	Id   string `json:"id"`
	Name string `json:"name"`
	Type string `json:"type"`
}

// User user info
type User struct {
	Nickname string `json:"nickname"`
	Avatar   string `json:"avatar"`
	UserID   string `json:"user_id"`
}
