package xiaohongshu

// CommentResponse 评论API响应
type CommentResponse struct {
	Comments []Comment `json:"comments"`
	Cursor   string    `json:"cursor"`
	HasMore  bool      `json:"has_more"`
}

// Comment 评论结构
type Comment struct {
	ID              string    `json:"id"`
	NoteID          string    `json:"note_id"`
	Content         string    `json:"content"`
	CreateTime      int64     `json:"create_time"`
	LikeCount       string    `json:"like_count"`
	SubCommentCount string    `json:"sub_comment_count"`
	Pictures        string    `json:"pictures"`
	TargetComment   *Comment  `json:"target_comment"`
	UserInfo        *UserInfo `json:"user_info"`
	IPLocation      string    `json:"ip_location"`
}

// UserInfo 用户信息（评论用）
type UserInfo struct {
	UserID   string `json:"user_id"`
	Nickname string `json:"nickname"`
	Image    string `json:"image"`
}
