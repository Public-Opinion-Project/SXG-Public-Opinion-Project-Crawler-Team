package bilibili

// SearchResponse 搜索响应
type SearchResponse struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    *SearchData `json:"data"`
}

type SearchData struct {
	NumResults int          `json:"numResults"`
	Page       int          `json:"page"`
	PageSize   int          `json:"pagesize"`
	Result     []SearchItem `json:"result"`
}

type SearchItem struct {
	Type        string `json:"type"`
	Aid         int64  `json:"aid"`
	Bvid        string `json:"bvid"`
	Title       string `json:"title"`
	Description string `json:"description"`
	Author      string `json:"author"`
	Mid         int64  `json:"mid"`
	Play        int64  `json:"play"`
	Favorites   int64  `json:"favorites"`
	VideoReview int64  `json:"video_review"`
	Like        int64  `json:"like"`
	Pubdate     int64  `json:"pubdate"`
	Duration    string `json:"duration"`
	Pic         string `json:"pic"`
	Tag         string `json:"tag"`
}

// VideoInfoResponse 视频详情响应
type VideoInfoResponse struct {
	Code    int        `json:"code"`
	Message string     `json:"message"`
	Data    *VideoInfo `json:"data"`
}

type VideoInfo struct {
	Bvid      string    `json:"bvid"`
	Aid       int64     `json:"aid"`
	Videos    int       `json:"videos"`
	Tid       int       `json:"tid"`
	Tname     string    `json:"tname"`
	Copyright int       `json:"copyright"`
	Pic       string    `json:"pic"`
	Title     string    `json:"title"`
	Pubdate   int64     `json:"pubdate"`
	Ctime     int64     `json:"ctime"`
	Desc      string    `json:"desc"`
	Duration  int64     `json:"duration"`
	Owner     Owner     `json:"owner"`
	Stat      VideoStat `json:"stat"`
	Dynamic   string    `json:"dynamic"`
}

type Owner struct {
	Mid  int64  `json:"mid"`
	Name string `json:"name"`
	Face string `json:"face"`
}

type VideoStat struct {
	Aid      int64 `json:"aid"`
	View     int64 `json:"view"`
	Danmaku  int64 `json:"danmaku"`
	Reply    int64 `json:"reply"`
	Favorite int64 `json:"favorite"`
	Coin     int64 `json:"coin"`
	Share    int64 `json:"share"`
	Like     int64 `json:"like"`
	NowRank  int64 `json:"now_rank"`
	HisRank  int64 `json:"his_rank"`
}

// CommentResponse 评论响应
type CommentResponse struct {
	Code    int          `json:"code"`
	Message string       `json:"message"`
	Data    *CommentData `json:"data"`
}

type CommentData struct {
	Cursor  CommentCursor `json:"cursor"`
	Replies []Comment     `json:"replies"`
}

type CommentCursor struct {
	AllCount   int                `json:"all_count"`
	IsBegin    bool               `json:"is_begin"`
	IsEnd      bool               `json:"is_end"`
	Mode       int                `json:"mode"`
	Next       int                `json:"next"`
	Pagination *CommentPagination `json:"pagination"`
}

type CommentPagination struct {
	Offset string `json:"offset"`
}

type Comment struct {
	Rpid         int64          `json:"rpid"`
	Oid          int64          `json:"oid"`
	Mid          int64          `json:"mid"`
	Root         int64          `json:"root"`
	Parent       int64          `json:"parent"`
	Count        int            `json:"count"`
	Rcount       int            `json:"rcount"`
	Like         int            `json:"like"`
	Ctime        int64          `json:"ctime"`
	Content      CommentContent `json:"content"`
	Member       CommentMember  `json:"member"`
	Replies      []Comment      `json:"replies"`
	ReplyControl *ReplyControl  `json:"reply_control"`
}

type CommentContent struct {
	Message string `json:"message"`
}

type CommentMember struct {
	Mid    string `json:"mid"`
	Uname  string `json:"uname"`
	Avatar string `json:"avatar"`
}

type ReplyControl struct {
	SubReplyCount     int    `json:"sub_reply_count"`
	SubReplyEntryText string `json:"sub_reply_entry_text"`
}

// UpInfoResponse UP主信息响应
type UpInfoResponse struct {
	Code    int     `json:"code"`
	Message string  `json:"message"`
	Data    *UpInfo `json:"data"`
}

type UpInfo struct {
	Mid       int64  `json:"mid"`
	Name      string `json:"name"`
	Sex       string `json:"sex"`
	Face      string `json:"face"`
	Sign      string `json:"sign"`
	Level     int    `json:"level"`
	Birthday  string `json:"birthday"`
	Follower  int64  `json:"-"` // 需要从 stat 接口获取
	Following int64  `json:"-"`
}

// UpStatResponse UP主统计响应
type UpStatResponse struct {
	Code    int     `json:"code"`
	Message string  `json:"message"`
	Data    *UpStat `json:"data"`
}

type UpStat struct {
	Follower  int64 `json:"follower"`
	Following int64 `json:"following"`
}

// SpaceVideoResponse 空间视频响应
type SpaceVideoResponse struct {
	Code    int             `json:"code"`
	Message string          `json:"message"`
	Data    *SpaceVideoData `json:"data"`
}

type SpaceVideoData struct {
	List           SpaceVideoList  `json:"list"`
	Page           SpaceVideoPage  `json:"page"`
	EpisodicButton *EpisodicButton `json:"episodic_button"`
}

type SpaceVideoList struct {
	Vlist []SpaceVideo `json:"vlist"`
}

type SpaceVideo struct {
	Aid         int64  `json:"aid"`
	Bvid        string `json:"bvid"`
	Title       string `json:"title"`
	Description string `json:"description"`
	Play        int64  `json:"play"`
	Comment     int64  `json:"comment"`
	Created     int64  `json:"created"`
	Pic         string `json:"pic"`
	Length      string `json:"length"`
	Author      string `json:"author"`
	Mid         int64  `json:"mid"`
}

type SpaceVideoPage struct {
	Pn    int `json:"pn"`
	Ps    int `json:"ps"`
	Count int `json:"count"`
}

type EpisodicButton struct {
	Text string `json:"text"`
	URI  string `json:"uri"`
}

// HomefeedResponse 首页推荐响应
type HomefeedResponse struct {
	Code    int           `json:"code"`
	Message string        `json:"message"`
	Data    *HomefeedData `json:"data"`
}

type HomefeedData struct {
	Item []HomefeedItem `json:"item"`
}

type HomefeedItem struct {
	Id       int64     `json:"id"`
	Bvid     string    `json:"bvid"`
	Cid      int64     `json:"cid"`
	Goto     string    `json:"goto"`
	Uri      string    `json:"uri"`
	Pic      string    `json:"pic"`
	Title    string    `json:"title"`
	Duration int64     `json:"duration"`
	Pubdate  int64     `json:"pubdate"`
	Owner    Owner     `json:"owner"`
	Stat     VideoStat `json:"stat"`
}
