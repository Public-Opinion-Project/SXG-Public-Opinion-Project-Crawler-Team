// internal/worker/pool.go
package worker

import (
	"context"
	"sync"
)

// Task 任务函数类型
type Task func(ctx context.Context) error

// Pool 基于channel的worker池
type Pool struct {
	size   int
	logger interface {
		Info(args ...interface{})
		Error(args ...interface{})
	}
}

// NewPool 创建worker池
func NewPool(size int) *Pool {
	if size <= 0 {
		size = 5
	}
	return &Pool{
		size: size,
	}
}

// SetLogger 设置日志器
func (p *Pool) SetLogger(logger interface {
	Info(args ...interface{})
	Error(args ...interface{})
}) {
	p.logger = logger
}

// Submit 提交任务并等待全部完成
func (p *Pool) Submit(ctx context.Context, tasks []Task) []error {
	if len(tasks) == 0 {
		return nil
	}

	var wg sync.WaitGroup
	taskCh := make(chan Task, len(tasks))
	errCh := make(chan error, len(tasks))

	// 启动workers
	for i := 0; i < p.size; i++ {
		go p.worker(ctx, &wg, taskCh, errCh)
	}

	// 提交任务
	for _, task := range tasks {
		wg.Add(1)
		taskCh <- task
	}
	close(taskCh)

	// 等待完成
	wg.Wait()
	close(errCh)

	// 收集错误
	return p.collectErrors(errCh)
}

// worker 工作协程
func (p *Pool) worker(ctx context.Context, wg *sync.WaitGroup, taskCh <-chan Task, errCh chan<- error) {
	for task := range taskCh {
		select {
		case <-ctx.Done():
			errCh <- ctx.Err()
			wg.Done()
			return
		default:
			if err := task(ctx); err != nil {
				errCh <- err
			}
			wg.Done()
		}
	}
}

// collectErrors 收集错误
func (p *Pool) collectErrors(errCh <-chan error) []error {
	var errs []error
	for err := range errCh {
		if err != nil {
			errs = append(errs, err)
		}
	}
	return errs
}

// Size 返回worker数量
func (p *Pool) Size() int {
	return p.size
}
