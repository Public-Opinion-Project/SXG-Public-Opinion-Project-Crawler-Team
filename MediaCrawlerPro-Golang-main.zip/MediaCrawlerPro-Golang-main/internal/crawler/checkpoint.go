// internal/crawler/checkpoint.go
package crawler

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// Checkpoint 断点数据结构
type Checkpoint struct {
	ID             string            `json:"id"`
	Platform       string            `json:"platform"`
	CrawlerType    string            `json:"crawler_type"`
	Keyword        string            `json:"keyword,omitempty"`
	CreatorID      string            `json:"creator_id,omitempty"`
	CurrentPage    int               `json:"current_page"`
	TotalCrawled   int               `json:"total_crawled"`
	CrawledNoteIDs []string          `json:"crawled_note_ids,omitempty"`
	UpdatedAt      int64             `json:"updated_at"`
	Extra          map[string]string `json:"extra,omitempty"`
}

// CheckpointManager 断点续爬管理器
type CheckpointManager struct {
	baseDir  string
	platform string
	mu       sync.RWMutex
}

// NewCheckpointManager 创建断点管理器
func NewCheckpointManager(platform string, baseDir string) *CheckpointManager {
	if baseDir == "" {
		baseDir = "data/checkpoints"
	}
	// 确保目录存在
	os.MkdirAll(baseDir, 0755)
	return &CheckpointManager{
		baseDir:  baseDir,
		platform: platform,
	}
}

// generateID 生成检查点ID
func (m *CheckpointManager) generateID(crawlerType, key string) string {
	timestamp := time.Now().Format("20060102150405")
	if key != "" {
		return fmt.Sprintf("%s_%s_%s_%s", m.platform, crawlerType, key, timestamp)
	}
	return fmt.Sprintf("%s_%s_%s", m.platform, crawlerType, timestamp)
}

// getFilePath 获取检查点文件路径
func (m *CheckpointManager) getFilePath(id string) string {
	return filepath.Join(m.baseDir, id+".json")
}

// Save 保存断点
func (m *CheckpointManager) Save(cp *Checkpoint) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if cp.ID == "" {
		cp.ID = m.generateID(cp.CrawlerType, cp.Keyword)
	}
	cp.UpdatedAt = time.Now().Unix()
	cp.Platform = m.platform

	data, err := json.MarshalIndent(cp, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal checkpoint failed: %w", err)
	}

	return os.WriteFile(m.getFilePath(cp.ID), data, 0644)
}

// Load 加载断点（按crawlerType和key查找最新的）
func (m *CheckpointManager) Load(crawlerType, key string) (*Checkpoint, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	pattern := filepath.Join(m.baseDir, fmt.Sprintf("%s_%s_%s_*.json", m.platform, crawlerType, key))
	if key == "" {
		pattern = filepath.Join(m.baseDir, fmt.Sprintf("%s_%s_*.json", m.platform, crawlerType))
	}

	matches, err := filepath.Glob(pattern)
	if err != nil {
		return nil, err
	}

	if len(matches) == 0 {
		return nil, nil
	}

	// 找最新的文件
	var latestFile string
	var latestTime time.Time
	for _, match := range matches {
		info, err := os.Stat(match)
		if err != nil {
			continue
		}
		if info.ModTime().After(latestTime) {
			latestTime = info.ModTime()
			latestFile = match
		}
	}

	if latestFile == "" {
		return nil, nil
	}

	return m.LoadByID(filepath.Base(latestFile[:len(latestFile)-5])) // 去掉.json后缀
}

// LoadByID 按ID加载断点
func (m *CheckpointManager) LoadByID(id string) (*Checkpoint, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	data, err := os.ReadFile(m.getFilePath(id))
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}

	var cp Checkpoint
	if err := json.Unmarshal(data, &cp); err != nil {
		return nil, fmt.Errorf("unmarshal checkpoint failed: %w", err)
	}

	return &cp, nil
}

// Clear 清除断点
func (m *CheckpointManager) Clear(id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	err := os.Remove(m.getFilePath(id))
	if os.IsNotExist(err) {
		return nil
	}
	return err
}

// AddCrawledNote 添加已爬取的笔记ID
func (m *CheckpointManager) AddCrawledNote(cp *Checkpoint, noteID string) {
	for _, id := range cp.CrawledNoteIDs {
		if id == noteID {
			return
		}
	}
	cp.CrawledNoteIDs = append(cp.CrawledNoteIDs, noteID)
}

// IsNoteCrawled 检查笔记是否已爬取
func (m *CheckpointManager) IsNoteCrawled(cp *Checkpoint, noteID string) bool {
	if cp == nil {
		return false
	}
	for _, id := range cp.CrawledNoteIDs {
		if id == noteID {
			return true
		}
	}
	return false
}
