package httpclient

import "time"

// ClientConfig request client config
type ClientConfig struct {
	// request client timeout
	TimeOut time.Duration

	// request client headers
	Headers map[string]string
}

// SetHeader set key value to headers
func (c *ClientConfig) SetHeader(key, value string) {
	c.Headers[key] = value
}

// GetHeader get value from headers by key
func (c *ClientConfig) GetHeader(key string) string {
	return c.Headers[key]
}

// GetCookie get cookie from headers
func (c *ClientConfig) GetCookie() string {
	return c.GetHeader("Cookie")
}

// GetHeaders get headers
func (c *ClientConfig) GetHeaders() map[string]string {
	return c.Headers
}
