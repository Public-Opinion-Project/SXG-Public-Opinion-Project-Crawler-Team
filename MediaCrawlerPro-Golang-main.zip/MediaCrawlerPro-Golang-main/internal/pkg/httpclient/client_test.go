package httpclient

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestNewHttpClientWithTimeout(t *testing.T) {
	client, err := NewHttpClient(10*time.Second, "")
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if client.client.Timeout != 10*time.Second {
		t.Errorf("expected %v, got %v", 10*time.Second, client.client.Timeout)
	}
}

func TestSetHeader(t *testing.T) {
	client, _ := NewHttpClient(10*time.Second, "")
	client.SetHeader("Content-Type", "application/json")
	if client.headers["Content-Type"] != "application/json" {
		t.Errorf("expected %s, got %s", "application/json", client.headers["Content-Type"])
	}
}

func TestGetRequest(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			t.Errorf("expected GET method, got %s", r.Method)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	client, _ := NewHttpClient(10*time.Second, "")
	resp, err := client.Get(server.URL)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected %d, got %d", http.StatusOK, resp.StatusCode)
	}
}

func TestPostRequest(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			t.Errorf("expected POST method, got %s", r.Method)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	client, _ := NewHttpClient(10*time.Second, "")
	resp, err := client.Post(server.URL, []byte(`{"key":"value"}`))
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected %d, got %d", http.StatusOK, resp.StatusCode)
	}
}

func TestDoRequestWithHeaders(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Content-Type") != "application/json" {
			t.Errorf("expected %s, got %s", "application/json", r.Header.Get("Content-Type"))
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	client, _ := NewHttpClient(10*time.Second, "")
	client.SetHeader("Content-Type", "application/json")
	resp, err := client.Get(server.URL)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected %d, got %d", http.StatusOK, resp.StatusCode)
	}
}
