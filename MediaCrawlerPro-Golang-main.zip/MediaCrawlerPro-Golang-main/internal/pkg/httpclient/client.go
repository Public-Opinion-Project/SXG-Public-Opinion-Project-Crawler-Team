package httpclient

import (
	"bytes"
	"fmt"
	"net/http"
	"net/url"
	"time"
)

// HttpClient 封装常用的HTTP客户端操作
type HttpClient struct {
	client  *http.Client
	headers map[string]string
}

// NewHttpClient 创建一个新的HttpClient实例
func NewHttpClient(timeout time.Duration, proxyStr string) (*HttpClient, error) {
	transport := &http.Transport{}

	// 如果设置了代理
	if proxyStr != "" {
		proxyURL, err := url.Parse(proxyStr)
		if err != nil {
			return nil, fmt.Errorf("failed to parse proxy URL: %v", err)
		}
		transport.Proxy = http.ProxyURL(proxyURL)
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   timeout,
	}

	return &HttpClient{
		client:  client,
		headers: make(map[string]string),
	}, nil
}

// SetHeader 设置一个全局的请求头
func (h *HttpClient) SetHeader(key, value string) {
	h.headers[key] = value
}

// Get 发起GET请求
func (h *HttpClient) Get(url string) (*http.Response, error) {
	return h.doRequest("GET", url, nil)
}

// Post 发起POST请求
func (h *HttpClient) Post(url string, data []byte) (*http.Response, error) {
	return h.doRequest("POST", url, data)
}

// doRequest 处理HTTP请求的通用方法
func (h *HttpClient) doRequest(method, url string, data []byte) (*http.Response, error) {
	var req *http.Request
	var err error

	if data != nil {
		req, err = http.NewRequest(method, url, bytes.NewBuffer(data))
	} else {
		req, err = http.NewRequest(method, url, nil)
	}
	if err != nil {
		return nil, err
	}

	// 设置全局请求头
	for key, value := range h.headers {
		req.Header.Set(key, value)
	}

	// 发送请求
	resp, err := h.client.Do(req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}
