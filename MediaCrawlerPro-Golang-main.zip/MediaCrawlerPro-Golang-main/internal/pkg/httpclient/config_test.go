package httpclient

import (
	"testing"
	"time"
)

func TestHeaderIsSetCorrectly(t *testing.T) {
	config := &ClientConfig{Headers: make(map[string]string)}
	config.SetHeader("Content-Type", "application/json")
	if config.GetHeader("Content-Type") != "application/json" {
		t.Errorf("expected %s, got %s", "application/json", config.GetHeader("Content-Type"))
	}
}

func TestHeaderIsUpdatedCorrectly(t *testing.T) {
	config := &ClientConfig{Headers: make(map[string]string)}
	config.SetHeader("Content-Type", "application/json")
	config.SetHeader("Content-Type", "text/plain")
	if config.GetHeader("Content-Type") != "text/plain" {
		t.Errorf("expected %s, got %s", "text/plain", config.GetHeader("Content-Type"))
	}
}

func TestHeaderIsRetrievedCorrectly(t *testing.T) {
	config := &ClientConfig{Headers: make(map[string]string)}
	config.SetHeader("Authorization", "Bearer token")
	if config.GetHeader("Authorization") != "Bearer token" {
		t.Errorf("expected %s, got %s", "Bearer token", config.GetHeader("Authorization"))
	}
}

func TestCookieHeaderIsRetrievedCorrectly(t *testing.T) {
	config := &ClientConfig{Headers: make(map[string]string)}
	config.SetHeader("Cookie", "sessionId=abc123")
	if config.GetCookie() != "sessionId=abc123" {
		t.Errorf("expected %s, got %s", "sessionId=abc123", config.GetCookie())
	}
}

func TestTimeoutIsSetCorrectly(t *testing.T) {
	config := &ClientConfig{TimeOut: 30 * time.Second}
	if config.TimeOut != 30*time.Second {
		t.Errorf("expected %v, got %v", 30*time.Second, config.TimeOut)
	}
}

func TestClientConfig_GetHeaders(t *testing.T) {
	config := &ClientConfig{Headers: make(map[string]string)}
	config.SetHeader("Content-Type", "application/json")
	config.SetHeader("Authorization", "Bearer token")

	headers := config.GetHeaders()
	if len(headers) != 2 {
		t.Errorf("expected %d, got %d", 2, len(headers))
	}

	if headers["Content-Type"] != "application/json" {
		t.Errorf("expected %s, got %s", "application/json", headers["Content-Type"])
	}

	if headers["Authorization"] != "Bearer token" {
		t.Errorf("expected %s, got %s", "Bearer token", headers["Authorization"])
	}
}
