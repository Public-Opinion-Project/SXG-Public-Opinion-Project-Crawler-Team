package proxy

import (
	"errors"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models"
	"github.com/google/wire"
	"github.com/samber/lo"
	"math/rand"
	"time"
)

var ProviderSet = wire.NewSet(NewIpPool, config.GetConfig)

type IpPool struct {
	IpPoolCount      int                   // IP代理池数量
	EnableValidateIp bool                  // 是否开启IP验证
	IpProvider       Provider              // Ip代理Provider接口
	ProxyList        []*models.IpInfoModel // IP代理列表
}

func NewIpPool(conf *config.Config, ipProvider Provider) (*IpPool, error) {
	ipPool := &IpPool{
		IpPoolCount:      conf.ProxyConfig.IpProxyPoolCount,
		EnableValidateIp: conf.ProxyConfig.EnableValidateIpProxy,
		IpProvider:       ipProvider,
	}
	err := ipPool.LoadProxies()
	if err != nil {
		return nil, err
	}
	return ipPool, nil
}

// LoadProxies load ip proxies from special provider brand name
func (i *IpPool) LoadProxies() error {
	ipList, err := i.IpProvider.GetProxies()
	if err != nil {
		// todo record log
		return err
	}
	i.ProxyList = ipList
	return nil
}

// validateProxy send an validate ip proxy request
func (i *IpPool) validateProxy(proxy *models.IpInfoModel) bool {

	return false
}

// GetProxy random get proxy from ip proxy pool
func (i *IpPool) GetProxy() (*models.IpInfoModel, error) {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	randomIndex := r.Intn(len(i.ProxyList))
	proxy := i.ProxyList[randomIndex]

	// ip取出来之后移除掉
	i.ProxyList = lo.DropByIndex(i.ProxyList, randomIndex)
	if i.EnableValidateIp {
		if !i.validateProxy(proxy) {
			return nil, errors.New("ip not available")
		}
	}
	return proxy, nil
}

// reloadProxies reload proxies
func (i *IpPool) reloadProxies() error {
	i.ProxyList = make([]*models.IpInfoModel, 0)
	return i.LoadProxies()
}

// MarkIpInvalid mark ip validates
func (i *IpPool) MarkIpInvalid(proxy *models.IpInfoModel) {
	i.IpProvider.MarkIpValidate(proxy)
	for index, p := range i.ProxyList {
		if p.Ip == proxy.Ip && p.User == proxy.User && p.Port == proxy.Port {
			i.ProxyList = lo.DropByIndex(i.ProxyList, index)
			break
		}
	}
}
