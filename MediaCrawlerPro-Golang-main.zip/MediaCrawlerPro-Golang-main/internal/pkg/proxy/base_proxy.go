package proxy

import (
	"encoding/json"
	"fmt"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/cache"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
)

type Provider interface {
	// GetProxies get proxies
	GetProxies() ([]*models.IpInfoModel, error)

	// MarkIpValidate mark ip validate
	MarkIpValidate(ip *models.IpInfoModel)
}

type IpCache struct {
	CacheClient cache.ICache
}

// SetIp set one ip to cache
func (i *IpCache) SetIp(ipKey string, ipValue string, ex int) error {
	return i.CacheClient.Set(ipKey, []byte(ipValue), ex)
}

// DeleteIp delete some ip
func (i *IpCache) DeleteIp(ipKey string) error {
	return i.CacheClient.Delete(ipKey)
}

// LoadAllIp load all ip from cache
func (i *IpCache) LoadAllIp(ProxyProviderBrandName string) ([]*models.IpInfoModel, error) {
	allIpList := make([]*models.IpInfoModel, 0)
	allIpKeys, err := i.CacheClient.Keys(fmt.Sprintf("%s_*", ProxyProviderBrandName))
	if err != nil {
		return allIpList, err
	}

	for _, ipKey := range allIpKeys {
		ipValue, err := i.CacheClient.Get(ipKey)
		if err != nil {
			// todo error log record
			return allIpList, err
		}

		ipValueInfo := models.IpInfoModel{}
		err = json.Unmarshal(ipValue, &ipValueInfo)
		if err != nil {
			// todo error log record
			return allIpList, err
		}

		ttl := i.CacheClient.Ttl(ipKey)
		if ttl <= 0 {
			continue
		}
		ipValueInfo.ExpiredTimeTs = tools.GetUnixTimeTs() + int64(ttl)
		allIpList = append(allIpList, &ipValueInfo)
	}
	return allIpList, nil
}
