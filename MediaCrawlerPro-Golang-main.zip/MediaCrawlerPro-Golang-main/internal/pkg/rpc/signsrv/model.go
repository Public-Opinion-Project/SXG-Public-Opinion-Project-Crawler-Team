package signsrv

type XhsSignResult struct {
	Xs         string `json:"x_s"`
	Xt         string `json:"x_t"`
	XsCommon   string `json:"x_s_common"`
	XB3TraceId string `json:"x_b3_trace_id"`
}

type XhsSignRequest struct {
	Uri     string `json:"uri"`
	Data    any    `json:"data"`
	Cookies string `json:"cookies"`
}

type XhsSignResponse struct {
	BizCode int            `json:"biz_code"`
	Msg     string         `json:"msg"`
	IsOk    bool           `json:"isok"`
	Result  *XhsSignResult `json:"data"`
}

type BilibiliSignResult struct {
	Wts  string `json:"wts"`
	WRid string `json:"w_rid"`
}

type BilibiliSignRequest struct {
	ReqData map[string]string `json:"req_data"`
	Cookies string            `json:"cookies"`
}

type BilibiliSignResponse struct {
	BizCode int                 `json:"biz_code"`
	Msg     string              `json:"msg"`
	IsOk    bool                `json:"isok"`
	Result  *BilibiliSignResult `json:"data"`
}
