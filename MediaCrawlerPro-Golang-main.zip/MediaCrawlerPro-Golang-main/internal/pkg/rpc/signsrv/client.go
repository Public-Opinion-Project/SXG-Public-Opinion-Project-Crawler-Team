package signsrv

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/httpclient"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/google/wire"
	"io"
	"net/http"
	"time"
)

const RequestTimeOut = 30 * time.Second

var ProviderSet = wire.NewSet(NewSignClient)

type Client struct {
	logger   *tools.Logger
	endPoint string
}

// NewSignClient create a new client
func NewSignClient(config *config.Config) *Client {
	return &Client{
		logger:   tools.GetLogger(),
		endPoint: fmt.Sprintf("http://%s:%d", config.SignSrvConfig.SignSrvHost, config.SignSrvConfig.SignSrvPort),
	}
}

// request do request
func (c *Client) request(method, uri string, data []byte, headers map[string]string) (string, error) {
	var (
		err      error
		response *http.Response
	)
	// create http client and set headers
	httpClient, err := httpclient.NewHttpClient(RequestTimeOut, "")
	if err != nil {
		c.logger.Error("[Client.request] create http client error: ", err)
		return "", err
	}
	for key, value := range headers {
		httpClient.SetHeader(key, value)
	}
	httpClient.SetHeader("Content-Type", "application/json")

	url := c.endPoint + uri

	// do request
	switch method {
	case http.MethodGet:
		response, err = httpClient.Get(url)
	case http.MethodPost:
		response, err = httpClient.Post(url, data)
	default:
		c.logger.Error("[Client.request] unsupported request method")
		panic("unsupported request method")
	}
	if err != nil {
		c.logger.Error("[Client.request] request error: ", err)
		return "", err
	}

	bodyBytes, err := io.ReadAll(response.Body)
	if err != nil {
		c.logger.Error("[Client.request] read response body error: ", err)
		return "", err
	}
	defer response.Body.Close()

	return string(bodyBytes), nil
}

// XhsSignServer xhs sign server
func (c *Client) XhsSignServer(signReq *XhsSignRequest) (*XhsSignResponse, error) {
	uri := "/signsrv/v1/xhs/sign"

	jsonBytes, err := json.Marshal(signReq)
	if err != nil {
		c.logger.Error("[XhsClient.XhsSignServer] marshal request data error: ", err)
		return nil, err
	}

	body, err := c.request(http.MethodPost, uri, jsonBytes, nil)
	if err != nil {
		c.logger.Error("[XhsClient.XhsSignServer] request error: ", err)
		return nil, err
	}

	signResp := &XhsSignResponse{}
	err = json.Unmarshal([]byte(body), signResp)
	if err != nil {
		c.logger.Error("[XhsClient.XhsSignServer] unmarshal response error: ", err)
		return nil, err
	}

	if !signResp.IsOk {
		c.logger.Error("[XhsClient.XhsSignServer] sign response error: ", signResp.Msg)
		return nil, errors.New(signResp.Msg)
	}

	return signResp, nil
}

// BilibiliSignServer bilibili sign server
func (c *Client) BilibiliSignServer(signReq *BilibiliSignRequest) (*BilibiliSignResponse, error) {
	uri := "/signsrv/v1/bilibili/sign"

	jsonBytes, err := json.Marshal(signReq)
	if err != nil {
		c.logger.Error("[BilibiliClient.BilibiliSignServer] marshal request data error: ", err)
		return nil, err
	}

	body, err := c.request(http.MethodPost, uri, jsonBytes, nil)
	if err != nil {
		c.logger.Error("[BilibiliClient.BilibiliSignServer] request error: ", err)
		return nil, err
	}

	signResp := &BilibiliSignResponse{}
	err = json.Unmarshal([]byte(body), signResp)
	if err != nil {
		c.logger.Error("[BilibiliClient.BilibiliSignServer] unmarshal response error: ", err)
		return nil, err
	}

	if !signResp.IsOk {
		c.logger.Error("[BilibiliClient.BilibiliSignServer] sign response error: ", signResp.Msg)
		return nil, errors.New(signResp.Msg)
	}

	return signResp, nil
}

// PongSignServer pong sign server
func (c *Client) PongSignServer() bool {
	uri := "/signsrv/pong"
	_, err := c.request(http.MethodGet, uri, nil, nil)
	if err != nil {
		c.logger.Error("[XhsClient.PongSignServer] request error: ", err)
		return false
	}
	return true
}
