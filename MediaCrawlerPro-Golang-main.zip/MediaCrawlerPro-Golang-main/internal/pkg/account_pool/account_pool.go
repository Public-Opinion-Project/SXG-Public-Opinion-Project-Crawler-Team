package account_pool

import (
	"errors"
	"fmt"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/constant"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/models"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/proxy"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/repo/accounts_cookies"
)

type AccountPool struct {
	platformName       string
	accountSaveType    string
	accountList        []*models.AccountInfoModel
	accountCookiesRepo *accounts_cookies.CookiesAccountRepo
}

// NewAccountPool create account pool
func NewAccountPool(config *config.Config, accountCookiesRepo *accounts_cookies.CookiesAccountRepo) *AccountPool {
	accountPool := &AccountPool{
		platformName:       config.Platform,
		accountSaveType:    config.AccountPoolSaveType,
		accountCookiesRepo: accountCookiesRepo,
	}
	accountPool.initialize()
	return accountPool
}

func (a *AccountPool) initialize() {
	switch a.accountSaveType {
	case constant.AccountSaveTypeExcel:
		a.loadAccountFromExcel()
	case constant.AccountSaveTypeDb:
		a.loadAccountFromDb()
	default:
		panic(fmt.Sprintf("不支持的账号池保存类型: %s", a.accountSaveType))
	}
}

func (a *AccountPool) loadAccountFromExcel() {
	// todo load account from excel
}

// loadAccountFromDb load account from db
func (a *AccountPool) loadAccountFromDb() {
	cookiesAccounts, err := a.accountCookiesRepo.ListCookiesAccountByStatus(constant.AccountStatusNormal)
	if err != nil {
		panic(fmt.Sprintf("加载账号池失败: %s", err.Error()))
	}
	for _, v := range cookiesAccounts {
		a.addCount(&models.AccountInfoModel{
			Id:                v.ID,
			AccountName:       v.AccountName,
			Cookies:           v.Cookies,
			PlatformName:      v.PlatformName,
			Status:            int(v.Status),
			InvalidTimeStamps: v.InvalidTimeStamp,
		})
	}
}

// addCount add account count
func (a *AccountPool) addCount(accountInfoModel *models.AccountInfoModel) {
	a.accountList = append(a.accountList, accountInfoModel)
}

// GetActiveAccount get active account
func (a *AccountPool) GetActiveAccount() (*models.AccountInfoModel, error) {
	for len(a.accountList) > 0 {
		account := a.accountList[0]
		if account.Status == constant.AccountStatusNormal {
			return account, nil
		}
		a.accountList = a.accountList[1:]
	}
	return nil, errors.New("账号池中没有可用账号")
}

// UpdateAccountStatus get account list
func (a *AccountPool) UpdateAccountStatus(account *models.AccountInfoModel, status int) {
	for _, v := range a.accountList {
		if v.Id == account.Id {
			v.Status = status
			// todo update account status in db
			return
		}
	}
}

type AccountWithIpPool struct {
	AccountPool *AccountPool
	ProxyIpPool *proxy.IpPool
}

func NewAccountWithIpPool(accountPool *AccountPool) *AccountWithIpPool {
	return &AccountWithIpPool{
		AccountPool: accountPool,
	}
}

// GetAccountWithIpInfo get account with ip info
func (a *AccountWithIpPool) GetAccountWithIpInfo() (*models.AccountWithIpPoolModel, error) {
	account, err := a.AccountPool.GetActiveAccount()
	if err != nil {
		return nil, err
	}

	// todo get ip info
	return &models.AccountWithIpPoolModel{
		Account: account,
	}, nil
}

// MarkAccountInvalid mark account invalid
func (a *AccountWithIpPool) MarkAccountInvalid(account *models.AccountWithIpPoolModel) {
	a.AccountPool.UpdateAccountStatus(account.Account, constant.AccountStatusInvalid)
}

// MarkIpInvalid mark ip invalid
func (a *AccountWithIpPool) MarkIpInvalid(ipInfo *models.IpInfoModel) {
	if ipInfo != nil {
		a.ProxyIpPool.MarkIpInvalid(ipInfo)
	}
}
