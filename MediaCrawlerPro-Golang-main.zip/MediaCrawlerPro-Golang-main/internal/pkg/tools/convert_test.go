package tools

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

// 测试 RecursiveConvertKeysToSnakeCase 函数
func TestRecursiveConvertKeysToSnakeCase(t *testing.T) {
	// 测试用例：单层 map
	input := map[string]interface{}{
		"FirstName": "John",
		"LastName":  "Doe",
	}
	expected := map[string]interface{}{
		"first_name": "John",
		"last_name":  "Doe",
	}
	result := RecursiveConvertKeysToSnakeCase(input)
	assert.Equal(t, expected, result, "单层 map 转换失败")

	// 测试用例：嵌套结构
	nestedInput := map[string]interface{}{
		"UserInfo": map[string]interface{}{
			"UserName": "johndoe",
			"UserAge":  30,
		},
	}
	nestedExpected := map[string]interface{}{
		"user_info": map[string]interface{}{
			"user_name": "johndoe",
			"user_age":  30,
		},
	}
	nestedResult := RecursiveConvertKeysToSnakeCase(nestedInput)
	assert.Equal(t, nestedExpected, nestedResult, "嵌套结构 map 转换失败")
}
