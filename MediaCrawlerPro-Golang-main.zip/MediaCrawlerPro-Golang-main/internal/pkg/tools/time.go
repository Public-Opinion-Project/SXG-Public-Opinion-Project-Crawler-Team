package tools

import "time"

func GetUnixTimeTs() int64 {
	return time.Now().Unix()
}
