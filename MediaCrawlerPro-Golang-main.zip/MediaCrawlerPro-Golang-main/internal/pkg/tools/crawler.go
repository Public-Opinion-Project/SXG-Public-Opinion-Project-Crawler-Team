package tools

import (
	"crypto/rand"
	"fmt"
	"math/big"
	"net/url"
	"strings"
	"time"
)

// EncodeQueryParams encodes a map of query parameters into a URL-encoded string.
func EncodeQueryParams(params map[string]any) string {
	values := url.Values{}
	for key, value := range params {
		values.Add(key, fmt.Sprintf("%v", value))
	}
	return values.Encode()
}

// EncodeQueryParamsStr encodes a map[string]string of query parameters into a URL-encoded string.
func EncodeQueryParamsStr(params map[string]string) string {
	values := url.Values{}
	for k, v := range params {
		values.Add(k, v)
	}
	return values.Encode()
}

const alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

// Base36encode converts a big integer to a base36 string
func Base36encode(number *big.Int) string {
	if number.Cmp(big.NewInt(0)) == 0 {
		return "0"
	}

	var base36 strings.Builder
	zero := big.NewInt(0)
	base := big.NewInt(36)
	num := new(big.Int).Set(number)

	// Convert to base36
	for num.Cmp(zero) > 0 {
		mod := new(big.Int)
		num.DivMod(num, base, mod)
		base36.WriteByte(alphabet[mod.Int64()])
	}

	// Reverse the string
	bytes := []byte(base36.String())
	for i, j := 0, len(bytes)-1; i < j; i, j = i+1, j-1 {
		bytes[i], bytes[j] = bytes[j], bytes[i]
	}

	return string(bytes)
}

// GetSearchID generates a unique search ID
func GetSearchID() string {
	// Get current timestamp in nanoseconds for more precision
	timestamp := time.Now().UnixNano()

	// Create big.Int for timestamp and shift left 64 bits
	e := big.NewInt(timestamp)
	e.Lsh(e, 64)

	// Generate cryptographically secure random number between 0 and 2147483646
	_max := big.NewInt(2147483647)
	t, _ := rand.Int(rand.Reader, _max)

	// Add the random number to the shifted timestamp
	e.Add(e, t)

	return Base36encode(e)
}
