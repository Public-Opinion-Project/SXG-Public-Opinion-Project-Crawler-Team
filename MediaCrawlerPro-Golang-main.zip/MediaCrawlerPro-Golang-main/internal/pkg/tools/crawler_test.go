package tools

import (
	"testing"
)

func TestEncodeQueryParamsEmptyParams(t *testing.T) {
	params := map[string]any{}
	expected := ""
	result := EncodeQueryParams(params)
	if result != expected {
		t.Errorf("expected %s, got %s", expected, result)
	}
}

func TestEncodeQueryParamsSingleParam(t *testing.T) {
	params := map[string]any{"key": "value"}
	expected := "key=value"
	result := EncodeQueryParams(params)
	if result != expected {
		t.Errorf("expected %s, got %s", expected, result)
	}
}

func TestEncodeQueryParamsMultipleParams(t *testing.T) {
	params := map[string]any{"key1": "value1", "key2": "value2"}
	expected := "key1=value1&key2=value2"
	result := EncodeQueryParams(params)
	if result != expected {
		t.Errorf("expected %s, got %s", expected, result)
	}
}

func TestEncodeQueryParamsSpecialCharacters(t *testing.T) {
	params := map[string]any{"key": "value with spaces", "key2": "value/with/slash"}
	expected := "key=value+with+spaces&key2=value%2Fwith%2Fslash"
	result := EncodeQueryParams(params)
	if result != expected {
		t.Errorf("expected %s, got %s", expected, result)
	}
}

func TestEncodeQueryParamsNumericValues(t *testing.T) {
	params := map[string]any{"key": 123, "key2": 45.67}
	expected := "key=123&key2=45.67"
	result := EncodeQueryParams(params)
	if result != expected {
		t.Errorf("expected %s, got %s", expected, result)
	}
}

func TestGetSearchID(t *testing.T) {
	searchId := GetSearchID()
	t.Log(searchId)
}
