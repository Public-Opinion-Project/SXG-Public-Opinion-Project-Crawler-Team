package tools

import (
	"github.com/iancoleman/strcase"
)

// RecursiveConvertKeysToSnakeCase 递归地将所有 key 转换成下划线格式
func RecursiveConvertKeysToSnakeCase(data interface{}) interface{} {
	switch v := data.(type) {
	case map[string]interface{}:
		newMap := make(map[string]interface{})
		for key, value := range v {
			// 使用 strcase 将 key 转换为 snake_case
			newKey := strcase.ToSnake(key)
			newMap[newKey] = RecursiveConvertKeysToSnakeCase(value)
		}
		return newMap
	case []interface{}:
		// 递归处理 slice 中的每一个元素
		for i, item := range v {
			v[i] = RecursiveConvertKeysToSnakeCase(item)
		}
		return v
	default:
		return v
	}
}
