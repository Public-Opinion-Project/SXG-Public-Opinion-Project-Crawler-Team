package tools

import (
	"fmt"
	"io"
	"log"
	"os"
	"runtime"
	"strings"
	"time"
)

type Logger struct {
	logger   *log.Logger
	logLevel int
}

// 日志级别
const (
	DEBUG = iota
	INFO
	WARN
	ERROR
)

// GetLogger 获取一个Logger实例
func GetLogger() *Logger {
	return NewLogger(io.Writer(os.Stdout), "MediaCrawlerPro-Golang", 0, DEBUG)
}

// NewLogger 创建一个新的Logger
func NewLogger(out io.Writer, prefix string, flag int, level int) *Logger {
	// 使用空前缀初始化logger,防止重复前缀
	return &Logger{
		logger:   log.New(out, "", 0),
		logLevel: level,
	}
}

func (l *Logger) SetLogLevel(level int) {
	l.logLevel = level
}

func (l *Logger) logMessage(level string, v ...interface{}) {
	_, file, line, ok := runtime.Caller(2)
	if ok {
		shortFile := file[strings.LastIndex(file, "/")+1:]
		timestamp := time.Now().Format("2006-01-02 15:04:05")
		message := fmt.Sprintf("%s MediaCrawlerPro-Golang %s (%s:%d) - %s",
			timestamp,
			level,
			shortFile,
			line,
			fmt.Sprint(v...))
		l.logger.Output(2, message)
	}
}

func (l *Logger) Debug(v ...interface{}) {
	if l.logLevel <= DEBUG {
		l.logMessage("DEBUG", v...)
	}
}

func (l *Logger) Info(v ...interface{}) {
	if l.logLevel <= INFO {
		l.logMessage("INFO", v...)
	}
}

func (l *Logger) Warn(v ...interface{}) {
	if l.logLevel <= WARN {
		l.logMessage("WARN", v...)
	}
}

func (l *Logger) Error(v ...interface{}) {
	if l.logLevel <= ERROR {
		l.logMessage("ERROR", v...)
	}
}

func (l *Logger) SetOutput(w io.Writer) {
	l.logger.SetOutput(w)
}

func (l *Logger) SetFlags(flag int) {
	l.logger.SetFlags(flag)
}
