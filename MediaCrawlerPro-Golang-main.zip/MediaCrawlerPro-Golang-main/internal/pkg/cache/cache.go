package cache

type ICache interface {
	Get(key string) ([]byte, error)
	Set(key string, value []byte, ex int) error
	Delete(key string) error
	Ttl(key string) int
	Keys(pattern string) ([]string, error)
}
