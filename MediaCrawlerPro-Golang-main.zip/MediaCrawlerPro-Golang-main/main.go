package main

import (
	"fmt"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/cmd"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/service"
)

func main() {
	// 初始化配置
	config.InitConfig()

	// 从命令行获取参数
	if err := cmd.RootCmd().Execute(); err != nil {
		fmt.Println("init command args err:", err)
	}

	// 初始化爬虫服务
	crawlerService := service.NewCrawlerService(config.GetConfig())
	crawlerService.Initialize()
	crawlerService.Start()
}
