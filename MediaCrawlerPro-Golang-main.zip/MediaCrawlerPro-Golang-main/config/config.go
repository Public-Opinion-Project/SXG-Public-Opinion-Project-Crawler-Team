package config

import (
	"fmt"
	"log"
	"strconv"

	"github.com/spf13/viper"
)

var (
	Obj *Config = nil
)

func InitConfig() {
	viper.SetConfigName("config")  // 配置文件名称(无扩展名)
	viper.SetConfigType("yml")     // 如果配置文件的名称中没有扩展名，则需要配置此项
	viper.AddConfigPath("config/") // 查找配置文件所在的路径
	err := viper.ReadInConfig()    // 查找并读取配置文件
	if err != nil {
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}

	err = viper.Unmarshal(&Obj)
	if err != nil {
		log.Fatalf("Unable to decode into struct, %v", err)
	}

	// 将环境变量中的敏感信息覆盖到配置中
	if Obj.DbConfig == nil {
		Obj.DbConfig = &DbConfig{}
	}

	// 设置关系型数据库配置（从环境变量）
	Obj.DbConfig.RelationDbPwd = RelationDbPwd
	Obj.DbConfig.RelationDbUser = RelationDbUser
	Obj.DbConfig.RelationDbHost = RelationDbHost
	Obj.DbConfig.RelationDbName = RelationDbName

	// 将端口字符串转换为整数
	if port, err := strconv.Atoi(RelationDbPort); err == nil {
		Obj.DbConfig.RelationDbPort = port
	} else {
		log.Printf("Error converting port to integer: %v", err)
		// 可以设置一个默认端口
		Obj.DbConfig.RelationDbPort = 3306
	}

	// 设置Redis配置（从环境变量）
	Obj.DbConfig.RedisDbHost = RedisDbHost
	Obj.DbConfig.RedisDbPwd = RedisDbPwd

	// 转换Redis端口
	if redisPort, err := strconv.Atoi(RedisDbPort); err == nil {
		Obj.DbConfig.RedisDbPort = redisPort
	} else {
		log.Printf("Error converting Redis port to integer: %v", err)
		Obj.DbConfig.RedisDbPort = 6379
	}

	// 转换Redis数据库编号
	if redisDbNum, err := strconv.ParseUint(RedisDbNum, 10, 32); err == nil {
		Obj.DbConfig.RedisDbNum = uint(redisDbNum)
	} else {
		log.Printf("Error converting Redis DB number to uint: %v", err)
		Obj.DbConfig.RedisDbNum = 0
	}

	// 打印读取的配置信息
	// fmt.Printf("Config: %+v\n", Obj)
	//fmt.Printf("Database: %+v\n", Obj.DbConfig)
	//fmt.Printf("Proxy: %+v\n", Obj.ProxyConfig)
	//fmt.Printf("SignSrv: %+v\n", Obj.SignSrvConfig)
}

func GetConfig() *Config {
	if Obj == nil {
		InitConfig()
	}
	return Obj
}

// Config 配置接口体
type Config struct {
	Platform             string         `yaml:"platform"`             // 爬取的平台名
	Keywords             []string       `yaml:"keywords"`             // 爬取的关键词列表
	CrawlerType          string         `yaml:"crawlerType"`          // 爬取的类型
	SaveDataOption       string         `yaml:"saveDataOption"`       // 爬取数据爬虫的类型
	AccountPoolSaveType  string         `yaml:"accountPoolSaveType"`  // 账号池保存类型
	StartPage            int            `yaml:"startPage"`            // 开始的页码
	CrawlerMaxNotesCount int            `yaml:"crawlerMaxNotesCount"` // 爬取的最大帖子数量
	MaxConcurrencyNum    int            `yaml:"maxConcurrencyNum"`    // 并发数量
	RequestTimeOut       int            `yaml:"requestTimeOut"`       // 请求超时时间,单位秒
	EnableGetComments    bool           `yaml:"enableGetComments"`    // 是否开启获取评论模式
	EnableGetSubComments bool           `yaml:"enableGetSubComments"` // 是否开启获取子评论模式
	DebugRequest         bool           `yaml:"debugRequest"`         // 是否开启调试请求
	CrawlerTimeSleep     int            `yaml:"crawlerTimeSleep"`     // 爬取请求间隔时间,单位秒
	PerNoteMaxComments   int            `yaml:"perNoteMaxComments"`   // 每个帖子最大评论数量
	SpecifiedNoteIDs     []string       `yaml:"specifiedNoteIds"`     // 指定爬取的帖子ID列表
	SpecifiedCreatorIDs  []string       `yaml:"specifiedCreatorIds"`  // 指定爬取的创作者ID列表
	DbConfig             *DbConfig      `yaml:"dbConfig"`             // DB相关的配置信息
	ProxyConfig          *ProxyConfig   `yaml:"proxyConfig"`          // IP代理相关的配置信息
	SignSrvConfig        *SignSrvConfig `yaml:"signSrvConfig"`        // 请求签名相关的配置信息
}

// DbConfig db配置结构体
type DbConfig struct {
	RelationDbHost string `yaml:"relationDbHost"` // 关系型数据库Host
	RelationDbName string `yaml:"relationDbName"` // 关系型数据库Db name
	RelationDbUser string `yaml:"relationDbUser"` // 关系型数据库DB user
	RelationDbPwd  string `yaml:"relationDbPwd"`  // 关系性数据库DB password
	RelationDbPort int    `yaml:"relationDbPort"` // 关系型数据库Db port
	RedisDbHost    string `yaml:"redisDbHost"`    // redis数据库Host
	RedisDbPwd     string `yaml:"redisDbPwd"`     // redis数据库密码
	RedisDbPort    int    `yaml:"redisDbPort"`    // redis数据库port
	RedisDbNum     uint   `yaml:"redisDbNum"`     // redis数据库Db num
}

// ProxyConfig 代理配置结构体
type ProxyConfig struct {
	EnableIpProxy         bool   `yaml:"enableIpProxy"`         // 是否开启IP代理
	EnableValidateIpProxy bool   `yaml:"enableValidateIpProxy"` // 是否开启IP代理验证
	IpProxyPoolCount      int    `yaml:"ipProxyPoolCount"`      // 代理池数量
	IpProxyProvideName    string `yaml:"ipProxyProvideName"`    // IP代理提供商的名称
	KdlSecretId           string `yaml:"kdlSecretId"`           //快代理的secret id
	KdlSignature          string `yaml:"kdlSignature"`          // 快代理的签名
	KdlUserName           string `yaml:"kdlUserName"`           // 快代理的订单用户名
	KdlUserPwd            string `yaml:"kdlUserPwd"`            // 快代理订单的用户名密码
}

// SignSrvConfig 请求签名配置结构体
type SignSrvConfig struct {
	SignSrvHost string `yaml:"signSrvHost"` // 签名服务Host
	SignSrvPort int    `yaml:"signSrvPort"` // 签名服务端口
}
