package config

import (
	"os"
)

func GetEnvWrapper(key string, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}

var (
	RelationDbPwd  = GetEnvWrapper("RELATION_DB_PWD", "123456")
	RelationDbUser = GetEnvWrapper("RELATION_DB_USER", "root")
	RelationDbHost = GetEnvWrapper("RELATION_DB_HOST", "localhost")
	RelationDbPort = GetEnvWrapper("RELATION_DB_PORT", "3306")
	RelationDbName = GetEnvWrapper("RELATION_DB_NAME", "media_crawler_pro")

	RedisDbHost = GetEnvWrapper("REDIS_DB_HOST", "localhost")
	RedisDbPwd  = GetEnvWrapper("REDIS_DB_PWD", "123456")
	RedisDbPort = GetEnvWrapper("REDIS_DB_PORT", "6379")
	RedisDbNum  = GetEnvWrapper("REDIS_DB_NUM", "6379")
)
