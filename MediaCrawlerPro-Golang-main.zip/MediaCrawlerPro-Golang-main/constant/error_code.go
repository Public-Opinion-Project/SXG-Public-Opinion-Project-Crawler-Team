package constant

// ErrorEnum 错误码枚举
type ErrorEnum int

const (
	// IpBlock 网络连接异常，请检查网络设置或重启试试
	IpBlock ErrorEnum = 300012

	// NoteSecreteFault 当前内容无法展示
	NoteSecreteFault ErrorEnum = -510001

	// SignFault 浏览器异常，请尝试关闭/卸载风险插件或重启试试！
	SignFault ErrorEnum = 300015

	// SessionExpired 登录已过期
	SessionExpired ErrorEnum = -100

	// AccessFrequencyError 访问频次异常，请勿频繁操作或重启试试
	AccessFrequencyError ErrorEnum = 300013
)
