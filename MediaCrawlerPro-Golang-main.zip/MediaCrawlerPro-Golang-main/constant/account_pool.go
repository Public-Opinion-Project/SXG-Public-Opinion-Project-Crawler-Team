package constant

const (
	// AccountStatusNormal 正常状态的账号
	AccountStatusNormal = 0

	// AccountStatusInvalid 账号失效状态
	AccountStatusInvalid = -1
)

const (
	// AccountSaveTypeExcel 保存账号信息的类型为excel
	AccountSaveTypeExcel = "excel"

	// AccountSaveTypeDb 保存账号信息的类型为db
	AccountSaveTypeDb = "mysql"
)

const (
	IpValidateUrl = "https://echo.apifox.com/ip"
)
