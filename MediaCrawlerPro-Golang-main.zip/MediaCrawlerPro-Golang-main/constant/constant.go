package constant

// 所有平台名称常量
const (
	XhsPlatformName      = "xhs"
	DouyinPlatformName   = "douyin"
	KuaishouPlatformName = "kuaishou"
	BilibiliPlatformName = "bilibili"
	WeiboPlatformName    = "weibo"
	TiebaPlatformName    = "tieba"
	ZhihuPlatformName    = "zhihu"
)

// 爬取类型常量
const (
	SearchCrawlerType   = "search"
	DetailCrawlerType   = "detail"
	CreatorCrawlerType  = "creator"
	HomefeedCrawlerType = "homefeed"
)

// 保存数据类型常量
const (
	SaveDataToDb   = "db"
	SaveDataToCsv  = "csv"
	SaveDataToJson = "json"
)
