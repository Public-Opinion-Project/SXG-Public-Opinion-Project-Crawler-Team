# XHS Crawler 重构设计文档

## 概述

将 Go 版本的小红书爬虫重构为 Handler 分层架构，实现完整的爬取功能，包括 Search、Detail、Creator、Homefeed 四种爬取类型，以及评论处理和断点续爬功能。

## 设计决策

| 决策项 | 选择 |
|--------|------|
| 架构风格 | Handler 分层架构（参考 Python 版本） |
| 爬取类型 | 全部实现：Search、Detail、Creator、Homefeed + Comment |
| 断点续爬 | 完整实现 CheckpointManager |
| Processor 层 | 完整实现 NoteProcessor + CommentProcessor |
| 并发模型 | 原生 channel + worker pool（移除 ants） |
| 存储方式 | 仅 DB 存储，复用 Python 版本 DDL |
| 目录结构 | 接口驱动 + 扁平结构 |

## 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                        main.go                               │
│                    (启动入口 + CLI)                           │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│                   internal/xhs/xhs.go                        │
│                      Crawler                                 │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  - client      *Client                               │    │
│  │  - handlers    map[string]Handler                    │    │
│  │  - processor   *Processor                            │    │
│  │  - checkpoint  *CheckpointManager                    │    │
│  │  - workerPool  *worker.Pool                          │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┬─────────────┐
        ▼             ▼             ▼             ▼
   ┌─────────┐  ┌─────────┐  ┌──────────┐  ┌───────────┐
   │ Search  │  │ Detail  │  │ Creator  │  │ Homefeed  │
   │ Handler │  │ Handler │  │ Handler  │  │ Handler   │
   └────┬────┘  └────┬────┘  └────┬─────┘  └─────┬─────┘
        │            │            │              │
        └────────────┴─────┬──────┴──────────────┘
                           ▼
              ┌────────────────────────┐
              │      Processor         │
              │  ┌──────────────────┐  │
              │  │  NoteProcessor   │  │
              │  │  CommentProcessor│  │
              │  └──────────────────┘  │
              └───────────┬────────────┘
                          ▼
              ┌────────────────────────┐
              │        Store           │
              │  (xhs_note,            │
              │   xhs_note_comment,    │
              │   xhs_creator)         │
              └────────────────────────┘
```

## 核心接口定义

### Handler 接口

```go
// internal/xhs/handler.go

// Handler 定义爬取处理器接口
type Handler interface {
    Handle(ctx context.Context) error
    Name() string
}

// HandlerDeps 所有Handler共享的依赖
type HandlerDeps struct {
    Client     *Client
    Processor  *Processor
    Checkpoint *CheckpointManager
    WorkerPool *worker.Pool
    Config     *config.Config
    Logger     *tools.Logger
}
```

### Processor

```go
// internal/xhs/processor.go

type Processor struct {
    noteProcessor    *NoteProcessor
    commentProcessor *CommentProcessor
}

type NoteProcessor struct {
    client     *Client
    store      Store
    checkpoint *CheckpointManager
    workerPool *worker.Pool
}

type CommentProcessor struct {
    client     *Client
    store      Store
    checkpoint *CheckpointManager
    workerPool *worker.Pool
}
```

### Store 接口

```go
// internal/xhs/store.go

type Store interface {
    SaveNote(ctx context.Context, note *NoteRepo) error
    NoteExists(ctx context.Context, noteID string) (bool, error)
    SaveComment(ctx context.Context, comment *CommentRepo) error
    SaveCreator(ctx context.Context, creator *CreatorRepo) error
}
```

## Handler 实现

### 职责划分

| Handler | 数据来源 | 产出 |
|---------|---------|------|
| SearchHandler | 关键词搜索 API | Notes + Comments |
| DetailHandler | 指定 noteId | Notes + Comments |
| CreatorHandler | 创作者主页 API | Creator + Notes + Comments |
| HomefeedHandler | 首页推荐 API | Notes + Comments |

### SearchHandler

```go
type SearchHandler struct {
    *HandlerDeps
}

func (h *SearchHandler) Handle(ctx context.Context) error {
    // 1. 从checkpoint恢复进度（如果有）
    // 2. 遍历关键词列表
    // 3. 分页搜索，获取noteId列表
    // 4. 调用 processor.ProcessNotes() 批量处理
    // 5. 根据配置决定是否爬取评论
    // 6. 每页完成后更新checkpoint
}
```

### DetailHandler

```go
type DetailHandler struct {
    *HandlerDeps
}

func (h *DetailHandler) Handle(ctx context.Context) error {
    // 1. 读取配置中的noteId列表
    // 2. 调用 processor.ProcessNotes() 批量处理
    // 3. 根据配置决定是否爬取评论
}
```

### CreatorHandler

```go
type CreatorHandler struct {
    *HandlerDeps
}

func (h *CreatorHandler) Handle(ctx context.Context) error {
    // 1. 遍历creator_id列表
    // 2. 获取创作者信息 -> processor.ProcessCreator()
    // 3. 分页获取创作者的帖子列表
    // 4. 调用 processor.ProcessNotes() 批量处理
    // 5. 根据配置决定是否爬取评论
}
```

### HomefeedHandler

```go
type HomefeedHandler struct {
    *HandlerDeps
}

func (h *HomefeedHandler) Handle(ctx context.Context) error {
    // 1. 循环请求首页推荐接口
    // 2. 获取noteId列表
    // 3. 调用 processor.ProcessNotes() 批量处理
    // 4. 达到配置数量后停止
}
```

## Worker Pool

```go
// internal/worker/pool.go

type Task func(ctx context.Context) error

type Pool struct {
    size    int
    taskCh  chan Task
    logger  *tools.Logger
}

func NewPool(size int) *Pool {
    return &Pool{
        size:   size,
        taskCh: make(chan Task, size*2),
    }
}

func (p *Pool) Submit(ctx context.Context, tasks []Task) error {
    var wg sync.WaitGroup
    errCh := make(chan error, len(tasks))

    // 启动workers
    for i := 0; i < p.size; i++ {
        go p.worker(ctx, &wg, errCh)
    }

    // 提交任务
    for _, task := range tasks {
        wg.Add(1)
        p.taskCh <- task
    }

    wg.Wait()
    close(errCh)

    return p.collectErrors(errCh)
}
```

## Checkpoint 断点续爬

```go
// internal/crawler/checkpoint.go

type CheckpointManager struct {
    store    CheckpointStore
    platform string
}

type Checkpoint struct {
    Platform     string            `json:"platform"`
    CrawlerType  string            `json:"crawler_type"`
    Keyword      string            `json:"keyword,omitempty"`
    CreatorID    string            `json:"creator_id,omitempty"`
    CurrentPage  int               `json:"current_page"`
    TotalCrawled int               `json:"total_crawled"`
    UpdatedAt    int64             `json:"updated_at"`
    Extra        map[string]string `json:"extra,omitempty"`
}

func (m *CheckpointManager) Save(ctx context.Context, cp *Checkpoint) error
func (m *CheckpointManager) Load(ctx context.Context, crawlerType, key string) (*Checkpoint, error)
func (m *CheckpointManager) Clear(ctx context.Context, crawlerType, key string) error
```

**存储位置:** `data/checkpoints/{platform}_{crawler_type}_{key}.json`

**触发保存时机:**
- 每完成一页搜索结果
- 每处理完一个创作者
- 程序正常退出时

## 数据模型

### NoteRepo (对应 xhs_note 表)

```go
type NoteRepo struct {
    ID             int64  `gorm:"primaryKey;autoIncrement"`
    UserID         string `gorm:"column:user_id;not null"`
    Nickname       string `gorm:"column:nickname"`
    Avatar         string `gorm:"column:avatar"`
    IPLocation     string `gorm:"column:ip_location"`
    AddTs          int64  `gorm:"column:add_ts;not null"`
    LastModifyTs   int64  `gorm:"column:last_modify_ts;not null"`
    NoteID         string `gorm:"column:note_id;not null;index"`
    Type           string `gorm:"column:type"`
    Title          string `gorm:"column:title"`
    Desc           string `gorm:"column:desc"`
    VideoURL       string `gorm:"column:video_url"`
    Time           int64  `gorm:"column:time;not null;index"`
    LastUpdateTime int64  `gorm:"column:last_update_time;not null"`
    LikedCount     string `gorm:"column:liked_count"`
    CollectedCount string `gorm:"column:collected_count"`
    CommentCount   string `gorm:"column:comment_count"`
    ShareCount     string `gorm:"column:share_count"`
    ImageList      string `gorm:"column:image_list"`
    TagList        string `gorm:"column:tag_list"`
    NoteURL        string `gorm:"column:note_url"`
    SourceKeyword  string `gorm:"column:source_keyword"`
}

func (NoteRepo) TableName() string { return "xhs_note" }
```

### CommentRepo (对应 xhs_note_comment 表)

```go
type CommentRepo struct {
    ID              int64  `gorm:"primaryKey;autoIncrement"`
    UserID          string `gorm:"column:user_id;not null"`
    Nickname        string `gorm:"column:nickname"`
    Avatar          string `gorm:"column:avatar"`
    IPLocation      string `gorm:"column:ip_location"`
    AddTs           int64  `gorm:"column:add_ts;not null"`
    LastModifyTs    int64  `gorm:"column:last_modify_ts;not null"`
    CommentID       string `gorm:"column:comment_id;not null;index"`
    CreateTime      int64  `gorm:"column:create_time;not null;index"`
    NoteID          string `gorm:"column:note_id;not null"`
    Content         string `gorm:"column:content;not null"`
    SubCommentCount string `gorm:"column:sub_comment_count;not null"`
    Pictures        string `gorm:"column:pictures"`
    ParentCommentID string `gorm:"column:parent_comment_id"`
    LikeCount       string `gorm:"column:like_count;not null;default:'0'"`
    NoteURL         string `gorm:"column:note_url;not null;default:''"`
    TargetCommentID string `gorm:"column:target_comment_id"`
}

func (CommentRepo) TableName() string { return "xhs_note_comment" }
```

### CreatorRepo (对应 xhs_creator 表)

```go
type CreatorRepo struct {
    ID           int64  `gorm:"primaryKey;autoIncrement"`
    UserID       string `gorm:"column:user_id;not null"`
    Nickname     string `gorm:"column:nickname"`
    Avatar       string `gorm:"column:avatar"`
    IPLocation   string `gorm:"column:ip_location"`
    AddTs        int64  `gorm:"column:add_ts;not null"`
    LastModifyTs int64  `gorm:"column:last_modify_ts;not null"`
    Desc         string `gorm:"column:desc"`
    Gender       string `gorm:"column:gender"`
    Follows      string `gorm:"column:follows"`
    Fans         string `gorm:"column:fans"`
    Interaction  string `gorm:"column:interaction"`
    TagList      string `gorm:"column:tag_list"`
}

func (CreatorRepo) TableName() string { return "xhs_creator" }
```

## 目录结构

```
MediaCrawlerPro-Golang/
├── cmd/
│   └── root.go
├── main.go
├── config/
│   ├── config.go
│   └── db_config.go
├── constant/
│   └── constant.go
├── data/
│   └── checkpoints/
│
├── internal/
│   ├── worker/
│   │   └── pool.go             # [新增]
│   │
│   ├── crawler/
│   │   └── checkpoint.go       # [新增]
│   │
│   ├── xhs/
│   │   ├── xhs.go              # [重构]
│   │   ├── client.go           # [保留]
│   │   ├── handler.go          # [新增]
│   │   ├── processor.go        # [新增]
│   │   ├── store.go            # [重构]
│   │   ├── model.go            # [重构]
│   │   └── convert.go          # [保留]
│   │
│   ├── models/
│   │   └── xiaohongshu/
│   │
│   └── pkg/
│       ├── httpclient/
│       ├── account_pool/
│       ├── proxy/
│       ├── rpc/signsrv/
│       ├── cache/
│       └── tools/
```

## 变更汇总

| 操作 | 文件/目录 |
|------|----------|
| 新增 | `internal/worker/pool.go` |
| 新增 | `internal/crawler/checkpoint.go` |
| 新增 | `internal/xhs/handler.go` |
| 新增 | `internal/xhs/processor.go` |
| 重构 | `internal/xhs/xhs.go` |
| 重构 | `internal/xhs/store.go` |
| 重构 | `internal/xhs/model.go` |
| 删除 | `internal/repo/platform_save_data/xhs/xhs_json_repo.go` |
| 删除 | `internal/repo/platform_save_data/xhs/xhs_csv_repo.go` |

## 启动流程

```go
func run() {
    // 1. 加载配置
    cfg := config.Load()

    // 2. 初始化基础设施
    db := initDB(cfg)
    accountPool := initAccountPool(cfg)
    signClient := initSignClient(cfg)

    // 3. 创建worker pool
    wp := worker.NewPool(cfg.MaxConcurrencyNum)

    // 4. 创建XHS Crawler并启动
    crawler := xhs.NewCrawler(xhs.CrawlerOptions{
        Config:      cfg,
        DB:          db,
        AccountPool: accountPool,
        SignClient:  signClient,
        WorkerPool:  wp,
    })

    crawler.Start(context.Background())
}
```
