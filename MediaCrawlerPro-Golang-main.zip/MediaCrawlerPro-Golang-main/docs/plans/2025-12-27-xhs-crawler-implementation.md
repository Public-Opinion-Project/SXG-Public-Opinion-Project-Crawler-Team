# XHS Crawler Handler架构重构 - 实现计划

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** 将Go版本XHS爬虫重构为Handler分层架构，实现Search/Detail/Creator/Homefeed四种爬取类型，包含评论处理和断点续爬功能。

**Architecture:** 采用接口驱动+扁平结构，Handler负责爬取流程编排，Processor负责数据处理和存储，Worker Pool提供并发控制，Checkpoint提供断点续爬能力。

**Tech Stack:** Go 1.21+, GORM, channel+goroutine worker pool

---

## Task 1: Worker Pool 实现

**Files:**
- Create: `internal/worker/pool.go`

**Step 1: 创建worker目录和文件**

```go
// internal/worker/pool.go
package worker

import (
	"context"
	"sync"
)

// Task 任务函数类型
type Task func(ctx context.Context) error

// Pool 基于channel的worker池
type Pool struct {
	size   int
	logger interface{ Info(args ...interface{}); Error(args ...interface{}) }
}

// NewPool 创建worker池
func NewPool(size int) *Pool {
	if size <= 0 {
		size = 5
	}
	return &Pool{
		size: size,
	}
}

// SetLogger 设置日志器
func (p *Pool) SetLogger(logger interface{ Info(args ...interface{}); Error(args ...interface{}) }) {
	p.logger = logger
}

// Submit 提交任务并等待全部完成
func (p *Pool) Submit(ctx context.Context, tasks []Task) []error {
	if len(tasks) == 0 {
		return nil
	}

	var wg sync.WaitGroup
	taskCh := make(chan Task, len(tasks))
	errCh := make(chan error, len(tasks))

	// 启动workers
	for i := 0; i < p.size; i++ {
		go p.worker(ctx, &wg, taskCh, errCh)
	}

	// 提交任务
	for _, task := range tasks {
		wg.Add(1)
		taskCh <- task
	}
	close(taskCh)

	// 等待完成
	wg.Wait()
	close(errCh)

	// 收集错误
	return p.collectErrors(errCh)
}

// worker 工作协程
func (p *Pool) worker(ctx context.Context, wg *sync.WaitGroup, taskCh <-chan Task, errCh chan<- error) {
	for task := range taskCh {
		select {
		case <-ctx.Done():
			errCh <- ctx.Err()
			wg.Done()
			return
		default:
			if err := task(ctx); err != nil {
				errCh <- err
			}
			wg.Done()
		}
	}
}

// collectErrors 收集错误
func (p *Pool) collectErrors(errCh <-chan error) []error {
	var errs []error
	for err := range errCh {
		if err != nil {
			errs = append(errs, err)
		}
	}
	return errs
}

// Size 返回worker数量
func (p *Pool) Size() int {
	return p.size
}
```

**Step 2: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./internal/worker/...`
Expected: 编译成功，无错误

**Step 3: Commit**

```bash
git add internal/worker/pool.go
git commit -m "feat(worker): add channel-based worker pool"
```

---

## Task 2: Checkpoint 断点续爬实现

**Files:**
- Create: `internal/crawler/checkpoint.go`
- Create: `data/checkpoints/.gitkeep`

**Step 1: 创建checkpoint目录和模型**

```go
// internal/crawler/checkpoint.go
package crawler

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// Checkpoint 断点数据结构
type Checkpoint struct {
	ID              string            `json:"id"`
	Platform        string            `json:"platform"`
	CrawlerType     string            `json:"crawler_type"`
	Keyword         string            `json:"keyword,omitempty"`
	CreatorID       string            `json:"creator_id,omitempty"`
	CurrentPage     int               `json:"current_page"`
	TotalCrawled    int               `json:"total_crawled"`
	CrawledNoteIDs  []string          `json:"crawled_note_ids,omitempty"`
	UpdatedAt       int64             `json:"updated_at"`
	Extra           map[string]string `json:"extra,omitempty"`
}

// CheckpointManager 断点续爬管理器
type CheckpointManager struct {
	baseDir  string
	platform string
	mu       sync.RWMutex
}

// NewCheckpointManager 创建断点管理器
func NewCheckpointManager(platform string, baseDir string) *CheckpointManager {
	if baseDir == "" {
		baseDir = "data/checkpoints"
	}
	// 确保目录存在
	os.MkdirAll(baseDir, 0755)
	return &CheckpointManager{
		baseDir:  baseDir,
		platform: platform,
	}
}

// generateID 生成检查点ID
func (m *CheckpointManager) generateID(crawlerType, key string) string {
	timestamp := time.Now().Format("20060102150405")
	if key != "" {
		return fmt.Sprintf("%s_%s_%s_%s", m.platform, crawlerType, key, timestamp)
	}
	return fmt.Sprintf("%s_%s_%s", m.platform, crawlerType, timestamp)
}

// getFilePath 获取检查点文件路径
func (m *CheckpointManager) getFilePath(id string) string {
	return filepath.Join(m.baseDir, id+".json")
}

// Save 保存断点
func (m *CheckpointManager) Save(cp *Checkpoint) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if cp.ID == "" {
		cp.ID = m.generateID(cp.CrawlerType, cp.Keyword)
	}
	cp.UpdatedAt = time.Now().Unix()
	cp.Platform = m.platform

	data, err := json.MarshalIndent(cp, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal checkpoint failed: %w", err)
	}

	return os.WriteFile(m.getFilePath(cp.ID), data, 0644)
}

// Load 加载断点（按crawlerType和key查找最新的）
func (m *CheckpointManager) Load(crawlerType, key string) (*Checkpoint, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	pattern := filepath.Join(m.baseDir, fmt.Sprintf("%s_%s_%s_*.json", m.platform, crawlerType, key))
	if key == "" {
		pattern = filepath.Join(m.baseDir, fmt.Sprintf("%s_%s_*.json", m.platform, crawlerType))
	}

	matches, err := filepath.Glob(pattern)
	if err != nil {
		return nil, err
	}

	if len(matches) == 0 {
		return nil, nil
	}

	// 找最新的文件
	var latestFile string
	var latestTime time.Time
	for _, match := range matches {
		info, err := os.Stat(match)
		if err != nil {
			continue
		}
		if info.ModTime().After(latestTime) {
			latestTime = info.ModTime()
			latestFile = match
		}
	}

	if latestFile == "" {
		return nil, nil
	}

	return m.LoadByID(filepath.Base(latestFile[:len(latestFile)-5])) // 去掉.json后缀
}

// LoadByID 按ID加载断点
func (m *CheckpointManager) LoadByID(id string) (*Checkpoint, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	data, err := os.ReadFile(m.getFilePath(id))
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}

	var cp Checkpoint
	if err := json.Unmarshal(data, &cp); err != nil {
		return nil, fmt.Errorf("unmarshal checkpoint failed: %w", err)
	}

	return &cp, nil
}

// Clear 清除断点
func (m *CheckpointManager) Clear(id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	err := os.Remove(m.getFilePath(id))
	if os.IsNotExist(err) {
		return nil
	}
	return err
}

// AddCrawledNote 添加已爬取的笔记ID
func (m *CheckpointManager) AddCrawledNote(cp *Checkpoint, noteID string) {
	for _, id := range cp.CrawledNoteIDs {
		if id == noteID {
			return
		}
	}
	cp.CrawledNoteIDs = append(cp.CrawledNoteIDs, noteID)
}

// IsNoteCrawled 检查笔记是否已爬取
func (m *CheckpointManager) IsNoteCrawled(cp *Checkpoint, noteID string) bool {
	if cp == nil {
		return false
	}
	for _, id := range cp.CrawledNoteIDs {
		if id == noteID {
			return true
		}
	}
	return false
}
```

**Step 2: 创建checkpoints目录占位文件**

```bash
mkdir -p data/checkpoints
touch data/checkpoints/.gitkeep
```

**Step 3: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./internal/crawler/...`
Expected: 编译成功

**Step 4: Commit**

```bash
git add internal/crawler/checkpoint.go data/checkpoints/.gitkeep
git commit -m "feat(crawler): add checkpoint manager for resumable crawling"
```

---

## Task 3: XHS Store 接口和DB实现

**Files:**
- Create: `internal/xhs/store.go`
- Modify: `internal/xhs/model.go` (重命名自 `internal/repo/platform_save_data/xhs/xhs_model.go`)

**Step 1: 创建xhs目录（如果不存在）并移动/重命名文件**

```bash
mkdir -p internal/xhs
# 如果 internal/service/xhs 存在，将其内容移动到 internal/xhs
```

**Step 2: 创建Store接口和模型**

```go
// internal/xhs/store.go
package xhs

import (
	"context"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

// Store 存储接口
type Store interface {
	// Note 相关
	SaveNote(ctx context.Context, note *NoteRepo) error
	NoteExists(ctx context.Context, noteID string) (bool, error)

	// Comment 相关
	SaveComment(ctx context.Context, comment *CommentRepo) error

	// Creator 相关
	SaveCreator(ctx context.Context, creator *CreatorRepo) error
}

// DBStore 数据库存储实现
type DBStore struct {
	db *gorm.DB
}

// NewDBStore 创建数据库存储
func NewDBStore(db *gorm.DB) *DBStore {
	return &DBStore{db: db}
}

// SaveNote 保存帖子（upsert语义）
func (s *DBStore) SaveNote(ctx context.Context, note *NoteRepo) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "note_id"}},
			UpdateAll: true,
		}).Create(note).Error
}

// NoteExists 检查帖子是否存在
func (s *DBStore) NoteExists(ctx context.Context, noteID string) (bool, error) {
	var count int64
	err := s.db.WithContext(ctx).Model(&NoteRepo{}).Where("note_id = ?", noteID).Count(&count).Error
	return count > 0, err
}

// SaveComment 保存评论
func (s *DBStore) SaveComment(ctx context.Context, comment *CommentRepo) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "comment_id"}},
			UpdateAll: true,
		}).Create(comment).Error
}

// SaveCreator 保存创作者
func (s *DBStore) SaveCreator(ctx context.Context, creator *CreatorRepo) error {
	return s.db.WithContext(ctx).
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "user_id"}},
			UpdateAll: true,
		}).Create(creator).Error
}
```

**Step 3: 创建数据模型（对齐Python DDL）**

```go
// internal/xhs/model.go
package xhs

// NoteRepo 对应 xhs_note 表
type NoteRepo struct {
	ID             int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID         string `gorm:"column:user_id;not null"`
	Nickname       string `gorm:"column:nickname"`
	Avatar         string `gorm:"column:avatar"`
	IPLocation     string `gorm:"column:ip_location"`
	AddTs          int64  `gorm:"column:add_ts;not null"`
	LastModifyTs   int64  `gorm:"column:last_modify_ts;not null"`
	NoteID         string `gorm:"column:note_id;not null;index"`
	Type           string `gorm:"column:type"`
	Title          string `gorm:"column:title"`
	Desc           string `gorm:"column:desc"`
	VideoURL       string `gorm:"column:video_url"`
	Time           int64  `gorm:"column:time;not null;index"`
	LastUpdateTime int64  `gorm:"column:last_update_time;not null"`
	LikedCount     string `gorm:"column:liked_count"`
	CollectedCount string `gorm:"column:collected_count"`
	CommentCount   string `gorm:"column:comment_count"`
	ShareCount     string `gorm:"column:share_count"`
	ImageList      string `gorm:"column:image_list"`
	TagList        string `gorm:"column:tag_list"`
	NoteURL        string `gorm:"column:note_url"`
	SourceKeyword  string `gorm:"column:source_keyword"`
}

func (NoteRepo) TableName() string { return "xhs_note" }

// CommentRepo 对应 xhs_note_comment 表
type CommentRepo struct {
	ID              int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID          string `gorm:"column:user_id;not null"`
	Nickname        string `gorm:"column:nickname"`
	Avatar          string `gorm:"column:avatar"`
	IPLocation      string `gorm:"column:ip_location"`
	AddTs           int64  `gorm:"column:add_ts;not null"`
	LastModifyTs    int64  `gorm:"column:last_modify_ts;not null"`
	CommentID       string `gorm:"column:comment_id;not null;index"`
	CreateTime      int64  `gorm:"column:create_time;not null;index"`
	NoteID          string `gorm:"column:note_id;not null"`
	Content         string `gorm:"column:content;not null"`
	SubCommentCount string `gorm:"column:sub_comment_count;not null"`
	Pictures        string `gorm:"column:pictures"`
	ParentCommentID string `gorm:"column:parent_comment_id"`
	LikeCount       string `gorm:"column:like_count;not null;default:'0'"`
	NoteURL         string `gorm:"column:note_url;not null;default:''"`
	TargetCommentID string `gorm:"column:target_comment_id"`
}

func (CommentRepo) TableName() string { return "xhs_note_comment" }

// CreatorRepo 对应 xhs_creator 表
type CreatorRepo struct {
	ID           int64  `gorm:"primaryKey;autoIncrement;column:id"`
	UserID       string `gorm:"column:user_id;not null"`
	Nickname     string `gorm:"column:nickname"`
	Avatar       string `gorm:"column:avatar"`
	IPLocation   string `gorm:"column:ip_location"`
	AddTs        int64  `gorm:"column:add_ts;not null"`
	LastModifyTs int64  `gorm:"column:last_modify_ts;not null"`
	Desc         string `gorm:"column:desc"`
	Gender       string `gorm:"column:gender"`
	Follows      string `gorm:"column:follows"`
	Fans         string `gorm:"column:fans"`
	Interaction  string `gorm:"column:interaction"`
	TagList      string `gorm:"column:tag_list"`
}

func (CreatorRepo) TableName() string { return "xhs_creator" }
```

**Step 4: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./internal/xhs/...`
Expected: 编译成功

**Step 5: Commit**

```bash
git add internal/xhs/store.go internal/xhs/model.go
git commit -m "feat(xhs): add Store interface with DB implementation and models"
```

---

## Task 4: Client API 扩展（评论、创作者、首页推荐）

**Files:**
- Modify: `internal/xhs/client.go` (从 internal/service/xhs/client.go 移动)

**Step 1: 添加评论API模型**

```go
// 添加到 internal/models/xiaohongshu/ 或 internal/xhs/api_model.go

// CommentResponse 评论API响应
type CommentResponse struct {
	Comments []Comment `json:"comments"`
	Cursor   string    `json:"cursor"`
	HasMore  bool      `json:"has_more"`
}

// Comment 评论结构
type Comment struct {
	ID              string    `json:"id"`
	NoteID          string    `json:"note_id"`
	Content         string    `json:"content"`
	CreateTime      int64     `json:"create_time"`
	LikeCount       string    `json:"like_count"`
	SubCommentCount string    `json:"sub_comment_count"`
	Pictures        string    `json:"pictures"`
	TargetComment   *Comment  `json:"target_comment"`
	UserInfo        *UserInfo `json:"user_info"`
	IPLocation      string    `json:"ip_location"`
}

// UserInfo 用户信息
type UserInfo struct {
	UserID   string `json:"user_id"`
	Nickname string `json:"nickname"`
	Image    string `json:"image"`
}
```

**Step 2: 在Client中添加评论获取方法**

```go
// GetNoteComments 获取帖子一级评论
func (c *Client) GetNoteComments(noteID, cursor, xsecToken string) (*CommentResponse, error) {
	uri := "/api/sns/web/v2/comment/page"
	params := map[string]any{
		"note_id":        noteID,
		"cursor":         cursor,
		"top_comment_id": "",
		"image_formats":  "jpg,webp,avif",
	}
	if xsecToken != "" {
		params["xsec_token"] = xsecToken
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var respStruct Response[*CommentResponse]
	err = c.unmarshalResponseData([]byte(respData), &respStruct)
	if err != nil {
		return nil, err
	}

	return respStruct.Data, nil
}

// GetNoteSubComments 获取子评论
func (c *Client) GetNoteSubComments(noteID, rootCommentID, cursor, xsecToken string, num int) (*CommentResponse, error) {
	uri := "/api/sns/web/v2/comment/sub/page"
	params := map[string]any{
		"note_id":         noteID,
		"root_comment_id": rootCommentID,
		"num":             num,
		"cursor":          cursor,
	}
	if xsecToken != "" {
		params["xsec_token"] = xsecToken
	}

	respData, err := c.Get(uri, params)
	if err != nil {
		return nil, err
	}

	var respStruct Response[*CommentResponse]
	err = c.unmarshalResponseData([]byte(respData), &respStruct)
	if err != nil {
		return nil, err
	}

	return respStruct.Data, nil
}
```

**Step 3: 添加创作者API**

```go
// GetCreatorInfo 获取创作者信息（从HTML解析）
func (c *Client) GetCreatorInfo(userID, xsecToken, xsecSource string) (*CreatorInfo, error) {
	url := fmt.Sprintf("%s/user/profile/%s?xsec_token=%s&xsec_source=%s",
		IndexUrl, userID, xsecToken, xsecSource)

	headers := c.clientConfig.GetHeaders()
	headers["Cookie"] = c.accountInfo.Account.Cookies

	respData, err := c.Request(http.MethodGet, url, nil, headers, true)
	if err != nil {
		return nil, err
	}

	return c.extractCreatorFromHtml(userID, respData)
}

// GetCreatorNotes 获取创作者的帖子列表
func (c *Client) GetCreatorNotes(creatorID, cursor, xsecToken, xsecSource string, pageSize int) (*CreatorNotesResponse, error) {
	uri := fmt.Sprintf("/api/sns/web/v1/user_posted?num=%d&cursor=%s&user_id=%s&image_formats=jpg,webp,avif&xsec_token=%s&xsec_source=%s",
		pageSize, cursor, creatorID, xsecToken, xsecSource)

	respData, err := c.Get(uri, nil)
	if err != nil {
		return nil, err
	}

	var respStruct Response[*CreatorNotesResponse]
	err = c.unmarshalResponseData([]byte(respData), &respStruct)
	if err != nil {
		return nil, err
	}

	return respStruct.Data, nil
}
```

**Step 4: 添加首页推荐API**

```go
// FeedType 首页推荐类型
type FeedType string

const (
	FeedTypeRecommend FeedType = "homefeed_recommend"
)

// HomefeedResponse 首页推荐响应
type HomefeedResponse struct {
	Items       []HomefeedItem `json:"items"`
	CursorScore string         `json:"cursor_score"`
}

// GetHomefeedNotes 获取首页推荐帖子
func (c *Client) GetHomefeedNotes(category FeedType, cursor string, noteIndex, noteNum int) (*HomefeedResponse, error) {
	uri := "/api/sns/web/v1/homefeed"
	data := map[string]any{
		"category":           string(category),
		"cursor_score":       cursor,
		"image_formats":      []string{"jpg", "webp", "avif"},
		"need_filter_image":  false,
		"need_num":           noteNum,
		"note_index":         noteIndex,
		"num":                noteNum,
		"refresh_type":       3,
		"search_key":         "",
		"unread_begin_note_id": "",
		"unread_end_note_id":   "",
		"unread_note_count":    0,
	}

	respData, err := c.Post(uri, data)
	if err != nil {
		return nil, err
	}

	var respStruct Response[*HomefeedResponse]
	err = c.unmarshalResponseData([]byte(respData), &respStruct)
	if err != nil {
		return nil, err
	}

	return respStruct.Data, nil
}
```

**Step 5: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./internal/xhs/...`
Expected: 编译成功

**Step 6: Commit**

```bash
git add internal/xhs/client.go internal/models/xiaohongshu/
git commit -m "feat(xhs): add comment, creator, and homefeed API methods"
```

---

## Task 5: Handler 接口和基础实现

**Files:**
- Create: `internal/xhs/handler.go`

**Step 1: 创建Handler接口和依赖结构**

```go
// internal/xhs/handler.go
package xhs

import (
	"context"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/crawler"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
)

// Handler 定义爬取处理器接口
type Handler interface {
	// Handle 执行爬取任务
	Handle(ctx context.Context) error
	// Name 返回handler名称
	Name() string
}

// HandlerDeps 所有Handler共享的依赖
type HandlerDeps struct {
	Client     *Client
	Processor  *Processor
	Checkpoint *crawler.CheckpointManager
	WorkerPool *worker.Pool
	Config     *config.Config
	Logger     *tools.Logger
}

// NewHandlerDeps 创建Handler依赖
func NewHandlerDeps(
	client *Client,
	processor *Processor,
	checkpoint *crawler.CheckpointManager,
	workerPool *worker.Pool,
	cfg *config.Config,
) *HandlerDeps {
	return &HandlerDeps{
		Client:     client,
		Processor:  processor,
		Checkpoint: checkpoint,
		WorkerPool: workerPool,
		Config:     cfg,
		Logger:     tools.GetLogger(),
	}
}
```

**Step 2: 实现SearchHandler**

```go
// SearchHandler 搜索爬取处理器
type SearchHandler struct {
	*HandlerDeps
}

func NewSearchHandler(deps *HandlerDeps) *SearchHandler {
	return &SearchHandler{HandlerDeps: deps}
}

func (h *SearchHandler) Name() string {
	return "search"
}

func (h *SearchHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[SearchHandler.Handle] Begin search xhs")

	keywords := h.Config.Keywords
	maxNotes := h.Config.CrawlerMaxNotesCount
	pageSize := 20

	for _, keyword := range keywords {
		h.Logger.Info("[SearchHandler.Handle] Searching keyword: ", keyword)

		// 尝试加载断点
		var startPage int = 1
		var crawledCount int = 0
		cp, _ := h.Checkpoint.Load(h.Name(), keyword)
		if cp != nil {
			startPage = cp.CurrentPage
			crawledCount = cp.TotalCrawled
			h.Logger.Info("[SearchHandler.Handle] Resume from checkpoint, page: ", startPage)
		} else {
			cp = &crawler.Checkpoint{
				CrawlerType: h.Name(),
				Keyword:     keyword,
				CurrentPage: 1,
			}
		}

		page := startPage
		for crawledCount < maxNotes {
			h.Logger.Info("[SearchHandler.Handle] Searching page: ", page)

			// 搜索
			searchResp, err := h.Client.SearchNotesByKeyword(&SearchRequest{
				Keyword:  keyword,
				Page:     page,
				PageSize: pageSize,
				SearchID: tools.GetSearchID(),
				Sort:     SearchSortTypeGeneral,
				NoteType: SearchNoteTypeAll,
			})
			if err != nil {
				h.Logger.Error("[SearchHandler.Handle] Search error: ", err)
				break
			}

			if !searchResp.HasMore || len(searchResp.Items) == 0 {
				h.Logger.Info("[SearchHandler.Handle] No more data")
				break
			}

			// 过滤有效帖子
			noteItems := make([]NoteItem, 0)
			for _, item := range searchResp.Items {
				if item.ModelType == "rec_query" || item.ModelType == "hot_query" {
					continue
				}
				noteItems = append(noteItems, NoteItem{
					NoteID:     item.ID,
					XsecToken:  item.XsecToken,
					XsecSource: "pc_feed",
				})
			}

			// 处理帖子
			processedCount, err := h.Processor.ProcessNotes(ctx, noteItems, keyword)
			if err != nil {
				h.Logger.Error("[SearchHandler.Handle] Process notes error: ", err)
			}

			// 处理评论
			if h.Config.EnableGetComments {
				noteIDs := make([]string, 0)
				xsecTokens := make([]string, 0)
				for _, item := range noteItems {
					noteIDs = append(noteIDs, item.NoteID)
					xsecTokens = append(xsecTokens, item.XsecToken)
				}
				h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
			}

			crawledCount += processedCount
			page++

			// 更新断点
			cp.CurrentPage = page
			cp.TotalCrawled = crawledCount
			h.Checkpoint.Save(cp)

			// 请求间隔
			if h.Config.CrawlerTimeSleep > 0 {
				time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
			}
		}
	}

	h.Logger.Info("[SearchHandler.Handle] Search completed")
	return nil
}
```

**Step 3: 实现DetailHandler**

```go
// DetailHandler 指定帖子爬取处理器
type DetailHandler struct {
	*HandlerDeps
}

func NewDetailHandler(deps *HandlerDeps) *DetailHandler {
	return &DetailHandler{HandlerDeps: deps}
}

func (h *DetailHandler) Name() string {
	return "detail"
}

func (h *DetailHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[DetailHandler.Handle] Begin get specified notes")

	noteIDs := h.Config.SpecifiedNoteIDs
	if len(noteIDs) == 0 {
		h.Logger.Warn("[DetailHandler.Handle] No note IDs specified")
		return nil
	}

	// 构建NoteItem列表
	noteItems := make([]NoteItem, 0, len(noteIDs))
	for _, noteID := range noteIDs {
		noteItems = append(noteItems, NoteItem{
			NoteID:     noteID,
			XsecToken:  "", // Detail模式可能没有token
			XsecSource: "pc_note_detail",
		})
	}

	// 处理帖子
	_, err := h.Processor.ProcessNotes(ctx, noteItems, "")
	if err != nil {
		h.Logger.Error("[DetailHandler.Handle] Process notes error: ", err)
		return err
	}

	// 处理评论
	if h.Config.EnableGetComments {
		xsecTokens := make([]string, len(noteIDs))
		h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
	}

	h.Logger.Info("[DetailHandler.Handle] Detail completed")
	return nil
}
```

**Step 4: 实现CreatorHandler**

```go
// CreatorHandler 创作者爬取处理器
type CreatorHandler struct {
	*HandlerDeps
}

func NewCreatorHandler(deps *HandlerDeps) *CreatorHandler {
	return &CreatorHandler{HandlerDeps: deps}
}

func (h *CreatorHandler) Name() string {
	return "creator"
}

func (h *CreatorHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[CreatorHandler.Handle] Begin get creator notes")

	creatorIDs := h.Config.SpecifiedCreatorIDs
	if len(creatorIDs) == 0 {
		h.Logger.Warn("[CreatorHandler.Handle] No creator IDs specified")
		return nil
	}

	for _, creatorID := range creatorIDs {
		h.Logger.Info("[CreatorHandler.Handle] Processing creator: ", creatorID)

		// 获取创作者信息
		creatorInfo, err := h.Client.GetCreatorInfo(creatorID, "", "pc_user")
		if err != nil {
			h.Logger.Error("[CreatorHandler.Handle] Get creator info error: ", err)
			continue
		}

		// 保存创作者信息
		h.Processor.ProcessCreator(ctx, creatorInfo)

		// 获取创作者帖子
		cursor := ""
		pageSize := 30
		crawledCount := 0
		maxNotes := h.Config.CrawlerMaxNotesCount

		for crawledCount < maxNotes {
			notesResp, err := h.Client.GetCreatorNotes(creatorID, cursor, "", "pc_user", pageSize)
			if err != nil {
				h.Logger.Error("[CreatorHandler.Handle] Get creator notes error: ", err)
				break
			}

			if len(notesResp.Notes) == 0 {
				break
			}

			// 构建NoteItem列表
			noteItems := make([]NoteItem, 0)
			for _, note := range notesResp.Notes {
				noteItems = append(noteItems, NoteItem{
					NoteID:     note.NoteID,
					XsecToken:  note.XsecToken,
					XsecSource: "pc_user",
				})
			}

			// 处理帖子
			processedCount, _ := h.Processor.ProcessNotes(ctx, noteItems, "")
			crawledCount += processedCount

			// 处理评论
			if h.Config.EnableGetComments {
				noteIDs := make([]string, 0)
				xsecTokens := make([]string, 0)
				for _, item := range noteItems {
					noteIDs = append(noteIDs, item.NoteID)
					xsecTokens = append(xsecTokens, item.XsecToken)
				}
				h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
			}

			cursor = notesResp.Cursor
			if !notesResp.HasMore {
				break
			}
		}
	}

	h.Logger.Info("[CreatorHandler.Handle] Creator completed")
	return nil
}
```

**Step 5: 实现HomefeedHandler**

```go
// HomefeedHandler 首页推荐爬取处理器
type HomefeedHandler struct {
	*HandlerDeps
}

func NewHomefeedHandler(deps *HandlerDeps) *HomefeedHandler {
	return &HomefeedHandler{HandlerDeps: deps}
}

func (h *HomefeedHandler) Name() string {
	return "homefeed"
}

func (h *HomefeedHandler) Handle(ctx context.Context) error {
	h.Logger.Info("[HomefeedHandler.Handle] Begin get homefeed notes")

	cursor := ""
	noteIndex := 0
	noteNum := 18
	crawledCount := 0
	maxNotes := h.Config.CrawlerMaxNotesCount

	for crawledCount < maxNotes {
		h.Logger.Info("[HomefeedHandler.Handle] Getting homefeed, index: ", noteIndex)

		resp, err := h.Client.GetHomefeedNotes(FeedTypeRecommend, cursor, noteIndex, noteNum)
		if err != nil {
			h.Logger.Error("[HomefeedHandler.Handle] Get homefeed error: ", err)
			break
		}

		if len(resp.Items) == 0 {
			h.Logger.Info("[HomefeedHandler.Handle] No more data")
			break
		}

		// 构建NoteItem列表
		noteItems := make([]NoteItem, 0)
		for _, item := range resp.Items {
			if item.NoteCard.NoteID == "" {
				continue
			}
			noteItems = append(noteItems, NoteItem{
				NoteID:     item.NoteCard.NoteID,
				XsecToken:  item.XsecToken,
				XsecSource: "pc_feed",
			})
		}

		// 处理帖子
		processedCount, _ := h.Processor.ProcessNotes(ctx, noteItems, "homefeed")
		crawledCount += processedCount

		// 处理评论
		if h.Config.EnableGetComments {
			noteIDs := make([]string, 0)
			xsecTokens := make([]string, 0)
			for _, item := range noteItems {
				noteIDs = append(noteIDs, item.NoteID)
				xsecTokens = append(xsecTokens, item.XsecToken)
			}
			h.Processor.ProcessComments(ctx, noteIDs, xsecTokens)
		}

		cursor = resp.CursorScore
		noteIndex += len(resp.Items)

		// 请求间隔
		if h.Config.CrawlerTimeSleep > 0 {
			time.Sleep(time.Duration(h.Config.CrawlerTimeSleep) * time.Second)
		}
	}

	h.Logger.Info("[HomefeedHandler.Handle] Homefeed completed")
	return nil
}
```

**Step 6: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./internal/xhs/...`
Expected: 编译成功

**Step 7: Commit**

```bash
git add internal/xhs/handler.go
git commit -m "feat(xhs): add Handler interface with Search/Detail/Creator/Homefeed implementations"
```

---

## Task 6: Processor 实现

**Files:**
- Create: `internal/xhs/processor.go`

**Step 1: 创建Processor**

```go
// internal/xhs/processor.go
package xhs

import (
	"context"
	"time"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
)

// NoteItem 帖子项（用于批量处理）
type NoteItem struct {
	NoteID     string
	XsecToken  string
	XsecSource string
}

// Processor 数据处理器
type Processor struct {
	client     *Client
	store      Store
	workerPool *worker.Pool
	config     *config.Config
	logger     *tools.Logger
}

// NewProcessor 创建处理器
func NewProcessor(client *Client, store Store, workerPool *worker.Pool, cfg *config.Config) *Processor {
	return &Processor{
		client:     client,
		store:      store,
		workerPool: workerPool,
		config:     cfg,
		logger:     tools.GetLogger(),
	}
}

// ProcessNotes 批量处理帖子
func (p *Processor) ProcessNotes(ctx context.Context, noteItems []NoteItem, sourceKeyword string) (int, error) {
	if len(noteItems) == 0 {
		return 0, nil
	}

	p.logger.Info("[Processor.ProcessNotes] Processing ", len(noteItems), " notes")

	successCount := 0
	tasks := make([]worker.Task, 0, len(noteItems))

	for _, item := range noteItems {
		noteItem := item // 捕获变量
		tasks = append(tasks, func(ctx context.Context) error {
			err := p.processOneNote(ctx, noteItem, sourceKeyword)
			if err == nil {
				successCount++
			}
			return err
		})
	}

	errs := p.workerPool.Submit(ctx, tasks)
	if len(errs) > 0 {
		p.logger.Error("[Processor.ProcessNotes] Failed count: ", len(errs))
	}

	return successCount, nil
}

// processOneNote 处理单个帖子
func (p *Processor) processOneNote(ctx context.Context, item NoteItem, sourceKeyword string) error {
	// 检查是否已存在
	exists, _ := p.store.NoteExists(ctx, item.NoteID)
	if exists {
		p.logger.Info("[Processor.processOneNote] Note already exists: ", item.NoteID)
		return nil
	}

	// 获取帖子详情（HTML优先）
	noteDetail, err := p.client.GetNoteDetailFromHtml(item.NoteID, item.XsecToken, item.XsecSource)
	if err != nil {
		p.logger.Warn("[Processor.processOneNote] Get from HTML failed, try API: ", item.NoteID)
		noteDetail, err = p.client.GetNoteDetailFromApi(item.NoteID, item.XsecToken, item.XsecSource)
		if err != nil {
			p.logger.Error("[Processor.processOneNote] Get note detail failed: ", item.NoteID, err)
			return err
		}
	}

	// 转换为存储模型
	noteRepo := ConvertNoteDetailToNoteRepo(noteDetail)
	noteRepo.SourceKeyword = sourceKeyword
	noteRepo.NoteURL = "https://www.xiaohongshu.com/explore/" + item.NoteID

	// 保存
	if err := p.store.SaveNote(ctx, noteRepo); err != nil {
		p.logger.Error("[Processor.processOneNote] Save note failed: ", item.NoteID, err)
		return err
	}

	p.logger.Info("[Processor.processOneNote] Saved note: ", item.NoteID)
	return nil
}

// ProcessComments 批量处理帖子评论
func (p *Processor) ProcessComments(ctx context.Context, noteIDs []string, xsecTokens []string) {
	if len(noteIDs) == 0 || !p.config.EnableGetComments {
		return
	}

	p.logger.Info("[Processor.ProcessComments] Processing comments for ", len(noteIDs), " notes")

	tasks := make([]worker.Task, 0, len(noteIDs))
	for i, noteID := range noteIDs {
		nid := noteID
		token := ""
		if i < len(xsecTokens) {
			token = xsecTokens[i]
		}

		tasks = append(tasks, func(ctx context.Context) error {
			return p.processNoteComments(ctx, nid, token)
		})
	}

	p.workerPool.Submit(ctx, tasks)
}

// processNoteComments 处理单个帖子的所有评论
func (p *Processor) processNoteComments(ctx context.Context, noteID, xsecToken string) error {
	cursor := ""
	totalComments := 0
	maxComments := p.config.PerNoteMaxComments

	for totalComments < maxComments {
		// 获取一级评论
		resp, err := p.client.GetNoteComments(noteID, cursor, xsecToken)
		if err != nil {
			p.logger.Error("[Processor.processNoteComments] Get comments failed: ", noteID, err)
			return err
		}

		if len(resp.Comments) == 0 {
			break
		}

		// 保存评论
		for _, comment := range resp.Comments {
			commentRepo := p.convertCommentToRepo(noteID, &comment, "")
			p.store.SaveComment(ctx, commentRepo)
			totalComments++

			// 获取子评论
			if p.config.EnableGetSubComments && comment.SubCommentCount != "0" {
				p.processSubComments(ctx, noteID, comment.ID, xsecToken)
			}
		}

		if !resp.HasMore || cursor == resp.Cursor {
			break
		}
		cursor = resp.Cursor
	}

	p.logger.Info("[Processor.processNoteComments] Processed ", totalComments, " comments for note: ", noteID)
	return nil
}

// processSubComments 处理子评论
func (p *Processor) processSubComments(ctx context.Context, noteID, rootCommentID, xsecToken string) {
	cursor := ""
	for {
		resp, err := p.client.GetNoteSubComments(noteID, rootCommentID, cursor, xsecToken, 10)
		if err != nil {
			break
		}

		if len(resp.Comments) == 0 {
			break
		}

		for _, comment := range resp.Comments {
			commentRepo := p.convertCommentToRepo(noteID, &comment, rootCommentID)
			p.store.SaveComment(ctx, commentRepo)
		}

		if !resp.HasMore {
			break
		}
		cursor = resp.Cursor
	}
}

// convertCommentToRepo 转换评论为存储模型
func (p *Processor) convertCommentToRepo(noteID string, comment *Comment, parentCommentID string) *CommentRepo {
	now := time.Now().Unix()
	return &CommentRepo{
		UserID:          comment.UserInfo.UserID,
		Nickname:        comment.UserInfo.Nickname,
		Avatar:          comment.UserInfo.Image,
		IPLocation:      comment.IPLocation,
		AddTs:           now,
		LastModifyTs:    now,
		CommentID:       comment.ID,
		CreateTime:      comment.CreateTime,
		NoteID:          noteID,
		Content:         comment.Content,
		SubCommentCount: comment.SubCommentCount,
		Pictures:        comment.Pictures,
		ParentCommentID: parentCommentID,
		LikeCount:       comment.LikeCount,
		NoteURL:         "https://www.xiaohongshu.com/explore/" + noteID,
	}
}

// ProcessCreator 处理创作者信息
func (p *Processor) ProcessCreator(ctx context.Context, creatorInfo *CreatorInfo) error {
	if creatorInfo == nil {
		return nil
	}

	now := time.Now().Unix()
	creatorRepo := &CreatorRepo{
		UserID:       creatorInfo.UserID,
		Nickname:     creatorInfo.Nickname,
		Avatar:       creatorInfo.Avatar,
		IPLocation:   creatorInfo.IPLocation,
		AddTs:        now,
		LastModifyTs: now,
		Desc:         creatorInfo.Desc,
		Gender:       creatorInfo.Gender,
		Follows:      creatorInfo.Follows,
		Fans:         creatorInfo.Fans,
		Interaction:  creatorInfo.Interaction,
		TagList:      creatorInfo.TagList,
	}

	return p.store.SaveCreator(ctx, creatorRepo)
}
```

**Step 2: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./internal/xhs/...`
Expected: 编译成功

**Step 3: Commit**

```bash
git add internal/xhs/processor.go
git commit -m "feat(xhs): add Processor for note and comment processing"
```

---

## Task 7: Crawler 主入口重构

**Files:**
- Modify: `internal/xhs/xhs.go` (重构自 internal/service/xhs/service.go)

**Step 1: 重构Crawler主结构**

```go
// internal/xhs/xhs.go
package xhs

import (
	"context"

	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/constant"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/crawler"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/pkg/tools"
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/internal/worker"
	"gorm.io/gorm"
)

// CrawlerOptions Crawler配置选项
type CrawlerOptions struct {
	DB         *gorm.DB
	Client     *Client
	WorkerPool *worker.Pool
	Config     *config.Config
}

// Crawler XHS爬虫主结构
type Crawler struct {
	client     *Client
	store      Store
	processor  *Processor
	checkpoint *crawler.CheckpointManager
	workerPool *worker.Pool
	handlers   map[string]Handler
	config     *config.Config
	logger     *tools.Logger
}

// NewCrawler 创建XHS爬虫
func NewCrawler(opts CrawlerOptions) *Crawler {
	store := NewDBStore(opts.DB)
	checkpoint := crawler.NewCheckpointManager("xhs", "data/checkpoints")

	c := &Crawler{
		client:     opts.Client,
		store:      store,
		checkpoint: checkpoint,
		workerPool: opts.WorkerPool,
		config:     opts.Config,
		logger:     tools.GetLogger(),
		handlers:   make(map[string]Handler),
	}

	// 创建Processor
	c.processor = NewProcessor(c.client, c.store, c.workerPool, c.config)

	// 注册Handlers
	deps := NewHandlerDeps(c.client, c.processor, c.checkpoint, c.workerPool, c.config)
	c.handlers[constant.SearchCrawlerType] = NewSearchHandler(deps)
	c.handlers[constant.DetailCrawlerType] = NewDetailHandler(deps)
	c.handlers[constant.CreatorCrawlerType] = NewCreatorHandler(deps)
	c.handlers[constant.HomefeedCrawlerType] = NewHomefeedHandler(deps)

	return c
}

// Initialize 初始化
func (c *Crawler) Initialize() {
	c.logger.Info("[Crawler.Initialize] Initializing XHS crawler")
	c.client.Initialize()
}

// Start 启动爬虫
func (c *Crawler) Start(ctx context.Context) {
	c.logger.Info("[Crawler.Start] Starting XHS crawler")

	// 检查登录状态
	if !c.client.Pong() {
		c.logger.Error("[Crawler.Start] API client pong failed, please check account")
		return
	}

	// 根据配置选择Handler
	crawlerType := c.config.CrawlerType
	handler, ok := c.handlers[crawlerType]
	if !ok {
		c.logger.Error("[Crawler.Start] Unknown crawler type: ", crawlerType)
		return
	}

	c.logger.Info("[Crawler.Start] Using handler: ", handler.Name())

	// 执行爬取
	if err := handler.Handle(ctx); err != nil {
		c.logger.Error("[Crawler.Start] Handler error: ", err)
		return
	}

	c.logger.Info("[Crawler.Start] XHS crawler finished")
}

// GetHandler 获取指定类型的Handler
func (c *Crawler) GetHandler(crawlerType string) Handler {
	return c.handlers[crawlerType]
}
```

**Step 2: 更新constant定义**

```go
// constant/constant.go 添加
const (
	HomefeedCrawlerType = "homefeed"
)
```

**Step 3: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./...`
Expected: 编译成功

**Step 4: Commit**

```bash
git add internal/xhs/xhs.go constant/constant.go
git commit -m "refactor(xhs): restructure Crawler with Handler-based architecture"
```

---

## Task 8: 清理旧代码和整理目录

**Files:**
- Delete: `internal/repo/platform_save_data/xhs/xhs_json_repo.go`
- Delete: `internal/repo/platform_save_data/xhs/xhs_csv_repo.go`
- Move: `internal/service/xhs/*` -> `internal/xhs/` (如果尚未移动)

**Step 1: 删除JSON/CSV存储代码**

```bash
rm -f internal/repo/platform_save_data/xhs/xhs_json_repo.go
rm -f internal/repo/platform_save_data/xhs/xhs_csv_repo.go
```

**Step 2: 整理目录结构**

```bash
# 如果internal/service/xhs存在，移动内容到internal/xhs
# mv internal/service/xhs/* internal/xhs/ (根据实际情况)
```

**Step 3: 更新import路径**

更新所有引用旧路径的文件。

**Step 4: 验证编译**

Run: `cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang && go build ./...`
Expected: 编译成功

**Step 5: Commit**

```bash
git add -A
git commit -m "refactor: cleanup old code and reorganize directory structure"
```

---

## Task 9: 集成测试

**Step 1: 运行完整编译**

```bash
cd /Users/nanmi/workspace/github/MediaCrawlerPro/MediaCrawlerPro-Golang
go build ./...
```

**Step 2: 运行现有测试**

```bash
go test ./...
```

**Step 3: 手动测试Search功能**

配置好config后运行：
```bash
go run main.go
```

验证：
- [ ] 搜索功能正常
- [ ] 帖子详情获取正常
- [ ] 数据保存到数据库
- [ ] 断点文件生成

---

## 实现顺序总结

| 顺序 | Task | 说明 |
|------|------|------|
| 1 | Worker Pool | 基础设施，无依赖 |
| 2 | Checkpoint | 基础设施，无依赖 |
| 3 | Store + Model | 依赖GORM |
| 4 | Client API扩展 | 依赖现有Client |
| 5 | Handler | 依赖Store, Client, Worker, Checkpoint |
| 6 | Processor | 依赖Store, Client, Worker |
| 7 | Crawler主入口 | 组装所有组件 |
| 8 | 清理旧代码 | 最后清理 |
| 9 | 集成测试 | 验证整体功能 |
