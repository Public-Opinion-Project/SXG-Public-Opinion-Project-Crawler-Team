### MediaCrawlerPro-Golang 项目结构说明
```tree
.
├── cmd                                               # 命令行工具目录
│   └── root.go                                       # 根命令实现
├── config                                            # 配置文件目录
│   ├── config.go                                     # 配置文件加载实现
│   ├── config.yml                                    # 配置文件
│   └── db_config.go                                  # 数据库配置实现
├── constant                                          # 常量定义目录
│   ├── account_pool.go                               # 账号池相关常量
│   ├── constant.go                                   # 通用常量定义
│   └── error_code.go                                 # 错误码定义
├── internal                                          # 内部代码目录
│   ├── models                                        # 数据模型目录
│   │   ├── xiaohongshu                               # 小红书相关模型
│   │   │   ├── common.go                             # 通用模型定义
│   │   │   ├── note_detail.go                        # 笔记详情模型
│   │   │   ├── search.go                             # 搜索相关模型
│   │   │   └── self_user.go                          # 用户信息模型
│   │   ├── account_pool.go                           # 账号池模型
│   │   └── ip_info.go                                # IP信息模型
│   ├── pkg                                           # 公共包目录
│   │   ├── account_pool                              # 账号池管理包
│   │   │   └── account_pool.go                       # 账号池实现
│   │   ├── cache                                     # 缓存包
│   │   │   ├── cache.go                              # 缓存接口定义
│   │   │   ├── local_cache.go                        # 本地缓存实现
│   │   │   └── redis_cache.go                        # Redis缓存实现
│   │   ├── httpclient                                # HTTP客户端包
│   │   │   ├── client.go                             # HTTP客户端实现
│   │   │   ├── client_test.go                        # 客户端测试
│   │   │   ├── config.go                             # 客户端配置
│   │   │   └── config_test.go                        # 配置测试
│   │   ├── proxy                                     # 代理管理包
│   │   │   ├── provider                              # 代理提供者目录
│   │   │   ├── base_proxy.go                         # 基础代理实现
│   │   │   └── ip_proxy.go                           # IP代理实现
│   │   ├── rpc                                       # RPC服务包
│   │   │   ├── sign                                  # 签名服务目录
│   │   │   └── signsrv                               # 签名服务实现
│   │   │       ├── client.go                         # 签名客户端
│   │   │       └── model.go                          # 签名模型
│   │   └── tools                                     # 工具包
│   │       ├── convert.go                            # 数据转换工具
│   │       ├── convert_test.go                       # 转换工具测试
│   │       ├── crawler.go                            # 爬虫工具实现
│   │       ├── crawler_test.go                       # 爬虫工具测试
│   │       ├── logger.go                             # 日志工具
│   │       └── time.go                               # 时间工具
│   ├── repo                                          # 数据仓库目录
│   │   ├── accounts_cookies                          # 账号Cookie管理
│   │   │   └── accounts_cookies.go                   # Cookie管理实现
│   │   ├── platform_save_data                        # 平台数据存储
│   │   │   └── xhs                                   # 小红书数据存储
│   │   │       ├── xhs_csv_repo.go                   # CSV存储实现
│   │   │       ├── xhs_db_repo.go                    # 数据库存储实现
│   │   │       ├── xhs_json_repo.go                  # JSON存储实现
│   │   │       ├── xhs_model.go                      # 存储模型定义
│   │   │       └── xhs_repo.go                       # 存储接口定义
│   │   └── db.go                                     # 数据库连接管理
│   ├── server                                        # 服务器目录
│   ├── service                                       # 业务服务目录
│   │   ├── xhs                                       # 小红书服务
│   │   │   ├── client.go                             # 小红书客户端
│   │   │   ├── convert.go                            # 数据转换实现
│   │   │   └── service.go                            # 服务实现
│   │   ├── client.go                                 # 通用客户端接口
│   │   └── service.go                                # 通用服务接口
│   └── app.go                                        # 应用程序入口
├── LICENSE                                           # 开源许可证
├── Makefile                                          # 项目构建文件
├── README.md                                         # 项目说明文档
├── go.mod                                            # Go模块定义
├── go.sum                                            # 依赖版本锁定
├── main.go                                           # 主程序入口
└── project_tree.md                                   # 项目结构说明
```
