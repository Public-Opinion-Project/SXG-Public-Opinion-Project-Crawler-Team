package cmd

import (
	"github.com/MediaCrawlerPro/MediaCrawlerPro-Golang/config"
	"github.com/spf13/cobra"
)

func RootCmd() *cobra.Command {
	conf := config.GetConfig()
	var rootCmd = &cobra.Command{
		Use:   "mcpro",
		Short: "Media crawler program for multiple platforms (e.g. xhs, douyin, etc.)",
		Long: `Media crawler program for multiple platforms (e.g. xhs, douyin, etc.)
小红书爬虫，抖音爬虫， 快手爬虫， B站爬虫， 微博爬虫，百度贴吧...。
Github Repo: https://github.com/MediaCrawlerPro/MediaCrawlerPro-Golang`,
		Run: func(cmd *cobra.Command, args []string) {

		},
	}
	rootCmd.Flags().StringVar(&conf.Platform, "platform", conf.Platform, "crawler platform name")
	rootCmd.Flags().StringVar(&conf.CrawlerType, "type", conf.CrawlerType, "crawler type (search | detail | creator)")
	//rootCmd.Flags().StringVar(&conf.Keywords, "keywords", "", "please input keywords, use ',' to split")
	rootCmd.Flags().IntVar(&conf.StartPage, "start", conf.StartPage, "number of start page")
	rootCmd.Flags().StringVar(&conf.SaveDataOption, "save_data_option", conf.SaveDataOption, "where to save the data (csv or db or json)")

	return rootCmd
}
